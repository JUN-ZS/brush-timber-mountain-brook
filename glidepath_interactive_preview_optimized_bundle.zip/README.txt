Glidepath Preview v2.1

1. Extract this archive.
2. Open v2.html in a current Edge or Chrome browser. It is a standalone offline HTML file.
3. Read glidepath_preview_v2.1_methodology.md before interpreting any results.

Important:
- The inflation selector is a scenario input, not actual CPI or a forecast.
- Counts below initial capital are nominal-only; they are not real purchasing-power breach rates.
- Withdrawal and shortfall dollar values remain nominal.
- STRIPS/TIPS are not modeled here; this does not claim a guaranteed floor.
- The optimizer buttons are in-sample historical rankings, not predictions.
- The 157 rolling 10-year windows overlap and are not independent probability trials.
- This package's separate machine audit JSON is kept next to the ZIP in the repository.
