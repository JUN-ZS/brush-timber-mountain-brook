# Live Candidates

Generated UTC: 2026-09-04T03:37:57.516577+00:00

## Honesty

- Fitness ≠ CAGR; gates require IS n≥30, OOS n≥15, both EV>0, anti fail, cost×2, not single-crisis.
- Option genes are Hypothetical / OPRA-blocked — never live.
- Shadow ≠ live capital.

## ACTIVE

### `G3_2471831b34` — ACTIVE

- evidence: **Observed**
- fitness: `0.04350249342735018` (multi-dim, not CAGR)
- IS: n=65 mean=0.008948498909485039 wr=0.6153846153846154 es5=-0.1550188873854656
- OOS: n=18 mean=0.016073106114597342 wr=0.7222222222222222
- maxDD linked: -0.46617279824662405
- cost: `{"mean_is_5bps": 0.008448498909485038, "mean_is_10bps": 0.007948498909485038, "oos_5bps": 0.015573106114597342, "oos_10bps": 0.015073106114597341, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -1% MA20, DD20<=-6%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G3_387723d3e5` — ACTIVE

- evidence: **Observed**
- fitness: `0.07005450342219068` (multi-dim, not CAGR)
- IS: n=50 mean=0.015529270975748606 wr=0.46 es5=-0.14586560410382285
- OOS: n=16 mean=0.026841075699186735 wr=0.625
- maxDD linked: -0.41328674027775714
- cost: `{"mean_is_5bps": 0.015029270975748606, "mean_is_10bps": 0.014529270975748607, "oos_5bps": 0.026341075699186735, "oos_10bps": 0.025841075699186734, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -5% MA20, DD20<=-6%, persist>=5, transition filters, hold 10d → positive mean forward QQQ (spot).

### `G3_effaff7b7d` — ACTIVE

- evidence: **Observed**
- fitness: `0.03525668469337621` (multi-dim, not CAGR)
- IS: n=74 mean=0.004711341519730233 wr=0.527027027027027 es5=-0.17018870726325339
- OOS: n=26 mean=0.019381521205966718 wr=0.6923076923076923
- maxDD linked: -0.47439217745804174
- cost: `{"mean_is_5bps": 0.004211341519730233, "mean_is_10bps": 0.0037113415197302328, "oos_5bps": 0.018881521205966718, "oos_10bps": 0.018381521205966717, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-6%, persist>=7, transition filters, hold 10d → positive mean forward QQQ (spot).

### `G3_f4cc07c313` — ACTIVE

- evidence: **Observed**
- fitness: `0.07005450342219068` (multi-dim, not CAGR)
- IS: n=50 mean=0.015529270975748606 wr=0.46 es5=-0.14586560410382285
- OOS: n=16 mean=0.026841075699186735 wr=0.625
- maxDD linked: -0.41328674027775714
- cost: `{"mean_is_5bps": 0.015029270975748606, "mean_is_10bps": 0.014529270975748607, "oos_5bps": 0.026341075699186735, "oos_10bps": 0.025841075699186734, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -5% MA20, DD20<=-2%, persist>=5, transition filters, hold 10d → positive mean forward QQQ (spot).

### `G3_ad105f62ac` — ACTIVE

- evidence: **Observed**
- fitness: `0.032978190299589996` (multi-dim, not CAGR)
- IS: n=45 mean=0.004707234171266851 wr=0.6222222222222222 es5=-0.22974563211383625
- OOS: n=16 mean=0.023835761521161264 wr=0.6875
- maxDD linked: -0.5912806573766639
- cost: `{"mean_is_5bps": 0.00420723417126685, "mean_is_10bps": 0.0037072341712668508, "oos_5bps": 0.023335761521161263, "oos_10bps": 0.022835761521161263, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-4%, persist>=10, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G3_fcdcd4e680` — ACTIVE

- evidence: **Observed**
- fitness: `0.06188996473500314` (multi-dim, not CAGR)
- IS: n=66 mean=0.014574006662139042 wr=0.6212121212121212 es5=-0.16404843146225448
- OOS: n=20 mean=0.02014350782465323 wr=0.75
- maxDD linked: -0.5413046904064203
- cost: `{"mean_is_5bps": 0.014074006662139042, "mean_is_10bps": 0.013574006662139041, "oos_5bps": 0.01964350782465323, "oos_10bps": 0.019143507824653228, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -1% MA20, DD20<=-6%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G3M_e887fcac2c` — ACTIVE

- evidence: **Observed**
- fitness: `0.05852838365914987` (multi-dim, not CAGR)
- IS: n=84 mean=0.01147045732806967 wr=0.6309523809523809 es5=-0.15092478928032652
- OOS: n=27 mean=0.020042955874878362 wr=0.7407407407407407
- maxDD linked: -0.46617279824662405
- cost: `{"mean_is_5bps": 0.01097045732806967, "mean_is_10bps": 0.010470457328069671, "oos_5bps": 0.01954295587487836, "oos_10bps": 0.01904295587487836, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -1% MA20, DD20<=-2%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G3X_7fa015f240` — ACTIVE

- evidence: **Observed**
- fitness: `0.07005450342219068` (multi-dim, not CAGR)
- IS: n=50 mean=0.015529270975748606 wr=0.46 es5=-0.14586560410382285
- OOS: n=16 mean=0.026841075699186735 wr=0.625
- maxDD linked: -0.41328674027775714
- cost: `{"mean_is_5bps": 0.015029270975748606, "mean_is_10bps": 0.014529270975748607, "oos_5bps": 0.026341075699186735, "oos_10bps": 0.025841075699186734, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -5% MA20, DD20<=-4%, persist>=5, transition filters, hold 10d → positive mean forward QQQ (spot).

### `G3X_28f1f9f5fd` — ACTIVE

- evidence: **Observed**
- fitness: `0.04884491551320986` (multi-dim, not CAGR)
- IS: n=64 mean=0.008643761605342203 wr=0.609375 es5=-0.1550188873854656
- OOS: n=17 mean=0.021131418073124998 wr=0.7058823529411765
- maxDD linked: -0.46617279824662405
- cost: `{"mean_is_5bps": 0.008143761605342203, "mean_is_10bps": 0.007643761605342203, "oos_5bps": 0.020631418073124998, "oos_10bps": 0.020131418073124997, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-6%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_6d1a9bdc50` — ACTIVE

- evidence: **Observed**
- fitness: `0.07349861015537554` (multi-dim, not CAGR)
- IS: n=79 mean=0.017467281765788375 wr=0.6455696202531646 es5=-0.16404843146225448
- OOS: n=28 mean=0.021823530082575877 wr=0.7857142857142857
- maxDD linked: -0.5413046904064203
- cost: `{"mean_is_5bps": 0.016967281765788374, "mean_is_10bps": 0.016467281765788374, "oos_5bps": 0.021323530082575877, "oos_10bps": 0.020823530082575877, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -1% MA20, DD20<=-4%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_abb4039cbf` — ACTIVE

- evidence: **Observed**
- fitness: `0.0587594565687127` (multi-dim, not CAGR)
- IS: n=70 mean=0.010651032223455066 wr=0.6142857142857143 es5=-0.16404843146225448
- OOS: n=24 mean=0.02417355398981254 wr=0.75
- maxDD linked: -0.5022909745537796
- cost: `{"mean_is_5bps": 0.010151032223455066, "mean_is_10bps": 0.009651032223455067, "oos_5bps": 0.02367355398981254, "oos_10bps": 0.02317355398981254, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-4%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_bb4f0eb457` — ACTIVE

- evidence: **Observed**
- fitness: `0.060733658002573666` (multi-dim, not CAGR)
- IS: n=77 mean=0.01220000406791313 wr=0.6363636363636364 es5=-0.1550188873854656
- OOS: n=27 mean=0.021250052368235916 wr=0.7777777777777778
- maxDD linked: -0.46617279824662405
- cost: `{"mean_is_5bps": 0.01170000406791313, "mean_is_10bps": 0.01120000406791313, "oos_5bps": 0.020750052368235915, "oos_10bps": 0.020250052368235915, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -1% MA20, DD20<=-4%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_c8736cbfac` — ACTIVE

- evidence: **Observed**
- fitness: `0.052071623424351295` (multi-dim, not CAGR)
- IS: n=52 mean=0.008702051656128104 wr=0.46153846153846156 es5=-0.16485131302842995
- OOS: n=17 mean=0.026821106294323504 wr=0.6470588235294118
- maxDD linked: -0.3972639758481147
- cost: `{"mean_is_5bps": 0.008202051656128103, "mean_is_10bps": 0.007702051656128104, "oos_5bps": 0.026321106294323503, "oos_10bps": 0.025821106294323503, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -5% MA20, DD20<=-4%, persist>=3, transition filters, hold 10d → positive mean forward QQQ (spot).

### `G6_7e150b31ee` — ACTIVE

- evidence: **Observed**
- fitness: `0.07279784798861341` (multi-dim, not CAGR)
- IS: n=86 mean=0.017251434798825863 wr=0.6395348837209303 es5=-0.15814842454175762
- OOS: n=28 mean=0.02065954417826681 wr=0.75
- maxDD linked: -0.5413046904064203
- cost: `{"mean_is_5bps": 0.016751434798825862, "mean_is_10bps": 0.01625143479882586, "oos_5bps": 0.02015954417826681, "oos_10bps": 0.01965954417826681, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -1% MA20, DD20<=-2%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_8591e5fc2d` — ACTIVE

- evidence: **Observed**
- fitness: `0.07958569671322133` (multi-dim, not CAGR)
- IS: n=73 mean=0.015946668824570794 wr=0.6164383561643836 es5=-0.16404843146225448
- OOS: n=26 mean=0.029052566795579847 wr=0.7692307692307693
- maxDD linked: -0.5413046904064203
- cost: `{"mean_is_5bps": 0.015446668824570794, "mean_is_10bps": 0.014946668824570793, "oos_5bps": 0.028552566795579847, "oos_10bps": 0.028052566795579846, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-4%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_1e935e7dcc` — ACTIVE

- evidence: **Observed**
- fitness: `0.059432220841388717` (multi-dim, not CAGR)
- IS: n=75 mean=0.012483865862225165 wr=0.64 es5=-0.16404843146225448
- OOS: n=27 mean=0.020441560087590904 wr=0.7777777777777778
- maxDD linked: -0.5022909745537796
- cost: `{"mean_is_5bps": 0.011983865862225164, "mean_is_10bps": 0.011483865862225166, "oos_5bps": 0.019941560087590904, "oos_10bps": 0.019441560087590903, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -1% MA20, DD20<=-4%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_460902cfc9` — ACTIVE

- evidence: **Observed**
- fitness: `0.04269261091291191` (multi-dim, not CAGR)
- IS: n=54 mean=0.007660515748951522 wr=0.5925925925925926 es5=-0.15488596219589898
- OOS: n=20 mean=0.019761264001653983 wr=0.65
- maxDD linked: -0.5058116111443333
- cost: `{"mean_is_5bps": 0.007160515748951522, "mean_is_10bps": 0.006660515748951522, "oos_5bps": 0.019261264001653983, "oos_10bps": 0.018761264001653982, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-6%, persist>=10, transition filters, hold 10d → positive mean forward QQQ (spot).

### `G6_4f5d98aa3c` — ACTIVE

- evidence: **Observed**
- fitness: `0.03032569413661191` (multi-dim, not CAGR)
- IS: n=82 mean=0.004339258189904862 wr=0.5365853658536586 es5=-0.16340511829257384
- OOS: n=29 mean=0.014690997214178332 wr=0.6551724137931034
- maxDD linked: -0.5437202180535547
- cost: `{"mean_is_5bps": 0.003839258189904862, "mean_is_10bps": 0.003339258189904862, "oos_5bps": 0.014190997214178332, "oos_10bps": 0.013690997214178331, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-6%, persist>=7, transition filters, hold 10d → positive mean forward QQQ (spot).

### `G6_a98902b9b2` — ACTIVE

- evidence: **Observed**
- fitness: `0.03737195879391768` (multi-dim, not CAGR)
- IS: n=55 mean=0.00779507770379581 wr=0.6181818181818182 es5=-0.1736648811805259
- OOS: n=18 mean=0.015231821191283905 wr=0.7222222222222222
- maxDD linked: -0.5639780711416749
- cost: `{"mean_is_5bps": 0.00729507770379581, "mean_is_10bps": 0.00679507770379581, "oos_5bps": 0.014731821191283904, "oos_10bps": 0.014231821191283904, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-4%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_ce9c325f93` — ACTIVE

- evidence: **Observed**
- fitness: `0.07248821949163958` (multi-dim, not CAGR)
- IS: n=66 mean=0.014574006662139042 wr=0.6212121212121212 es5=-0.16404843146225448
- OOS: n=20 mean=0.02763309282916241 wr=0.75
- maxDD linked: -0.5413046904064203
- cost: `{"mean_is_5bps": 0.014074006662139042, "mean_is_10bps": 0.013574006662139041, "oos_5bps": 0.02713309282916241, "oos_10bps": 0.02663309282916241, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-6%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_d53ce71b80` — ACTIVE

- evidence: **Observed**
- fitness: `0.0539823148901159` (multi-dim, not CAGR)
- IS: n=56 mean=0.015514608359263193 wr=0.5892857142857143 es5=-0.1539025274141512
- OOS: n=21 mean=0.01529966577748371 wr=0.6190476190476191
- maxDD linked: -0.4965170621604841
- cost: `{"mean_is_5bps": 0.015014608359263193, "mean_is_10bps": 0.014514608359263194, "oos_5bps": 0.01479966577748371, "oos_10bps": 0.014299665777483709, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-2%, persist>=10, transition filters, hold 10d → positive mean forward QQQ (spot).

### `G6_26196e1aef` — ACTIVE

- evidence: **Observed**
- fitness: `0.06031186573247872` (multi-dim, not CAGR)
- IS: n=72 mean=0.010509807287624056 wr=0.6111111111111112 es5=-0.1550188873854656
- OOS: n=24 mean=0.02508310780553818 wr=0.75
- maxDD linked: -0.46617279824662405
- cost: `{"mean_is_5bps": 0.010009807287624056, "mean_is_10bps": 0.009509807287624055, "oos_5bps": 0.02458310780553818, "oos_10bps": 0.02408310780553818, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-4%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_bc47af9a6b` — ACTIVE

- evidence: **Observed**
- fitness: `0.041185315723247344` (multi-dim, not CAGR)
- IS: n=64 mean=0.00887588913566035 wr=0.609375 es5=-0.16404843146225448
- OOS: n=18 mean=0.014860367693629825 wr=0.7222222222222222
- maxDD linked: -0.5022909745537796
- cost: `{"mean_is_5bps": 0.00837588913566035, "mean_is_10bps": 0.007875889135660352, "oos_5bps": 0.014360367693629824, "oos_10bps": 0.013860367693629826, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -1% MA20, DD20<=-6%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_22619cc6e9` — ACTIVE

- evidence: **Observed**
- fitness: `0.05164705164766275` (multi-dim, not CAGR)
- IS: n=61 mean=0.01385551564078958 wr=0.5901639344262295 es5=-0.14947992034278443
- OOS: n=22 mean=0.014933923875751633 wr=0.6363636363636364
- maxDD linked: -0.4965170621604841
- cost: `{"mean_is_5bps": 0.01335551564078958, "mean_is_10bps": 0.012855515640789579, "oos_5bps": 0.014433923875751632, "oos_10bps": 0.013933923875751632, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-6%, persist>=10, transition filters, hold 10d → positive mean forward QQQ (spot).

### `G6_6bd714a7c2` — ACTIVE

- evidence: **Observed**
- fitness: `0.03984413210410168` (multi-dim, not CAGR)
- IS: n=56 mean=0.00796930162250477 wr=0.6071428571428571 es5=-0.1616254890781407
- OOS: n=18 mean=0.016444559612251424 wr=0.7222222222222222
- maxDD linked: -0.5278598948345193
- cost: `{"mean_is_5bps": 0.007469301622504769, "mean_is_10bps": 0.00696930162250477, "oos_5bps": 0.015944559612251424, "oos_10bps": 0.015444559612251423, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-2%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_18e843ee7d` — ACTIVE

- evidence: **Observed**
- fitness: `0.052071623424351295` (multi-dim, not CAGR)
- IS: n=52 mean=0.008702051656128104 wr=0.46153846153846156 es5=-0.16485131302842995
- OOS: n=17 mean=0.026821106294323504 wr=0.6470588235294118
- maxDD linked: -0.3972639758481147
- cost: `{"mean_is_5bps": 0.008202051656128103, "mean_is_10bps": 0.007702051656128104, "oos_5bps": 0.026321106294323503, "oos_10bps": 0.025821106294323503, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -5% MA20, DD20<=-2%, persist>=3, transition filters, hold 10d → positive mean forward QQQ (spot).

### `G6_fd27d5ebe7` — ACTIVE

- evidence: **Observed**
- fitness: `0.03188861845727613` (multi-dim, not CAGR)
- IS: n=71 mean=0.004256218984830235 wr=0.5211267605633803 es5=-0.17018870726325339
- OOS: n=25 mean=0.017887455127922162 wr=0.68
- maxDD linked: -0.5611832606100227
- cost: `{"mean_is_5bps": 0.0037562189848302347, "mean_is_10bps": 0.0032562189848302347, "oos_5bps": 0.017387455127922162, "oos_10bps": 0.01688745512792216, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-6%, persist>=7, transition filters, hold 10d → positive mean forward QQQ (spot).

### `G6_a1234cf405` — ACTIVE

- evidence: **Observed**
- fitness: `0.037557845636806704` (multi-dim, not CAGR)
- IS: n=54 mean=0.005996206518890328 wr=0.5185185185185185 es5=-0.19960428182694198
- OOS: n=18 mean=0.021080935129868115 wr=0.7222222222222222
- maxDD linked: -0.5264722883815505
- cost: `{"mean_is_5bps": 0.005496206518890328, "mean_is_10bps": 0.004996206518890328, "oos_5bps": 0.020580935129868114, "oos_10bps": 0.020080935129868114, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -1% MA20, DD20<=-2%, persist>=15, transition filters, hold 10d → positive mean forward QQQ (spot).

### `G6_739971b6f4` — ACTIVE

- evidence: **Observed**
- fitness: `0.04124785527866632` (multi-dim, not CAGR)
- IS: n=54 mean=0.007660515748951522 wr=0.5925925925925926 es5=-0.15488596219589898
- OOS: n=20 mean=0.018446417475996475 wr=0.65
- maxDD linked: -0.5058116111443333
- cost: `{"mean_is_5bps": 0.007160515748951522, "mean_is_10bps": 0.006660515748951522, "oos_5bps": 0.017946417475996474, "oos_10bps": 0.017446417475996474, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-2%, persist>=10, transition filters, hold 10d → positive mean forward QQQ (spot).

### `G6_6ccc0945e2` — ACTIVE

- evidence: **Observed**
- fitness: `0.029567044547840295` (multi-dim, not CAGR)
- IS: n=75 mean=0.004371750344553272 wr=0.5333333333333333 es5=-0.17018870726325339
- OOS: n=28 mean=0.01459988372258523 wr=0.6785714285714286
- maxDD linked: -0.47439217745804174
- cost: `{"mean_is_5bps": 0.003871750344553272, "mean_is_10bps": 0.003371750344553272, "oos_5bps": 0.01409988372258523, "oos_10bps": 0.013599883722585231, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-4%, persist>=7, transition filters, hold 10d → positive mean forward QQQ (spot).

### `G6_b912e541d5` — ACTIVE

- evidence: **Observed**
- fitness: `0.0539823148901159` (multi-dim, not CAGR)
- IS: n=56 mean=0.015514608359263193 wr=0.5892857142857143 es5=-0.1539025274141512
- OOS: n=21 mean=0.01529966577748371 wr=0.6190476190476191
- maxDD linked: -0.4965170621604841
- cost: `{"mean_is_5bps": 0.015014608359263193, "mean_is_10bps": 0.014514608359263194, "oos_5bps": 0.01479966577748371, "oos_10bps": 0.014299665777483709, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-4%, persist>=10, transition filters, hold 10d → positive mean forward QQQ (spot).

## SHADOW / PROMISING (not live)

### `G6_871e6e0ca9` — PROMISING

- evidence: **Observed**
- fitness: `0.06683466635915379` (multi-dim, not CAGR)
- IS: n=40 mean=0.014118969670708817 wr=0.6 es5=-0.16075378202083423
- OOS: n=12 mean=0.04083744477714258 wr=0.75
- maxDD linked: -0.421997982463014
- cost: `{"mean_is_5bps": 0.013618969670708816, "mean_is_10bps": 0.013118969670708816, "oos_5bps": 0.04033744477714258, "oos_10bps": 0.03983744477714258, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-2%, persist>=5, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G3M_97a70da9c7` — PROMISING

- evidence: **Observed**
- fitness: `0.06587128080452` (multi-dim, not CAGR)
- IS: n=81 mean=0.012887318293365289 wr=0.6296296296296297 es5=-0.15814842454175762
- OOS: n=30 mean=0.023255588686005094 wr=0.7666666666666667
- maxDD linked: -0.6092062696757234
- cost: `{"mean_is_5bps": 0.012387318293365288, "mean_is_10bps": 0.011887318293365288, "oos_5bps": 0.022755588686005093, "oos_10bps": 0.022255588686005093, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-4%, persist>=5, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G3X_a36c8c53d5` — PROMISING

- evidence: **Observed**
- fitness: `0.0658487237906569` (multi-dim, not CAGR)
- IS: n=61 mean=0.014800230190505059 wr=0.6229508196721312 es5=-0.16404843146225448
- OOS: n=21 mean=0.023306182017173754 wr=0.7619047619047619
- maxDD linked: -0.6029917869943155
- cost: `{"mean_is_5bps": 0.014300230190505058, "mean_is_10bps": 0.01380023019050506, "oos_5bps": 0.022806182017173753, "oos_10bps": 0.022306182017173753, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-4%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_97b86d401a` — PROMISING

- evidence: **Observed**
- fitness: `0.0658487237906569` (multi-dim, not CAGR)
- IS: n=61 mean=0.014800230190505059 wr=0.6229508196721312 es5=-0.16404843146225448
- OOS: n=21 mean=0.023306182017173754 wr=0.7619047619047619
- maxDD linked: -0.6029917869943155
- cost: `{"mean_is_5bps": 0.014300230190505058, "mean_is_10bps": 0.01380023019050506, "oos_5bps": 0.022806182017173753, "oos_10bps": 0.022306182017173753, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-2%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G3M_4dba316bd9` — PROMISING

- evidence: **Observed**
- fitness: `0.0657885316641835` (multi-dim, not CAGR)
- IS: n=73 mean=0.011510132909843115 wr=0.6301369863013698 es5=-0.16404843146225448
- OOS: n=24 mean=0.02750454637784304 wr=0.7083333333333334
- maxDD linked: -0.6193262973062809
- cost: `{"mean_is_5bps": 0.011010132909843115, "mean_is_10bps": 0.010510132909843116, "oos_5bps": 0.02700454637784304, "oos_10bps": 0.02650454637784304, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-4%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G3M_8f91cd3594` — PROMISING

- evidence: **Observed**
- fitness: `0.0657885316641835` (multi-dim, not CAGR)
- IS: n=73 mean=0.011510132909843115 wr=0.6301369863013698 es5=-0.16404843146225448
- OOS: n=24 mean=0.02750454637784304 wr=0.7083333333333334
- maxDD linked: -0.6193262973062809
- cost: `{"mean_is_5bps": 0.011010132909843115, "mean_is_10bps": 0.010510132909843116, "oos_5bps": 0.02700454637784304, "oos_10bps": 0.02650454637784304, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-2%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_0de69f9494` — PROMISING

- evidence: **Observed**
- fitness: `0.06420940898759556` (multi-dim, not CAGR)
- IS: n=42 mean=0.022891590087551445 wr=0.5238095238095238 es5=-0.1377622467592524
- OOS: n=12 mean=0.02177374013673226 wr=0.8333333333333334
- maxDD linked: -0.41328674027775714
- cost: `{"mean_is_5bps": 0.022391590087551445, "mean_is_10bps": 0.021891590087551444, "oos_5bps": 0.02127374013673226, "oos_10bps": 0.02077374013673226, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-4%, persist>=5, transition filters, hold 10d → positive mean forward QQQ (spot).

### `G6_324f548efc` — PROMISING

- evidence: **Observed**
- fitness: `0.06384942869232876` (multi-dim, not CAGR)
- IS: n=82 mean=0.012041995550668245 wr=0.6219512195121951 es5=-0.15814842454175762
- OOS: n=30 mean=0.023255588686005094 wr=0.7666666666666667
- maxDD linked: -0.6092062696757234
- cost: `{"mean_is_5bps": 0.011541995550668245, "mean_is_10bps": 0.011041995550668246, "oos_5bps": 0.022755588686005093, "oos_10bps": 0.022255588686005093, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-2%, persist>=5, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G3_afd1288c76` — PROMISING

- evidence: **Observed**
- fitness: `0.06369180865305053` (multi-dim, not CAGR)
- IS: n=70 mean=0.011993299085799616 wr=0.6285714285714286 es5=-0.16404843146225448
- OOS: n=24 mean=0.025223489122332684 wr=0.7083333333333334
- maxDD linked: -0.6137422339602648
- cost: `{"mean_is_5bps": 0.011493299085799616, "mean_is_10bps": 0.010993299085799615, "oos_5bps": 0.024723489122332683, "oos_10bps": 0.024223489122332683, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-4%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_02127ba4ee` — PROMISING

- evidence: **Observed**
- fitness: `0.06369180865305053` (multi-dim, not CAGR)
- IS: n=70 mean=0.011993299085799616 wr=0.6285714285714286 es5=-0.16404843146225448
- OOS: n=24 mean=0.025223489122332684 wr=0.7083333333333334
- maxDD linked: -0.6137422339602648
- cost: `{"mean_is_5bps": 0.011493299085799616, "mean_is_10bps": 0.010993299085799615, "oos_5bps": 0.024723489122332683, "oos_10bps": 0.024223489122332683, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-2%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_619f4e13d0` — PROMISING

- evidence: **Observed**
- fitness: `0.06361177460828435` (multi-dim, not CAGR)
- IS: n=71 mean=0.012187853335408352 wr=0.647887323943662 es5=-0.14378408631797668
- OOS: n=25 mean=0.023747899978295142 wr=0.68
- maxDD linked: -0.6665511022723642
- cost: `{"mean_is_5bps": 0.011687853335408352, "mean_is_10bps": 0.011187853335408351, "oos_5bps": 0.023247899978295142, "oos_10bps": 0.02274789997829514, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-2%, persist>=5, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_65d2c6a2b2` — PROMISING

- evidence: **Observed**
- fitness: `0.06361177460828435` (multi-dim, not CAGR)
- IS: n=71 mean=0.012187853335408352 wr=0.647887323943662 es5=-0.14378408631797668
- OOS: n=25 mean=0.023747899978295142 wr=0.68
- maxDD linked: -0.6665511022723642
- cost: `{"mean_is_5bps": 0.011687853335408352, "mean_is_10bps": 0.011187853335408351, "oos_5bps": 0.023247899978295142, "oos_10bps": 0.02274789997829514, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-4%, persist>=5, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_e604fc7102` — PROMISING

- evidence: **Observed**
- fitness: `0.06308651984975416` (multi-dim, not CAGR)
- IS: n=37 mean=0.011056115927866096 wr=0.5945945945945946 es5=-0.16075378202083423
- OOS: n=12 mean=0.04842679069820585 wr=0.8333333333333334
- maxDD linked: -0.43221221922781916
- cost: `{"mean_is_5bps": 0.010556115927866096, "mean_is_10bps": 0.010056115927866097, "oos_5bps": 0.04792679069820585, "oos_10bps": 0.04742679069820585, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -1% MA20, DD20<=-2%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_085e34f46d` — PROMISING

- evidence: **Observed**
- fitness: `0.06158049418721261` (multi-dim, not CAGR)
- IS: n=38 mean=0.010971364083078578 wr=0.5789473684210527 es5=-0.2360921013514392
- OOS: n=12 mean=0.05198545652552478 wr=0.75
- maxDD linked: -0.5335799755991077
- cost: `{"mean_is_5bps": 0.010471364083078577, "mean_is_10bps": 0.009971364083078579, "oos_5bps": 0.05148545652552478, "oos_10bps": 0.05098545652552478, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-2%, persist>=5, transition filters, hold 20d → positive mean forward QQQ (spot).

### `G6_96edc9f227` — PROMISING

- evidence: **Observed**
- fitness: `0.060658659206216034` (multi-dim, not CAGR)
- IS: n=65 mean=0.010012424780656977 wr=0.6 es5=-0.16603312624916725
- OOS: n=23 mean=0.028465030463087286 wr=0.782608695652174
- maxDD linked: -0.7104802049549462
- cost: `{"mean_is_5bps": 0.009512424780656977, "mean_is_10bps": 0.009012424780656978, "oos_5bps": 0.027965030463087286, "oos_10bps": 0.027465030463087285, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-6%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_2b75de6b16` — PROMISING

- evidence: **Observed**
- fitness: `0.060149727445460384` (multi-dim, not CAGR)
- IS: n=66 mean=0.0102554226906036 wr=0.6212121212121212 es5=-0.14378408631797668
- OOS: n=22 mean=0.026105580627918068 wr=0.6818181818181818
- maxDD linked: -0.7117271326985672
- cost: `{"mean_is_5bps": 0.0097554226906036, "mean_is_10bps": 0.009255422690603601, "oos_5bps": 0.025605580627918068, "oos_10bps": 0.025105580627918067, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-6%, persist>=5, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_4dee3ac93f` — PROMISING

- evidence: **Observed**
- fitness: `0.059906170715065175` (multi-dim, not CAGR)
- IS: n=63 mean=0.010100639476646462 wr=0.6349206349206349 es5=-0.16404843146225448
- OOS: n=18 mean=0.027834468097455458 wr=0.6666666666666666
- maxDD linked: -0.6193262973062809
- cost: `{"mean_is_5bps": 0.009600639476646461, "mean_is_10bps": 0.009100639476646463, "oos_5bps": 0.027334468097455458, "oos_10bps": 0.026834468097455457, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-6%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_bb34307d0e` — PROMISING

- evidence: **Observed**
- fitness: `0.05911741073790365` (multi-dim, not CAGR)
- IS: n=83 mean=0.012659053047371494 wr=0.6385542168674698 es5=-0.15814842454175762
- OOS: n=27 mean=0.018862117375479288 wr=0.7037037037037037
- maxDD linked: -0.6524577500481616
- cost: `{"mean_is_5bps": 0.012159053047371493, "mean_is_10bps": 0.011659053047371495, "oos_5bps": 0.018362117375479287, "oos_10bps": 0.017862117375479287, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -1% MA20, DD20<=-2%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_68f0384adc` — PROMISING

- evidence: **Observed**
- fitness: `0.05905657703867546` (multi-dim, not CAGR)
- IS: n=76 mean=0.012397781786496628 wr=0.6447368421052632 es5=-0.16404843146225448
- OOS: n=27 mean=0.020201979610493546 wr=0.7407407407407407
- maxDD linked: -0.6524577500481616
- cost: `{"mean_is_5bps": 0.011897781786496628, "mean_is_10bps": 0.011397781786496627, "oos_5bps": 0.019701979610493546, "oos_10bps": 0.019201979610493546, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -1% MA20, DD20<=-4%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_a2c9eb2426` — PROMISING

- evidence: **Observed**
- fitness: `0.058769530235620454` (multi-dim, not CAGR)
- IS: n=80 mean=0.012301682063050911 wr=0.6 es5=-0.1504893165359976
- OOS: n=31 mean=0.01924403918570728 wr=0.8064516129032258
- maxDD linked: -0.6916719617802759
- cost: `{"mean_is_5bps": 0.01180168206305091, "mean_is_10bps": 0.011301682063050912, "oos_5bps": 0.01874403918570728, "oos_10bps": 0.01824403918570728, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -2% MA20, DD20<=-4%, persist>=5, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_374cdbfda7` — PROMISING

- evidence: **Observed**
- fitness: `0.058244576058696346` (multi-dim, not CAGR)
- IS: n=60 mean=0.013614140222942021 wr=0.6166666666666667 es5=-0.1736648811805259
- OOS: n=18 mean=0.020311438132487997 wr=0.7222222222222222
- maxDD linked: -0.6029917869943155
- cost: `{"mean_is_5bps": 0.01311414022294202, "mean_is_10bps": 0.012614140222942022, "oos_5bps": 0.019811438132487997, "oos_10bps": 0.019311438132487996, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-6%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G3X_00ad77ba64` — PROMISING

- evidence: **Observed**
- fitness: `0.058086057205156104` (multi-dim, not CAGR)
- IS: n=78 mean=0.012585329465054034 wr=0.6538461538461539 es5=-0.16404843146225448
- OOS: n=27 mean=0.019026906585685913 wr=0.7407407407407407
- maxDD linked: -0.6193262973062809
- cost: `{"mean_is_5bps": 0.012085329465054034, "mean_is_10bps": 0.011585329465054035, "oos_5bps": 0.018526906585685912, "oos_10bps": 0.018026906585685912, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -1% MA20, DD20<=-4%, persist>=7, transition filters, hold 15d → positive mean forward QQQ (spot).

### `G6_1634d68d0d` — PROMISING

- evidence: **Observed**
- fitness: `0.057661268022504375` (multi-dim, not CAGR)
- IS: n=48 mean=0.015062232994789588 wr=0.4583333333333333 es5=-0.14586560410382285
- OOS: n=15 mean=0.025281469827107484 wr=0.6
- maxDD linked: -0.41328674027775714
- cost: `{"mean_is_5bps": 0.014562232994789587, "mean_is_10bps": 0.014062232994789588, "oos_5bps": 0.024781469827107484, "oos_10bps": 0.024281469827107483, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -5% MA20, DD20<=-8%, persist>=5, transition filters, hold 10d → positive mean forward QQQ (spot).

### `G3M_304aac053c` — PROMISING

- evidence: **Observed**
- fitness: `0.05755119113592114` (multi-dim, not CAGR)
- IS: n=67 mean=0.012494852962353014 wr=0.6119402985074627 es5=-0.2177080862501964
- OOS: n=23 mean=0.022077012063218056 wr=0.6956521739130435
- maxDD linked: -0.981268163083705
- cost: `{"mean_is_5bps": 0.011994852962353014, "mean_is_10bps": 0.011494852962353013, "oos_5bps": 0.021577012063218055, "oos_10bps": 0.021077012063218055, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-4%, persist>=5, transition filters, hold 20d → positive mean forward QQQ (spot).

### `G3M_b6742ded57` — PROMISING

- evidence: **Observed**
- fitness: `0.05755119113592114` (multi-dim, not CAGR)
- IS: n=67 mean=0.012494852962353014 wr=0.6119402985074627 es5=-0.2177080862501964
- OOS: n=23 mean=0.022077012063218056 wr=0.6956521739130435
- maxDD linked: -0.981268163083705
- cost: `{"mean_is_5bps": 0.011994852962353014, "mean_is_10bps": 0.011494852962353013, "oos_5bps": 0.021577012063218055, "oos_10bps": 0.021077012063218055, "survive_5bps": true, "survive_10bps": true}`
- hypothesis: QQQ <= -3% MA20, DD20<=-2%, persist>=5, transition filters, hold 20d → positive mean forward QQQ (spot).

