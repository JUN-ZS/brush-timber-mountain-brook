# Event Clock Latest — asof 2026-09-03

Generated UTC: 2026-09-04T12:20:02.377953+00:00

**Honesty:** P(Event|State,Age) over P(Event|Age); overdue≠buy

傳統中文摘要：事件年齡只是時鐘，不是買入訊號；若 late−early hazard ≤ 0，年齡沒有 timing edge。

| event_id | days_since | median_IS | age/median | n_IS | late−early haz | confidence |
|---|---:|---:|---:|---:|---:|---|
| `vxx_p20pct_day` | 518 | 3.0 | 172.67 | 2 | -0.0766 | insufficient |
| `qqq_5d_m8` | 517 | 17.5 | 29.54 | 63 | -0.1936 | Estimated |
| `vix_above_40` | 511 | 17.5 | 29.20 | 21 | -0.6253 | Estimated |
| `dd20_m10` | 504 | 13.0 | 38.77 | 91 | -0.5424 | Estimated |
| `qqq_vxx_rel_shock` | 182 | 26.0 | 7.00 | 8 | 0.0187 | low_sample |
| `vxx_p10pct_day` | 181 | 39.0 | 4.64 | 8 | -0.0766 | low_sample |
| `vix_above_30` | 160 | 27.0 | 5.93 | 49 | -0.6773 | Estimated |
| `term_backwardation` | 149 | 13.0 | 11.46 | 110 | -0.4561 | Estimated |
| `vix_above_25` | 149 | 17.5 | 8.51 | 101 | -0.7050 | Estimated |
| `vix_p20pct_day` | 90 | 42.0 | 2.14 | 69 | -0.0310 | Estimated |
| `qqq_m3pct_day` | 72 | 8.0 | 9.00 | 196 | -0.1238 | Estimated |
| `dd20_m4` | 43 | 20.0 | 2.15 | 196 | -0.6220 | Estimated |
| `below_ma20_2pct` | 42 | 20.0 | 2.10 | 202 | -0.5307 | Estimated |
| `dd20_m6` | 42 | 21.0 | 2.00 | 136 | -0.6246 | Estimated |
| `below_ma20_3pct` | 41 | 17.5 | 2.34 | 177 | -0.4967 | Estimated |
| `persist_below_ma20_ge10` | 41 | 68.0 | 0.60 | 72 | -0.6053 | Estimated |
| `corr_breakdown_proxy` | 41 | 19.0 | 2.16 | 117 | -0.0312 | Estimated |
| `qqq_m2pct_day` | 36 | 7.0 | 5.14 | 374 | -0.1422 | Estimated |
| `vix_p10pct_day` | 36 | 14.0 | 2.57 | 315 | -0.0576 | Estimated |
| `qqq_5d_m5` | 36 | 15.0 | 2.40 | 154 | -0.2645 | Estimated |
| `vix_m10pct_day` | 35 | 19.5 | 1.79 | 193 | -0.0415 | Estimated |
| `persist_below_ma20_ge15` | 34 | 103.5 | 0.33 | 45 | -0.5665 | Estimated |
| `winning_state_phase_a` | 34 | 66.0 | 0.52 | 54 | -0.5499 | Estimated |
| `qqq_p2pct_day` | 30 | 8.0 | 3.75 | 348 | -0.1068 | Estimated |
| `qqq_p3pct_day` | 30 | 11.0 | 2.73 | 169 | -0.0889 | Estimated |
| `below_ma20` | 6 | 16.0 | 0.38 | 300 | -0.5630 | Estimated |
| `vol_compression` | 3 | 14.0 | 0.21 | 437 | -0.2679 | Estimated |
| `spy_below_ma20` | 3 | 16.0 | 0.19 | 312 | -0.5493 | Estimated |
| `qqq_m1pct_day` | 2 | 7.0 | 0.29 | 708 | -0.1429 | Estimated |
| `below_ma20_1pct` | 2 | 16.0 | 0.12 | 254 | -0.5488 | Estimated |
| `below_ma50` | 2 | 26.0 | 0.08 | 158 | -0.7151 | Estimated |
| `vol_expansion` | 1 | 16.0 | 0.06 | 357 | -0.3023 | Estimated |
| `vpz_falling_while_below` | 1 | 6.0 | 0.17 | 581 | -0.2664 | Estimated |
| `vol_dislocation_neg` | 1 | 14.0 | 0.07 | 256 | -0.5566 | Estimated |
| `persist_below_ma20_ge5` | 0 | 48.0 | 0.00 | 126 | -0.6013 | Estimated |
| `term_steep_contango` | 0 | 14.0 | 0.00 | 162 | -0.6168 | Estimated |
| `vix_below_15` | 0 | 12.0 | 0.00 | 116 | -0.7782 | Estimated |
| `mom_improve_while_below` | 0 | 7.0 | 0.00 | 479 | -0.2872 | Estimated |

## Definitions (top by age)

- `vxx_p20pct_day`: VXX daily %chg >= +20% (overlay)
- `qqq_5d_m8`: QQQ 5D return < -8%
- `vix_above_40`: VIX > 40
- `dd20_m10`: DD20 <= -10%
- `qqq_vxx_rel_shock`: VXX_rel_shock high (if present)
- `vxx_p10pct_day`: VXX daily %chg >= +10% (overlay)
- `vix_above_30`: VIX > 30
- `term_backwardation`: VIX > VIX3M (when available)
- `vix_above_25`: VIX > 25
- `vix_p20pct_day`: VIX daily %chg >= +20%
- `qqq_m3pct_day`: QQQ daily return <= -3%
- `dd20_m4`: DD20 <= -4%
- `below_ma20_2pct`: QQQ <= MA20 - 2%
- `dd20_m6`: DD20 <= -6%
- `below_ma20_3pct`: QQQ <= MA20 - 3%
