# EVB LIFEFORM Cycle Report — 2026-09-03

Generated UTC: 2026-09-04T12:20:02.991497+00:00
Root: `/workspace/evb-life`

## 傳統中文摘要

- 本輪只跑 Phase 1–2：資料核對、市場狀態、事件時鐘；**沒有**把任何基因升到 ACTIVE。
- 事件「很久沒來」≠ 買入訊號；看條件 hazard，不要賭徒謬誤。
- 事件配搭（共現 lift）已刷新；配搭提升≠交易訊號。
- 期權結構僅目錄／Hypothetical；OPRA 未接，禁止把 BS P/L 當 Verified。
- Fitness 不是 CAGR；Phase A sole A 以 Observed 現貨分數孵化中。

## MARKET STATE

```json
{
  "asof": "2026-09-03",
  "prices": {
    "QQQ": 717.6699829101562,
    "VIX": 14.319999694824219,
    "VIX3M": 17.420000076293945,
    "VIX9D": 11.680000305175781,
    "VIX6M": 19.780000686645508,
    "VXX": null,
    "SPY": 773.1699829101562,
    "TLT": 82.06999969482422
  },
  "trend": {
    "label": "below_MA20",
    "MA20": 717.7140014648437,
    "MA50": 711.0333996582032,
    "QQQ_over_MA20": -6.133160924493009e-05,
    "QQQ_over_MA50": 0.009333715202609838,
    "QQQ_ret1": 0.011885952275470846,
    "DD20": -0.019670283265251998,
    "DD60": -0.034329762329571745
  },
  "relative_vol": {
    "label": "neutral",
    "RV5": 0.14779744441401665,
    "RV20": 0.13536425169070648,
    "RV5_over_RV20": 1.0918498980936173,
    "VolPremium": 1.0578863707342732,
    "VolPremium_z": 0.002046689928206339,
    "TermSlope": 1.2164804781797713,
    "backwardation": 0.0,
    "ShortVolRel": 0.8156424967940026
  },
  "persistence": {
    "persist_below_MA20": 5,
    "consec_down": 0,
    "mom2": 0.01417382857681071,
    "mom2_improve": true,
    "QQQ_1d_up": true,
    "VolPremium_z_falling": true,
    "ShortVolRel_falling": false
  },
  "regime_hints": []
}
```

Data verify: `{'ok': True, 'missing_required': [], 'rows': 6915, 'gaps': [], 'end': '2026-09-03'}`

## EVENT CLOCK (top by days_since)

| event_id | days_since | median_IS | age/median | n_IS | late−early | conf |
|---|---:|---:|---:|---:|---:|---|
| `vxx_p20pct_day` | 518 | 3.0 | 172.67 | 2 | -0.0766 | insufficient |
| `qqq_5d_m8` | 517 | 17.5 | 29.54 | 63 | -0.1936 | Estimated |
| `vix_above_40` | 511 | 17.5 | 29.20 | 21 | -0.6253 | Estimated |
| `dd20_m10` | 504 | 13.0 | 38.77 | 91 | -0.5424 | Estimated |
| `qqq_vxx_rel_shock` | 182 | 26.0 | 7.00 | 8 | 0.0187 | low_sample |
| `vxx_p10pct_day` | 181 | 39.0 | 4.64 | 8 | -0.0766 | low_sample |
| `vix_above_30` | 160 | 27.0 | 5.93 | 49 | -0.6773 | Estimated |
| `term_backwardation` | 149 | 13.0 | 11.46 | 110 | -0.4561 | Estimated |
| `vix_above_25` | 149 | 17.5 | 8.51 | 101 | -0.7050 | Estimated |
| `vix_p20pct_day` | 90 | 42.0 | 2.14 | 69 | -0.0310 | Estimated |
| `qqq_m3pct_day` | 72 | 8.0 | 9.00 | 196 | -0.1238 | Estimated |
| `dd20_m4` | 43 | 20.0 | 2.15 | 196 | -0.6220 | Estimated |
| `below_ma20_2pct` | 42 | 20.0 | 2.10 | 202 | -0.5307 | Estimated |
| `dd20_m6` | 42 | 21.0 | 2.00 | 136 | -0.6246 | Estimated |
| `below_ma20_3pct` | 41 | 17.5 | 2.34 | 177 | -0.4967 | Estimated |
| `persist_below_ma20_ge10` | 41 | 68.0 | 0.60 | 72 | -0.6053 | Estimated |
| `corr_breakdown_proxy` | 41 | 19.0 | 2.16 | 117 | -0.0312 | Estimated |
| `qqq_m2pct_day` | 36 | 7.0 | 5.14 | 374 | -0.1422 | Estimated |
| `vix_p10pct_day` | 36 | 14.0 | 2.57 | 315 | -0.0576 | Estimated |
| `qqq_5d_m5` | 36 | 15.0 | 2.40 | 154 | -0.2645 | Estimated |

Full clock: `events/event_memory.json` / `reports/event_clock_latest.md`

## GENE POPULATION (seed)

- `CE_PHASEA_A_OPT_EXPR_HYP` state=**INCUBATING** tag=Hypothetical source=phase_a_state_option_expression
- `G3_a7d59b6bd0` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_d66c65392c` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_cc503b9df9` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_7854c5374f` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_c6eaa597ca` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_406aac1291` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_c4128fe574` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_57852a001e` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_d710d8902e` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_f30785e35f` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_72cc71ab08` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_bfa5c9b198` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_4e82a93d7d` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_3ff63c561f` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_fadc5309a0` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_9fe864b85d` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_cc8b24ff1f` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_1d26325fd6` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_71c7705a70` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_eac2ab0c8b` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_f6127fd939` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_8d86d2f086` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_71e4dfc223` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_c30423290b` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_a695a76a03` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_10e78f1556` state=**WEAKENING** tag=Observed source=hypothesis_lab_grid
- `G3_96fe8d0d30` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_e6646775ee` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_b01fad5c46` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_85dbc2f66b` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_266b0e662b` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_011c814e44` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_f3ec209fc8` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_e265f6af7d` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_5452707361` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_28d2e7b1a2` state=**WEAKENING** tag=Observed source=hypothesis_lab_grid
- `G3_df5957463f` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_4f999b09bb` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_8087a83f92` state=**WEAKENING** tag=Observed source=hypothesis_lab_grid
- `G3_544eda743f` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_2116f652bf` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_b895fc0c37` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_58d3633955` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_69399240ae` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_8ba93b9a62` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_2471831b34` state=**ACTIVE** tag=Observed source=hypothesis_lab_grid
- `G3_2fb8ff80e1` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_21f2d77a2c` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_c6b2e5f65f` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_aeab9a11a1` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_20adbe09cc` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_8a786cbff2` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_aec101531a` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_51f3e81326` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_8b521c8506` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_3830768399` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_bd068be378` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_0a69a9c76d` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_286a245618` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_6590d9bb28` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_78a5e64a08` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_18f010a343` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_d618a662b7` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_b422e76c2f` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_fe0c322b05` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_6d265260e3` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_2390ae7565` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_ca42ab29c8` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_dabb10454a` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_de45dbb49c` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_f62633f489` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_744ee4dccd` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_9ec389ed0e` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_16ce164c99` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_b71a55240d` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_d46af443c3` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_7d92ebad5b` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_b913f8719a` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_64af865d23` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_a9258f2aa0` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_fa99cbbf60` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_a36c6119f1` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_8d69e54a11` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_30f841599f` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_88109f0255` state=**WEAKENING** tag=Observed source=hypothesis_lab_grid
- `G3_6dd639c114` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_5a66fb4390` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_47b222a921` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_3d5848c9bf` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_e7b5fa2c2c` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_724204876d` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_a99a8d41ae` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_639f4cf438` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_e5538882bf` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_70bba32b45` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_33cca1f16c` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_c32ce0766f` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_bdc24f3126` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_8afc4d7cc6` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_abae477940` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_0ae2ad911d` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_4644b9497c` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_3619175cb7` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_bae7cb4f5e` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_50c182bc13` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_bf1603e330` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_8a52d8b880` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_de12324cc5` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_9cfa0335cf` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_d15a228b21` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_5098f31f79` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_4559d068a9` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_205ffd7fde` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_23a834455e` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_7294aa96b6` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_a666d2f0cf` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_6dea1b2223` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_1cc289bf25` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_a33b8a692e` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_d770d8ebd7` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_44041db95f` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_e5a5a0d09b` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_db75879581` state=**WEAKENING** tag=Observed source=hypothesis_lab_grid
- `G3_35c1d7c5eb` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_de4d773cae` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_c3af74bc78` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_4e75dcae02` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_c718b83b21` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_c58a16a8a7` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_e1ad86df16` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_467b9af542` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_b575437d3d` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_f052b339af` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_ce7f6a4c62` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_d685089cd9` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_987603ea6b` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_c6f5a459cf` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_da78281e6e` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_68198a1db4` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_0274ad4fb0` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_b6796e5a95` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_d28b48362c` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_7b76b72999` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_7b0fc05966` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_401fc43e2e` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_87204c00c0` state=**WEAKENING** tag=Observed source=hypothesis_lab_grid
- `G3_a315431a18` state=**WEAKENING** tag=Observed source=hypothesis_lab_grid
- `G3_924dd2ccbf` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_f7daca6361` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_80c80eefd6` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_f9a901e207` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_5265a70bfc` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_ffa5a34e29` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_ad01768fb7` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_7fe0d5b125` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_d6f7ce5ea6` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_042b8fbf85` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_acadea324b` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_1ace8a6c21` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_2c537ee82f` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_ca68d591fb` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_5b05b6aea8` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_ede0c6c0f3` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_387723d3e5` state=**ACTIVE** tag=Observed source=hypothesis_lab_grid
- `G3_443ce5cfbb` state=**WEAKENING** tag=Observed source=hypothesis_lab_grid
- `G3_55e8699363` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_04e5dc4e9c` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_0367e31a19` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_faf3216ccf` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_87f17fb948` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_bbc7b46724` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_9d1ed4220b` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_ce044d9b06` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_0a6c387a57` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_dfef1b2e3d` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_a6d95564a5` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_4759c6cc26` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_33ce45dbb0` state=**WEAKENING** tag=Observed source=hypothesis_lab_grid
- `G3_afd1288c76` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_0cf8bc4b1e` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_fd9c6553be` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_1502e78d29` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_effaff7b7d` state=**ACTIVE** tag=Observed source=hypothesis_lab_grid
- `G3_a5d9205b16` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_a85632d4dc` state=**WEAKENING** tag=Observed source=hypothesis_lab_grid
- `G3_aa2707e1db` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_fa84ba286f` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_1b48281c14` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_b32a49e7ad` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_b5cec8dfd2` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_b8b88efe7b` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_c481b809fe` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_e5977817ae` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_aff476b135` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_2bc49d6d8f` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_2d6a54e9bc` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_9e5ae4d709` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_36fafd9ac5` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_b33630ffd2` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_2ca7601045` state=**WEAKENING** tag=Observed source=hypothesis_lab_grid
- `G3_bb9e719cb1` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_72710fd273` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_8663bbd748` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_ea1ef49a58` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_989212f0ff` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_18490c4301` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_d574fb5b15` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_06692ef726` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_f4cc07c313` state=**ACTIVE** tag=Observed source=hypothesis_lab_grid
- `G3_ba9210e27a` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_ad105f62ac` state=**ACTIVE** tag=Observed source=hypothesis_lab_grid
- `G3_0b374dbdc2` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_1921349ee4` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_ade36f03ec` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_fcdcd4e680` state=**ACTIVE** tag=Observed source=hypothesis_lab_grid
- `G3_24cfab753f` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_fc38ca144c` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_90933b1ce4` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_9cb7f9060d` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_c43a5b11c4` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_10e312f71c` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_ef4bd77f63` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_387bd63f8e` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_05318f6227` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_caec38eb52` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_8cc8b23b56` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_cee864f3a4` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_00178b6c26` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_4bd6574de5` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_55949d8d74` state=**WEAKENING** tag=Observed source=hypothesis_lab_grid
- `G3_b5df9e74e8` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_7d82d3c8dd` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_9449cb6b5a` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_ef870faa08` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_4cc84ca050` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_502b705636` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_34a3806d11` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_41f8b0d4bc` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_362de1de5e` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_d514ea5474` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_0d2a4354a2` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_dfba1c64d2` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_cc5416a872` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_f5bc8224c6` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_62402a3845` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_cfede7ade4` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_90efd719de` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_7bf3068893` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_24bd9bc6f3` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_a6359bf225` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_b97c581186` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_8f624100b0` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_0cbc47ab54` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_51e26fbd22` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_28757e862e` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_e1ccbae232` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_23a5fe9602` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_aa58ee2147` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_4283363807` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_5105020e50` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_901046b38a` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_409983c4f8` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_4840011090` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_0b97d31a6f` state=**WEAKENING** tag=Observed source=hypothesis_lab_grid
- `G3_d185a2e3e3` state=**WEAKENING** tag=Observed source=hypothesis_lab_grid
- `G3_314c921806` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_2e4abfee98` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_e4651c3eb5` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_3fd378882d` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_99c8b969f6` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_b71405267c` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_60486f205b` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_1c90b06bbf` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_8ab8a8d980` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_2497d720b4` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_00564c9836` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_f254ee64fc` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_ca27f7e0a0` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_08260b408a` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_2b62d0b7bd` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_8aeb38afe8` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_a04520d724` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_10f39df5d5` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_ae51c29f7c` state=**WEAKENING** tag=Observed source=hypothesis_lab_grid
- `G3_2c5cf45ded` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3_5ca5cb0397` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_11487d97a4` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_fe59f2c924` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_54ddadfa56` state=**DORMANT** tag=Observed source=hypothesis_lab_grid
- `G3_4dc0a7293b` state=**PROMISING** tag=Observed source=hypothesis_lab_grid
- `G3_399d3931ae` state=**TESTING** tag=Observed source=hypothesis_lab_grid
- `G3M_b99d87ae12` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_8299839ac3` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_c7e89edba9` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_b9339671e6` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_51c16f059f` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_216bfe2ab0` state=**DORMANT** tag=Observed source=hypothesis_lab_mutation
- `G3M_4422ef7077` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_e24aa26c8b` state=**DORMANT** tag=Observed source=hypothesis_lab_mutation
- `G3M_16e6e4625f` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_66a6ad5d55` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_2013f5decf` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_e384deeaec` state=**DORMANT** tag=Observed source=hypothesis_lab_mutation
- `G3M_3f0bab0138` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_ad4d4e79bc` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_e22e330101` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_b6ac32a6e5` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_96b169b02a` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_0479d8d623` state=**DORMANT** tag=Observed source=hypothesis_lab_mutation
- `G3M_00cd46c598` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_eaf5546574` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_e884bbbac7` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_0c6cc9eafd` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_0419a03d4f` state=**WEAKENING** tag=Observed source=hypothesis_lab_mutation
- `G3M_304aac053c` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_490061e37a` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_7cff6f7ea8` state=**DORMANT** tag=Observed source=hypothesis_lab_mutation
- `G3M_0bdc343ca9` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_1c8e9e3287` state=**DORMANT** tag=Observed source=hypothesis_lab_mutation
- `G3M_37ba9a2729` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_d6a56f9b2d` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_0b54dce2f3` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_c03ac8107d` state=**DORMANT** tag=Observed source=hypothesis_lab_mutation
- `G3M_fc27e965db` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_0f331d120d` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_123cf07d2f` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_3b4da4cc3b` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_e34f3b96ba` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_36a29d3cd7` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_14f624e46d` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_a5980f4a8a` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_39a5380248` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_97a70da9c7` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_c048b025e5` state=**DORMANT** tag=Observed source=hypothesis_lab_mutation
- `G3M_348f7b78be` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_364aad7777` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_aed8152aad` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_e3a128a9d7` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_b128011463` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_b6742ded57` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_f2374e9c23` state=**DORMANT** tag=Observed source=hypothesis_lab_mutation
- `G3M_d2998fdd5e` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_aa12d986a3` state=**DORMANT** tag=Observed source=hypothesis_lab_mutation
- `G3M_69c13acda3` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_ca17eaf3f1` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_2ff444969a` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_5a13c5634c` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_2065aa618b` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_770c5cfb46` state=**DORMANT** tag=Observed source=hypothesis_lab_mutation
- `G3M_4dba316bd9` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_bd39fe662e` state=**WEAKENING** tag=Observed source=hypothesis_lab_mutation
- `G3M_68e6eef0ba` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_47d74fc67b` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_7dd5949339` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_8b19ddbb99` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_854364800f` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_671e7a559b` state=**DORMANT** tag=Observed source=hypothesis_lab_mutation
- `G3M_757c888ed4` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_39b3f0cc3e` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_d8abb8dbb1` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_aead9b7a1e` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_6df65d81b2` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_2468396ad5` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_ed2818d7f7` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_d62d25b70c` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_67e8e34948` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_c95604b8bb` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_5be7f2b111` state=**WEAKENING** tag=Observed source=hypothesis_lab_mutation
- `G3M_4dac265b6e` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_db586a3616` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_41d7e4e29c` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_d94ead4adb` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_633d40faa1` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_b255c95c28` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_60c34044cc` state=**WEAKENING** tag=Observed source=hypothesis_lab_mutation
- `G3M_a28e92ce2f` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_9af0f8b3b6` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_8f91cd3594` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_e887fcac2c` state=**ACTIVE** tag=Observed source=hypothesis_lab_mutation
- `G3M_08fc62cbe7` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3M_d8495b00ce` state=**PROMISING** tag=Observed source=hypothesis_lab_mutation
- `G3M_2675077f68` state=**TESTING** tag=Observed source=hypothesis_lab_mutation
- `G3X_78ce9e1ca9` state=**PROMISING** tag=Observed source=hypothesis_lab_crossover
- `G3X_0d6b7a6c9e` state=**DORMANT** tag=Observed source=hypothesis_lab_crossover
- `G3X_e4aeb04536` state=**PROMISING** tag=Observed source=hypothesis_lab_crossover
- `G3X_d664217353` state=**PROMISING** tag=Observed source=hypothesis_lab_crossover
- `G3X_198e52ca50` state=**PROMISING** tag=Observed source=hypothesis_lab_crossover
- `G3X_22b46ffc16` state=**DORMANT** tag=Observed source=hypothesis_lab_crossover
- `G3X_b23f56a30f` state=**TESTING** tag=Observed source=hypothesis_lab_crossover
- `G3X_15a7357437` state=**PROMISING** tag=Observed source=hypothesis_lab_crossover
- `G3X_4862d19d4f` state=**TESTING** tag=Observed source=hypothesis_lab_crossover
- `G3X_d349b759b2` state=**TESTING** tag=Observed source=hypothesis_lab_crossover
- `G3X_ad5bef532e` state=**PROMISING** tag=Observed source=hypothesis_lab_crossover
- `G3X_3d88ace408` state=**TESTING** tag=Observed source=hypothesis_lab_crossover
- `G3X_00ad77ba64` state=**PROMISING** tag=Observed source=hypothesis_lab_crossover
- `G3X_7fa015f240` state=**ACTIVE** tag=Observed source=hypothesis_lab_crossover
- `G3X_388422d6cf` state=**PROMISING** tag=Observed source=hypothesis_lab_crossover
- `G3X_8a95fd3210` state=**TESTING** tag=Observed source=hypothesis_lab_crossover
- `G3X_bfc2750b1e` state=**PROMISING** tag=Observed source=hypothesis_lab_crossover
- `G3X_e9be5eac5f` state=**TESTING** tag=Observed source=hypothesis_lab_crossover
- `G3X_03d9385750` state=**WEAKENING** tag=Observed source=hypothesis_lab_crossover
- `G3X_5dd978f1e9` state=**TESTING** tag=Observed source=hypothesis_lab_crossover
- `G3X_1208b56c15` state=**PROMISING** tag=Observed source=hypothesis_lab_crossover
- `G3X_a36c8c53d5` state=**PROMISING** tag=Observed source=hypothesis_lab_crossover
- `G3X_9031cf3638` state=**PROMISING** tag=Observed source=hypothesis_lab_crossover
- `G3X_ef270b0f41` state=**PROMISING** tag=Observed source=hypothesis_lab_crossover
- `G3X_cc274a2424` state=**TESTING** tag=Observed source=hypothesis_lab_crossover
- `G3X_28f1f9f5fd` state=**ACTIVE** tag=Observed source=hypothesis_lab_crossover
- `G3X_3ad813eaba` state=**PROMISING** tag=Observed source=hypothesis_lab_crossover
- `G3X_8293f35556` state=**TESTING** tag=Observed source=hypothesis_lab_crossover
- `G3X_8e0e17f6e5` state=**TESTING** tag=Observed source=hypothesis_lab_crossover
- `G3X_730ec08d4e` state=**TESTING** tag=Observed source=hypothesis_lab_crossover
- `G3X_784b756fc3` state=**TESTING** tag=Observed source=hypothesis_lab_crossover
- `G3X_02f5169608` state=**PROMISING** tag=Observed source=hypothesis_lab_crossover
- `OPT_STUB_HYP_01` state=**INCUBATING** tag=Hypothetical source=option_library_stub
- `OPT_STUB_HYP_02` state=**INCUBATING** tag=Hypothetical source=option_library_stub
- `OPT_STUB_HYP_03` state=**INCUBATING** tag=Hypothetical source=option_library_stub
- `OPT_STUB_HYP_04` state=**INCUBATING** tag=Hypothetical source=option_library_stub
- `G6_0889ee2d9b` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_13136c639e` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_b25eb6f861` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_6835cfc402` state=**WEAKENING** tag=Observed source=gen2_mutation
- `G6_e6be365db0` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_8e227600d7` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_a6bbd5443a` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_e86ab06e86` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_6d1a9bdc50` state=**ACTIVE** tag=Observed source=gen2_crossover
- `G6_583a43e0f9` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_e9ff8c219c` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_524f592ec1` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_5f312dfa22` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_3500866d5a` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_a8996988c5` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_2e797979e8` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_5b01a2cb65` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_a4c834d7b5` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_bb664143b8` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_17893a387e` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_9da2cd8591` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_790ba96e3a` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_d4d2a5d0ee` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_4d04e7bdf5` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_2c51a7038c` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_ae479af5ee` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_02127ba4ee` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_10d545e1a2` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_619f4e13d0` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_a7f3c96060` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_c7a6c54a33` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_83123eeb90` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_35d9cffad1` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_d5bd3d10e3` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_9b6d37d215` state=**WEAKENING** tag=Observed source=gen2_mutation
- `G6_192cd6a250` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_3e1e5e7c4b` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_abb4039cbf` state=**ACTIVE** tag=Observed source=gen2_crossover
- `G6_1ba528dc81` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_bb4f0eb457` state=**ACTIVE** tag=Observed source=gen2_crossover
- `G6_1634d68d0d` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_6562073bb5` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_20d51ffe0a` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_d226c266fc` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_d99db53abb` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_ceb0585452` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_a147084c9a` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_129a956164` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_871e6e0ca9` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_3916f86446` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_78e8e42d5d` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_b9d1f1dcd4` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_c27e9f3ba3` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_4754210e61` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_5d52717c40` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_bb34307d0e` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_1496388560` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_3fe6fdbc83` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_3dbc0858e8` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_017ac70594` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_6d0141a64b` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_3d406a63fa` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_8d68592a91` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_2484ddc017` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_c8736cbfac` state=**ACTIVE** tag=Observed source=gen2_mutation
- `G6_29da2fc4f3` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_8ce7589b87` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_563b7d4e6f` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_cab0788aa1` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_1973a000c3` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_e2411a179d` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_bc9dd07492` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_1a7af51b7e` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_c5678757ee` state=**WEAKENING** tag=Observed source=gen2_crossover
- `G6_c82610b4c7` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_3c56bfc1f8` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_213af41869` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_b801fc96e3` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_b4ba8b1792` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_109062dd31` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_3749ba9a32` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_3b36b31174` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_cd0eb38821` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_65d2c6a2b2` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_4338ce7458` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_9f86c6dd29` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_301e3e151e` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_704caea687` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_7e150b31ee` state=**ACTIVE** tag=Observed source=gen2_crossover
- `G6_4b0b3e21b0` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_ab01076a54` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_2d9a985b42` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_df6a2638f4` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_3c03d44774` state=**WEAKENING** tag=Observed source=gen2_mutation
- `G6_a935cea0da` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_e1d4de372f` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_c1057de329` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_025ae70be3` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_085e34f46d` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_6c2bfa41c0` state=**WEAKENING** tag=Observed source=gen2_crossover
- `G6_8f78df82b2` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_9d6d4ec4df` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_2164f1fc70` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_c09d1d2663` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_7a9a799580` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_35daa0e7f2` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_ece0b91465` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_f1aeada88d` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_8ba77124d5` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_0acecbb33f` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_60c1688aa5` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_365994106a` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_ce9258819c` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_f2bb382677` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_a2c9eb2426` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_1a9e7b586c` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_2e88251257` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_a87c29c114` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_dc639294f1` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_374cdbfda7` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_aee79671b5` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_98d2d6e836` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_bacfa41447` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_c3ecab6186` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_f66657fd16` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_45b98587aa` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_8591e5fc2d` state=**ACTIVE** tag=Observed source=gen2_crossover
- `G6_2418a6f9d3` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_7c9008daea` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_1d99675de2` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_697ee4cf43` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_79f1e74df2` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_6b3da81930` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_0fd585090a` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_e0dce7ab9f` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_2a1d06058b` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_bab759802d` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_b8f3eae338` state=**WEAKENING** tag=Observed source=gen2_mutation
- `G6_ad55dbf31f` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_d7a93e655d` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_5e9abe8b7e` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_52c1d6b1db` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_7bf7ad3186` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_11d3eee40c` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_97055080bb` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_656de5327a` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_df8ecff968` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_1e935e7dcc` state=**ACTIVE** tag=Observed source=gen2_crossover
- `G6_66efec0e49` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_545fd803df` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_b545cb9c2d` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_2a6326e632` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_8300107017` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_60e29c8cee` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_ee695fa275` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_460902cfc9` state=**ACTIVE** tag=Observed source=gen2_mutation
- `G6_b1e4f314dd` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_5fe4569c46` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_3b27e6d50c` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_0517b9a148` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_cc07d0d4d6` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_96edc9f227` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_096bb4d518` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_f3bcdddd2f` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_b1560e54dc` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_e57063e16e` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_6b2f421ff0` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_40ca1197a8` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_57908a3820` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_2d51b37b9f` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_19742e9b4b` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_80548836be` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_b426c139cd` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_8808bf2084` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_06a235ae4e` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_5513f25f60` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_6467c84caf` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_4f5d98aa3c` state=**ACTIVE** tag=Observed source=gen2_crossover
- `G6_04fd8d4e99` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_6a54734301` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_4051e5d10f` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_caed198d03` state=**WEAKENING** tag=Observed source=gen2_crossover
- `G6_4c81425dab` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_415e2e41dc` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_7fcf0384b7` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_987afdf05a` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_4dce2bc2cb` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_ce2c9c334b` state=**WEAKENING** tag=Observed source=gen2_crossover
- `G6_ca5d9d58fd` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_4544cf4599` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_120aa7432f` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_8838db1cb2` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_2fe6d209fe` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_02e026b7d7` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_7478cd2077` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_840c48719c` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_64b9a493fe` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_68f0384adc` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_3bcd7b7f8c` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_a98902b9b2` state=**ACTIVE** tag=Observed source=gen2_mutation
- `G6_bc32660a60` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_506c0b1a7e` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_e08df6052d` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_4d9dce5cd2` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_83eab601f5` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_9ab4218572` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_42f6c4e385` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_ce9c325f93` state=**ACTIVE** tag=Observed source=gen2_crossover
- `G6_f15faa5c09` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_d365f5b834` state=**WEAKENING** tag=Observed source=gen2_mutation
- `G6_183aef100f` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_8bbf02e271` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_2b75de6b16` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_6fad0c31b4` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_0d9e6a7a40` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_0decf973c9` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_6ee951c2e9` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_097a2ab5b5` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_a9f7f7afa7` state=**WEAKENING** tag=Observed source=gen2_mutation
- `G6_980699eef5` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_f8b34411d1` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_193a368310` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_76ceef689b` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_1baf0ffdc0` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_fc99f68322` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_247cc6ef33` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_a775d5e663` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_63f64dd7c0` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_a154a52a3e` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_2b49ab05af` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_e51483a0a3` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_25c4cf4f62` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_a06960a73c` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_c1d08f13bd` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_fe0ac5a401` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_b32385e308` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_1c0056ed52` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_afa3267101` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_324f548efc` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_0ef35257b0` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_a0f2c06aef` state=**WEAKENING** tag=Observed source=gen2_mutation
- `G6_9b7f3d2f85` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_9e49f4c2d7` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_afbf087535` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_c8a2f2b247` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_ba525bd4df` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_5090f0b611` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_5cab5c43e6` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_eb21642dd0` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_17128e8159` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_e604fc7102` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_e7fe2b43a5` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_2adcc05b73` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_725a0c9fe4` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_d85a94d26f` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_f04700cc44` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_97b86d401a` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_99c064d4df` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_451409db62` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_4392f4326f` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_e7776ff1d6` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_6e579b1385` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_ad60e41331` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_6890bd6e38` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_6c6dd5ac50` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_d53ce71b80` state=**ACTIVE** tag=Observed source=gen2_mutation
- `G6_9115de1f79` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_ac196b43ff` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_450876c16d` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_c03b372bbd` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_26df4f7f6a` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_22f79a9c39` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_881dbc7c65` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_211e55b388` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_013a43105f` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_69d60d723f` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_4146b5d243` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_2e0f15648b` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_47e910aeff` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_59160d2bfe` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_5c7bb1b5fa` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_fcb72dbd68` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_65ddaaec46` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_cbdd4aedf5` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_140a86c165` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_ae72451e32` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_26196e1aef` state=**ACTIVE** tag=Observed source=gen2_crossover
- `G6_ca37e8b4c5` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_1166e9e874` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_7488db1622` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_bb66e54f7b` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_41f1c758cc` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_bc47af9a6b` state=**ACTIVE** tag=Observed source=gen2_mutation
- `G6_6c5c6331c8` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_a222b136ed` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_04f42bede7` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_44de45a38b` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_8dac34e561` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_4dee3ac93f` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_c708ae3257` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_0de69f9494` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_3570fef9e2` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_82ae5fe686` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_4ef1850e36` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_ae256112ce` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_0c892fa641` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_137542d8a7` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_f826f54a3e` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_22619cc6e9` state=**ACTIVE** tag=Observed source=gen2_crossover
- `G6_210aa9a3f7` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_e1a6337cb7` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_3f5e92654f` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_b65215e42e` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_62f125d8c8` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_64fd716877` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_ee575b2e69` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_6bd714a7c2` state=**ACTIVE** tag=Observed source=gen2_mutation
- `G6_1659c145c4` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_18e843ee7d` state=**ACTIVE** tag=Observed source=gen2_mutation
- `G6_edd54830b5` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_e7daf52843` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_f1134c6b0d` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_26ef787495` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_305cff8767` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_3cffa7fe53` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_0669dc8385` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_cbc665faa6` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_8011bf42a8` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_4fbaa72639` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_a661cbe5f3` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_7155b4fd30` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_8d7bde6478` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_4183fc237f` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_b907df50ca` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_fd27d5ebe7` state=**ACTIVE** tag=Observed source=gen2_crossover
- `G6_cf845d2f28` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_28cb066313` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_18fbf76cfc` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_a7437a7dd5` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_2782827186` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_eebcd43fc3` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_174ded5b9c` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_51d9181fc2` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_bfe80b54ff` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_b0d10a401a` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_e1e136101e` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_910fd47867` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_f6fc737485` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_bef10d3b41` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_cfac2b3a9c` state=**WEAKENING** tag=Observed source=gen2_crossover
- `G6_e7069397af` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_9412cd0dfb` state=**WEAKENING** tag=Observed source=gen2_mutation
- `G6_df03c4a3e9` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_d5071dff9e` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_ea7998cf4d` state=**WEAKENING** tag=Observed source=gen2_crossover
- `G6_731d54d9e7` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_da303f0c87` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_44166aa529` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_bfaa7dc939` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_f03de7ac57` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_a448210673` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_e957a37d6e` state=**WEAKENING** tag=Observed source=gen2_mutation
- `G6_eff3fdf195` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_9cc4f23e1f` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_379a554dfa` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_2663ff0c79` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_ad4807c633` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_3ac89305ee` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_e2ab4d178a` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_fc44d4388f` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_983ea11ef8` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_4dfe61e54f` state=**WEAKENING** tag=Observed source=gen2_mutation
- `G6_b0969af556` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_8586f0c869` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_bf883c38ab` state=**WEAKENING** tag=Observed source=gen2_mutation
- `G6_b28f6c47ab` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_3d082b33e3` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_c5414909bb` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_ac6a38d2dc` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_918e6489a9` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_bbafb2726a` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_bfbee0f3f0` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_33fa0a7ade` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_9347f9d6cc` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_2d1ba94f4f` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_9315d9b26a` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_375ea8ac50` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_ca2ec49b33` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_966862c6b8` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_665a897642` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_9b60e3cd91` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_984fd2040c` state=**WEAKENING** tag=Observed source=gen2_mutation
- `G6_286233b1ea` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_5dd023b221` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_a1234cf405` state=**ACTIVE** tag=Observed source=gen2_mutation
- `G6_ce80896785` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_e57b94c48f` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_0a93c59e86` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_4c32a9e66f` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_aab768862f` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_d1b9501b84` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_1676f557cb` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_37643383c4` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_9f306d6f9a` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_5b7953cc74` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_ee85751b49` state=**WEAKENING** tag=Observed source=gen2_mutation
- `G6_ab77ab0727` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_fa5984baed` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_2b3dfbdeac` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_977267f32e` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_52388ce669` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_3b94923074` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_739077da98` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_ffd3e30acb` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_518c311998` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_9362db47a6` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_33ec450e06` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_144538a6c4` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_739971b6f4` state=**ACTIVE** tag=Observed source=gen2_mutation
- `G6_6808ff0620` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_6c9a322239` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_8e8b9c590d` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_0c2fd82d1f` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_6ccc0945e2` state=**ACTIVE** tag=Observed source=gen2_crossover
- `G6_06cf84ac18` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_16445f763f` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_463a648b3f` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_fc8ead846c` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_9ea74db674` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_e68b1fcf0b` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_81e4d2485d` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_6c32943b83` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_93e40788b1` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_2d4aa7ea53` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_52f10f4251` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_839726e30b` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_a6516a887e` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_246bdd4a9d` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_6f156d032e` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_fbc381a784` state=**WEAKENING** tag=Observed source=gen2_crossover
- `G6_e84812eec9` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_71cbe9ab0f` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_9b83505914` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_7f6ce0b7cf` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_06ed7fabbf` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_4a2cdd71b4` state=**WEAKENING** tag=Observed source=gen2_mutation
- `G6_95ac8d6772` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_9e50fa1eec` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_8eb86ffef4` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_3a277225e7` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_0a8d855696` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_a3a68d62f4` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_1bda08df80` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_ce9f29d71d` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_295a2dff8a` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_e8cc817e5d` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_b912e541d5` state=**ACTIVE** tag=Observed source=gen2_mutation
- `G6_2ecf856ae7` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_60b823eb07` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_9b2798745d` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_863c6e4d54` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_942a7aed62` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_7c43890d58` state=**TESTING** tag=Observed source=gen2_crossover
- `G6_aaae1860bb` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_66612a4c6a` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_2e39d311f3` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_ffbdaead4f` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_ffc80a3cd1` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_4540aa254c` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_c5496a44f6` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_204922efa1` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_15fbbd4152` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_a6bc5e1aef` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_64f093cbdf` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_ec90a6eced` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_935a66c7fa` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_e11f1ca743` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_c452df270a` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_7b5cc58006` state=**TESTING** tag=Observed source=gen2_mutation
- `G6_bb772a3277` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_4513c5f861` state=**DORMANT** tag=Observed source=gen2_mutation
- `G6_4c91daa8c8` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_71579737f0` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_53bdddfedf` state=**PROMISING** tag=Observed source=gen2_mutation
- `G6_d00ba6ae7b` state=**DORMANT** tag=Observed source=gen2_crossover
- `G6_cd47828253` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_d2e8c150cf` state=**PROMISING** tag=Observed source=gen2_crossover
- `G6_172c636a0a` state=**PROMISING** tag=Observed source=gen2_mutation
- `CE_PHASEA_SOLE_A` state=**INCUBATING** tag=Observed source=rvte_phase_a_survivor_A
- `CE_V01_SPOT_FAMILY_021` state=**INCUBATING** tag=Observed source=evb_evolutionary_report_v0_1_spot_family

**No gene promoted to ACTIVE.**

## NEXT RESEARCH QUESTIONS

1. Given current regime_hints=[] and persist_below_MA20=5, does conditional hazard for winning_state_phase_a rise with age, or is it flat/falling (anti-gambler check)?
2. For pulse events (qqq_m3pct_day, vix_p20pct_day), is P(event|vol_expansion, age) materially different from unconditional P(event|age)?
3. Should CE_PHASEA_SOLE_A remain INCUBATING until secondary OOS n improves, or move only to TESTING with walk-forward gates (never ACTIVE yet)?
4. Which relative features (QQQ/SPY, ShortVolRel, TermSlope) currently diverge from vol_state=neutral, and do historical analogs of that divergence precede turns?
5. OPRA-blocked: until option chains exist, what spot-only adversarial tests (leave-one-crisis, cost×5, anti-signal) should Phase 4 run on the incubating population (n_genes=909) before any promotion?
6. Event `vxx_p20pct_day` is age/median≈172.67 — what is the *conditional* hazard in the current regime, and does it justify any research attention without treating overdue as a buy?

## Artifacts

- `data/market_data.parquet` + `data/DATA_MANIFEST.json`
- `state/market_state.json`
- `events/event_memory.json`
- `events/event_combos.json`
- `genes/gene_population.json`
- `docs/MASTER_PROMPT_v2.md`, `docs/PHASES.md`, `docs/HONESTY.md`
- Blueprint: `docs/EVB_BRAIN_BLUEPRINT_V0_2.md`

