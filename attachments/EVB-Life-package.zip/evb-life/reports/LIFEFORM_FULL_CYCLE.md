# EVB LIFEFORM — FULL CYCLE (Phase 1–11)

Generated UTC: 2026-09-04T03:37:58.339045+00:00
Root: `/workspace/evb-life`

## 傳統中文摘要

- 全週期已跑完 Phase 1–11；基因測試約 **14113**。
- 狀態：`{"INCUBATING": 5, "PROMISING": 360, "TESTING": 327, "WEAKENING": 41, "DORMANT": 143, "ACTIVE": 31}`
- ACTIVE=31 PROMISING=360 pop=907 dead_bank=13211
- 期權前沿：blocked / Hypothetical catalog only；禁止 BS fitness。
- Shadow 無真金；Risk Auction 為 Estimated stub。

## 1 MARKET STATE

See Phase1–2 / Phase3–6 reports. Phase3–6 report: `/workspace/evb-life/reports/cycle_phase3_6_20260903.md`

## 2 NEW DISCOVERIES

- Explosion + gen2; tested=14113
- Phase3 summary: `{"generated_utc": "2026-09-04T03:37:18.246058+00:00", "grid_unique": 10075, "born_grid": 10000, "mutations": 1237, "crossovers": 374, "option_stubs_incubating": 4, "population_size": 11618, "mechanism_tag_counts": {"trend_persist": 5675, "meanrev_fail": 6998, "vol_rel": 9895, "term": 8545}, "target": 10000, "evidence": "Derived genomes from Observed features; option stubs Hypothetical"}`

## 3 TOP GENES

- ACTIVE: ['G3_2471831b34', 'G3_387723d3e5', 'G3_effaff7b7d', 'G3_f4cc07c313', 'G3_ad105f62ac', 'G3_fcdcd4e680', 'G3M_e887fcac2c', 'G3X_7fa015f240', 'G3X_28f1f9f5fd', 'G6_6d1a9bdc50', 'G6_abb4039cbf', 'G6_bb4f0eb457', 'G6_c8736cbfac', 'G6_7e150b31ee', 'G6_8591e5fc2d', 'G6_1e935e7dcc', 'G6_460902cfc9', 'G6_4f5d98aa3c', 'G6_a98902b9b2', 'G6_ce9c325f93', 'G6_d53ce71b80', 'G6_26196e1aef', 'G6_bc47af9a6b', 'G6_22619cc6e9', 'G6_6bd714a7c2', 'G6_18e843ee7d', 'G6_fd27d5ebe7', 'G6_a1234cf405', 'G6_739971b6f4', 'G6_6ccc0945e2', 'G6_b912e541d5']
- PROMISING (first 20): ['G3_a7d59b6bd0', 'G3_406aac1291', 'G3_c4128fe574', 'G3_57852a001e', 'G3_f30785e35f', 'G3_72cc71ab08', 'G3_bfa5c9b198', 'G3_4e82a93d7d', 'G3_9fe864b85d', 'G3_266b0e662b', 'G3_5452707361', 'G3_69399240ae', 'G3_21f2d77a2c', 'G3_c6b2e5f65f', 'G3_bd068be378', 'G3_b422e76c2f', 'G3_2390ae7565', 'G3_744ee4dccd', 'G3_b71a55240d', 'G3_3d5848c9bf']

## 4 FAILED GENES

- dead_gene_bank size: 13211 (never deleted)

## 5 RESURRECTED

- schedule_n: 13354
- resurrected: []
- regime_hints: []

## 6 TURNING BOUNDARIES

_See cycle_phase3_6 report for persist_age boundary notes (Derived)._

## 7 EVENT CLOCK

_See `events/event_memory.json` / phase1_2 report._

## 8 OPTION STRUCTURE FRONTIER

**OPTION STRUCTURE FRONTIER = blocked / Hypothetical catalog only**
- n_structures=15 stubs=144 theoretical_grid=6300
- evidence_tag=Hypothetical / OPRA-blocked / fitness_scoring=FORBIDDEN

## 9 RISK TRANSFER / RISK AUCTION

- N/A spot phase
- allocations_n=391 live_capital=0
- regime_state_probs (Estimated): {'persistent_drawdown': 0.125, 'vol_expansion': 0.18749999999999997, 'baseline': 0.6875}

## 10 PARETO / SHADOW

- shadow entries: 391 asof=2026-09-03 capital=0
- path: `shadow/shadow_book.json`

## 11 OOS / COST / TAIL

_Detailed tables in `reports/cycle_phase3_6_*.md` sections 11–13._

## 12 COST ROBUSTNESS

_See Phase 3–6 report §12._

## 13 TAIL RISK

_See Phase 3–6 report §13._

## 14 LIVE CANDIDATES

- true ACTIVE: ['G3_2471831b34', 'G3_387723d3e5', 'G3_effaff7b7d', 'G3_f4cc07c313', 'G3_ad105f62ac', 'G3_fcdcd4e680', 'G3M_e887fcac2c', 'G3X_7fa015f240', 'G3X_28f1f9f5fd', 'G6_6d1a9bdc50', 'G6_abb4039cbf', 'G6_bb4f0eb457', 'G6_c8736cbfac', 'G6_7e150b31ee', 'G6_8591e5fc2d', 'G6_1e935e7dcc', 'G6_460902cfc9', 'G6_4f5d98aa3c', 'G6_a98902b9b2', 'G6_ce9c325f93', 'G6_d53ce71b80', 'G6_26196e1aef', 'G6_bc47af9a6b', 'G6_22619cc6e9', 'G6_6bd714a7c2', 'G6_18e843ee7d', 'G6_fd27d5ebe7', 'G6_a1234cf405', 'G6_739971b6f4', 'G6_6ccc0945e2', 'G6_b912e541d5']
- report: `/workspace/evb-life/reports/live_candidates.md`

## 15 SHADOW CANDIDATES (PROMISING)

- n=360 ids sample: ['G3_a7d59b6bd0', 'G3_406aac1291', 'G3_c4128fe574', 'G3_57852a001e', 'G3_f30785e35f', 'G3_72cc71ab08', 'G3_bfa5c9b198', 'G3_4e82a93d7d', 'G3_9fe864b85d', 'G3_266b0e662b', 'G3_5452707361', 'G3_69399240ae', 'G3_21f2d77a2c', 'G3_c6b2e5f65f', 'G3_bd068be378', 'G3_b422e76c2f', 'G3_2390ae7565', 'G3_744ee4dccd', 'G3_b71a55240d', 'G3_3d5848c9bf', 'G3_e7b5fa2c2c', 'G3_639f4cf438', 'G3_8afc4d7cc6', 'G3_abae477940', 'G3_4644b9497c']

## 16 NEXT RESEARCH QUESTIONS

1. Which resurrected genes keep OOS>0 after cost×2 on the latest window?
2. Does regime_similarity threshold 0.55 over-trigger false resurrection?
3. Gen3: mutate underrepresented mechanism tags only?
4. Secondary OOS (2023+) sign-flip rate among PROMISING?
5. Shadow would_enter_today cluster — correlated entries risk?
6. Risk auction: should PROMISING get zero budget until ACTIVE?
7. OPRA: priority parent list for option expression (still Hypothetical)?
8. Anti-signal families that repeatedly also-pass → retire mechanism?
9. Event-clock pulse proximity vs entry EV (Estimated conditional)?
10. Walk-forward expanding window stability of top fitness genes?

## 17 COMPUTE ALLOCATION FOR NEXT ROUND

- Tested this full cycle: **14113** (8k–12k+gen2 class if <20k).
- Next compute: PROMISING walk-forward depth > new random grid.
- Resurrection retests weekly per next_review schedule.
- No BS option scoring until OPRA EOD.

## Artifact index

- `/workspace/evb-life/reports/cycle_phase3_6_20260903.md`
- `/workspace/evb-life/reports/live_candidates.md`
- `/workspace/evb-life/shadow/shadow_book.json`
- `/workspace/evb-life/risk/risk_budget.json`
- `/workspace/evb-life/options/option_library.json`
- `/workspace/evb-life/genes/gene_population.json`
- `/workspace/evb-life/genes/candidate_pool.json`
- `/workspace/evb-life/genes/dead_gene_bank.json`


---

## POST-HOC STRICT ACTIVE GATES (honesty)

After first pass produced too many ACTIVE under loose gates, gates were tightened
(OOS tlike>1, walk-forward lite, secondary means, ES/MDD caps, fitness floor).

- demoted_from_loose_ACTIVE: 284
- strict ACTIVE n: 31
- PROMISING n: 360
- state_counts: {"INCUBATING": 5, "PROMISING": 360, "TESTING": 327, "WEAKENING": 41, "DORMANT": 143, "ACTIVE": 31}
- Updated UTC: 2026-09-04T03:37:58.033046+00:00

ACTIVE ids: ['G3_2471831b34', 'G3_387723d3e5', 'G3_effaff7b7d', 'G3_f4cc07c313', 'G3_ad105f62ac', 'G3_fcdcd4e680', 'G3M_e887fcac2c', 'G3X_7fa015f240', 'G3X_28f1f9f5fd', 'G6_6d1a9bdc50', 'G6_abb4039cbf', 'G6_bb4f0eb457', 'G6_c8736cbfac', 'G6_7e150b31ee', 'G6_8591e5fc2d', 'G6_1e935e7dcc', 'G6_460902cfc9', 'G6_4f5d98aa3c', 'G6_a98902b9b2', 'G6_ce9c325f93', 'G6_d53ce71b80', 'G6_26196e1aef', 'G6_bc47af9a6b', 'G6_22619cc6e9', 'G6_6bd714a7c2', 'G6_18e843ee7d', 'G6_fd27d5ebe7', 'G6_a1234cf405', 'G6_739971b6f4', 'G6_6ccc0945e2', 'G6_b912e541d5']

