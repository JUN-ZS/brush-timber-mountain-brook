# EVB LIFEFORM Cycle Phase 3–6 — 2026-09-03

Generated UTC: 2026-09-04T03:37:23.105815+00:00
Root: `/workspace/evb-life`

## 傳統中文摘要

- 本輪 Phase 3–6：基因爆炸 → 批量回測 → 穩健性 → 進化；測試約 **14113** 條。
- 狀態計數：`{"INCUBATING": 5, "ACTIVE": 315, "TESTING": 327, "WEAKENING": 41, "DORMANT": 143, "PROMISING": 76}`
- ACTIVE：315；PROMISING：76；dead_bank=13211。
- Fitness ≠ CAGR；期權僅 Hypothetical 目錄；不過度宣稱。
- 標籤：Observed 現貨報酬 / Derived 特徵 / Estimated 適性與 hazard / Hypothetical 期權。

## 1 MARKET STATE

```json
{
  "asof": "2026-09-03",
  "prices": {
    "QQQ": 717.6699829101562,
    "VIX": 14.319999694824219,
    "VIX3M": 17.420000076293945,
    "VIX9D": 11.680000305175781,
    "VIX6M": 19.780000686645508,
    "VXX": null,
    "SPY": 773.1699829101562,
    "TLT": 82.06999969482422
  },
  "trend": {
    "label": "below_MA20",
    "MA20": 717.7140014648437,
    "MA50": 711.0333996582032,
    "QQQ_over_MA20": -6.133160924493009e-05,
    "QQQ_over_MA50": 0.009333715202609838,
    "QQQ_ret1": 0.011885952275470846,
    "DD20": -0.019670283265251998,
    "DD60": -0.034329762329571745
  },
  "relative_vol": {
    "label": "neutral",
    "RV5": 0.14779744441401665,
    "RV20": 0.13536425169070648,
    "RV5_over_RV20": 1.0918498980936173,
    "VolPremium": 1.0578863707342732,
    "VolPremium_z": 0.002046689928206339,
    "TermSlope": 1.2164804781797713,
    "backwardation": 0.0,
    "ShortVolRel": 0.8156424967940026
  },
  "persistence": {
    "persist_below_MA20": 5,
    "consec_down": 0,
    "mom2": 0.01417382857681071,
    "mom2_improve": true,
    "QQQ_1d_up": true,
    "VolPremium_z_falling": true,
    "ShortVolRel_falling": false
  },
  "regime_hints": []
}
```

## 2 NEW DISCOVERIES

- Phase3 born≈10000 + mut=1237 + xo=374
- Population size after explosion: 11618
- Mechanism tags: {'trend_persist': 5675, 'meanrev_fail': 6998, 'vol_rel': 9895, 'term': 8545}
- Gen2 children: 2500

## 3 TOP GENES

- `G3_a7d59b6bd0` **ACTIVE** fit=0.030566324221717095 IS n=79 mean=0.003582023289719452 | OOS n=26 mean=0.02723864703685328
- `G3_406aac1291` **ACTIVE** fit=0.03460215257101912 IS n=77 mean=0.004877083153892717 | OOS n=28 mean=0.025580992895235743
- `G3_c4128fe574` **ACTIVE** fit=0.033650285522452354 IS n=83 mean=0.004222023625145173 | OOS n=29 mean=0.02646386317128729
- `G3_57852a001e` **ACTIVE** fit=0.03830471989163644 IS n=76 mean=0.004975733330916478 | OOS n=28 mean=0.03101848631783369
- `G3_f30785e35f` **ACTIVE** fit=0.0394290580534891 IS n=80 mean=0.006736772522599273 | OOS n=31 mean=0.023572148034992378
- `G3_72cc71ab08` **ACTIVE** fit=0.036357481373333216 IS n=77 mean=0.004456190522458614 | OOS n=28 mean=0.03101848631783369
- `G3_bfa5c9b198` **ACTIVE** fit=0.029550530953746924 IS n=89 mean=0.005672003710392921 | OOS n=34 mean=0.014842865169216065
- `G3_4e82a93d7d` **ACTIVE** fit=0.04767972767897069 IS n=86 mean=0.008666389509476248 | OOS n=30 mean=0.019243038579764938
- `G3_9fe864b85d` **ACTIVE** fit=0.05649336944052642 IS n=84 mean=0.012262631769588698 | OOS n=27 mean=0.017687044350671654
- `G3_266b0e662b` **ACTIVE** fit=0.04132190875384568 IS n=68 mean=0.012523289898263438 | OOS n=19 mean=0.010305305205250753
- `G3_5452707361` **ACTIVE** fit=0.021864802379177102 IS n=64 mean=0.0024267955602929707 | OOS n=23 mean=0.023005685326320996
- `G3_69399240ae` **ACTIVE** fit=0.033186219672050134 IS n=97 mean=0.007572195084154485 | OOS n=35 mean=0.009498561194507255
- `G3_2471831b34` **ACTIVE** fit=0.04350249342735018 IS n=65 mean=0.008948498909485039 | OOS n=18 mean=0.016073106114597342
- `G3_21f2d77a2c` **ACTIVE** fit=0.02866481471472262 IS n=71 mean=0.003501436639343672 | OOS n=27 mean=0.025376382327519438
- `G3_c6b2e5f65f` **ACTIVE** fit=0.025684401067694367 IS n=61 mean=0.005769282128515454 | OOS n=15 mean=0.010502174362691564
- `G3_744ee4dccd` **ACTIVE** fit=0.051572261009274034 IS n=79 mean=0.009643458410292346 | OOS n=29 mean=0.019462185435046235
- `G3_b71a55240d` **ACTIVE** fit=0.053911761100006506 IS n=77 mean=0.009660023832875836 | OOS n=27 mean=0.020759113009218483
- `G3_3d5848c9bf` **ACTIVE** fit=0.034273878369542154 IS n=85 mean=0.008417718495348472 | OOS n=31 mean=0.009631031756702291
- `G3_639f4cf438` **ACTIVE** fit=0.05303869826455162 IS n=63 mean=0.006261580062331792 | OOS n=24 mean=0.03844529416231767
- `G3_8afc4d7cc6` **ACTIVE** fit=0.013301272725097499 IS n=101 mean=0.0015358773443650427 | OOS n=33 mean=0.010654297466655163

## 4 FAILED GENES (sample)

- `CE_PHASEA_SOLE_A` reason=`anti_also_passes;OVERFIT_PROXY_anti_also_passes` resurrect=`revisit if anti-signal fails under new regime features`
- `CE_V01_SPOT_FAMILY_021` reason=`stage1_mean_IS<=0;stage1_kill` resurrect=`if n_IS grows or mean_IS turns positive with same mechanism`
- `G3_153a86945e` reason=`anti_also_passes;OVERFIT_PROXY_anti_also_passes` resurrect=`revisit if anti-signal fails under new regime features`
- `G3_1322eede5c` reason=`stage1_n_IS<25;stage1_kill` resurrect=`if n_IS grows or mean_IS turns positive with same mechanism`
- `G3_440af5ab2f` reason=`no_transition` resurrect=`regime similarity high + retest OOS/cost/anti`
- `G3_7ba58d04ab` reason=`no_transition` resurrect=`regime similarity high + retest OOS/cost/anti`
- `G3_c289a1581f` reason=`no_transition` resurrect=`regime similarity high + retest OOS/cost/anti`
- `G3_f07dc52e7d` reason=`anti_also_passes;OVERFIT_PROXY_anti_also_passes;walk_forward_lite_fail` resurrect=`revisit if anti-signal fails under new regime features`
- `G3_29c6e508b9` reason=`no_transition` resurrect=`regime similarity high + retest OOS/cost/anti`
- `G3_5714772b97` reason=`anti_also_passes;OVERFIT_PROXY_anti_also_passes;walk_forward_lite_fail` resurrect=`revisit if anti-signal fails under new regime features`
- `G3_83a846a3f4` reason=`anti_also_passes;OVERFIT_PROXY_anti_also_passes` resurrect=`revisit if anti-signal fails under new regime features`
- `G3_c32902b152` reason=`anti_also_passes;OVERFIT_PROXY_anti_also_passes` resurrect=`revisit if anti-signal fails under new regime features`

## 5 RESURRECTED

_Stub schedule — full Phase 7 runs in cycle_full._

## 6 TURNING BOUNDARIES

- Among positive IS-mean genes, persist_age values observed: [3, 5, 7, 10, 15, 20] (Derived)

## 7 EVENT CLOCK snapshot

| event_id | days_since | median_IS | n_IS |
|---|---:|---:|---:|
| `vxx_p20pct_day` | 518 | 3.0 | 2 |
| `qqq_5d_m8` | 517 | 17.5 | 63 |
| `vix_above_40` | 511 | 17.5 | 21 |
| `dd20_m10` | 504 | 13.0 | 91 |
| `qqq_vxx_rel_shock` | 182 | 26.0 | 8 |
| `vxx_p10pct_day` | 181 | 39.0 | 8 |
| `vix_above_30` | 160 | 27.0 | 49 |
| `term_backwardation` | 149 | 13.0 | 110 |
| `vix_above_25` | 149 | 17.5 | 101 |
| `vix_p20pct_day` | 90 | 42.0 | 69 |
| `qqq_m3pct_day` | 72 | 8.0 | 196 |
| `dd20_m4` | 43 | 20.0 | 196 |

## 8 OPTION STRUCTURE FRONTIER

**blocked / Hypothetical catalog only** — no BS option P/L as fitness. OPRA-blocked.

## 9 RISK TRANSFER

N/A spot phase

## 10 PARETO FRONTIER (EV vs |ES| vs n)

| gene_id | EV(mean IS) | |ES5| | n | fitness | state |
|---|---:|---:|---:|---:|---|
| `G3M_3f0bab0138` | 0.031146141396446825 | 0.2003436142651815 | 25 | 0.09738700634195775 | TESTING |
| `G3X_8e0e17f6e5` | 0.031146141396446825 | 0.2003436142651815 | 25 | 0.09738700634195775 | TESTING |
| `G6_a6bc5e1aef` | 0.031146141396446825 | 0.2003436142651815 | 25 | 0.09738700634195775 | TESTING |
| `G3_c6f5a459cf` | 0.024848485433553023 | 0.2003436142651815 | 25 | 0.09577890414140039 | TESTING |
| `G3_dabb10454a` | 0.02069970366873011 | 0.2003436142651815 | 26 | 0.08386842986520399 | TESTING |
| `G3_d66c65392c` | 0.02465839078478943 | 0.2003436142651815 | 26 | 0.08303674858537 | TESTING |
| `G3M_0f331d120d` | 0.02465839078478943 | 0.2003436142651815 | 26 | 0.08303674858537 | TESTING |
| `G3M_2675077f68` | 0.02465839078478943 | 0.2003436142651815 | 26 | 0.08303674858537 | TESTING |
| `G3X_730ec08d4e` | 0.02465839078478943 | 0.2003436142651815 | 26 | 0.08303674858537 | TESTING |
| `G3M_c7e89edba9` | 0.025080479654890016 | 0.17044869956615483 | 26 | 0.08279629061302267 | TESTING |
| `G3M_aead9b7a1e` | 0.025080479654890016 | 0.17044869956615483 | 26 | 0.08279629061302267 | TESTING |
| `G3_cc503b9df9` | 0.024050309024606146 | 0.2003436142651815 | 26 | 0.08200650447263015 | TESTING |
| `G3X_3d88ace408` | 0.024050309024606146 | 0.2003436142651815 | 26 | 0.08200650447263015 | TESTING |
| `G3X_784b756fc3` | 0.024050309024606146 | 0.2003436142651815 | 26 | 0.08200650447263015 | TESTING |
| `G3_6d265260e3` | 0.02291750547265204 | 0.159160944801585 | 26 | 0.08196960769442099 | TESTING |
| `G3M_fc27e965db` | 0.021601199342968114 | 0.2003436142651815 | 25 | 0.08104879239782692 | TESTING |
| `G3M_d62d25b70c` | 0.021601199342968114 | 0.2003436142651815 | 25 | 0.08104879239782692 | TESTING |
| `G3_924dd2ccbf` | 0.016353596085421942 | 0.1341015417648952 | 35 | 0.08103083206105548 | TESTING |
| `G3_b6796e5a95` | 0.013031209694501802 | 0.2222224983371237 | 36 | 0.08062277103038541 | TESTING |
| `G6_8591e5fc2d` | 0.015946668824570794 | 0.16404843146225448 | 73 | 0.07958569671322133 | ACTIVE |
| `G3_c481b809fe` | 0.01742051516756153 | 0.1389134846183066 | 25 | 0.07919175195575306 | TESTING |
| `G6_ee575b2e69` | 0.01742051516756153 | 0.1389134846183066 | 25 | 0.07919175195575306 | TESTING |
| `G6_33fa0a7ade` | 0.01742051516756153 | 0.1389134846183066 | 25 | 0.07919175195575306 | TESTING |
| `G3_70bba32b45` | 0.012884324428912526 | 0.1593898393559381 | 30 | 0.07804592062429194 | TESTING |
| `G3M_16e6e4625f` | 0.020735653489346285 | 0.20152839623304125 | 28 | 0.07711656505873415 | TESTING |

## 11 OOS RESULTS

- Genes with OOS n≥12 and mean>0: **438** (Observed forwards)
- `G6_8591e5fc2d` OOS n=26 mean=0.029052566795579847 wr=0.7692307692307693 state=ACTIVE
- `G6_6d1a9bdc50` OOS n=28 mean=0.021823530082575877 wr=0.7857142857142857 state=ACTIVE
- `G6_7e150b31ee` OOS n=28 mean=0.02065954417826681 wr=0.75 state=ACTIVE
- `G6_ce9c325f93` OOS n=20 mean=0.02763309282916241 wr=0.75 state=ACTIVE
- `G3_387723d3e5` OOS n=16 mean=0.026841075699186735 wr=0.625 state=ACTIVE
- `G3_f4cc07c313` OOS n=16 mean=0.026841075699186735 wr=0.625 state=ACTIVE
- `G3X_7fa015f240` OOS n=16 mean=0.026841075699186735 wr=0.625 state=ACTIVE
- `G6_871e6e0ca9` OOS n=12 mean=0.04083744477714258 wr=0.75 state=PROMISING
- `G3M_97a70da9c7` OOS n=30 mean=0.023255588686005094 wr=0.7666666666666667 state=ACTIVE
- `G3X_a36c8c53d5` OOS n=21 mean=0.023306182017173754 wr=0.7619047619047619 state=ACTIVE
- `G6_97b86d401a` OOS n=21 mean=0.023306182017173754 wr=0.7619047619047619 state=ACTIVE
- `G3M_4dba316bd9` OOS n=24 mean=0.02750454637784304 wr=0.7083333333333334 state=ACTIVE
- `G3M_8f91cd3594` OOS n=24 mean=0.02750454637784304 wr=0.7083333333333334 state=ACTIVE
- `G6_0de69f9494` OOS n=12 mean=0.02177374013673226 wr=0.8333333333333334 state=PROMISING
- `G6_324f548efc` OOS n=30 mean=0.023255588686005094 wr=0.7666666666666667 state=ACTIVE

## 12 COST ROBUSTNESS

- survive 5bps: 759 | survive 10bps: 725 (among remaining population)

## 13 TAIL RISK

- `G3_b5cec8dfd2` es95=-0.27563512201231294 maxDD=-1.2838893785863845 n_IS=58
- `G6_ece0b91465` es95=-0.25794895539235596 maxDD=-0.7020660775784259 n_IS=29
- `G6_e6be365db0` es95=-0.2579381696406858 maxDD=-1.007533024178555 n_IS=60
- `G6_e08df6052d` es95=-0.2579381696406858 maxDD=-1.0608695858792676 n_IS=44
- `G6_144538a6c4` es95=-0.2579381696406858 maxDD=-1.0608695858792676 n_IS=44
- `G3_18490c4301` es95=-0.2561582744804634 maxDD=-1.2971792049502204 n_IS=76
- `G6_1a7af51b7e` es95=-0.2561582744804634 maxDD=-1.1755337853693724 n_IS=67
- `G6_4d9dce5cd2` es95=-0.2561582744804634 maxDD=-1.1051584554230116 n_IS=79
- `G6_980699eef5` es95=-0.2561582744804634 maxDD=-1.159994563475074 n_IS=67
- `G6_f04700cc44` es95=-0.2561582744804634 maxDD=-1.099574504830974 n_IS=78

## 14 LIVE CANDIDATES

ACTIVE ids: ['G3_a7d59b6bd0', 'G3_406aac1291', 'G3_c4128fe574', 'G3_57852a001e', 'G3_f30785e35f', 'G3_72cc71ab08', 'G3_bfa5c9b198', 'G3_4e82a93d7d', 'G3_9fe864b85d', 'G3_266b0e662b', 'G3_5452707361', 'G3_69399240ae', 'G3_2471831b34', 'G3_21f2d77a2c', 'G3_c6b2e5f65f', 'G3_744ee4dccd', 'G3_b71a55240d', 'G3_3d5848c9bf', 'G3_639f4cf438', 'G3_8afc4d7cc6', 'G3_abae477940', 'G3_50c182bc13', 'G3_a666d2f0cf', 'G3_6dea1b2223', 'G3_a33b8a692e', 'G3_c58a16a8a7', 'G3_da78281e6e', 'G3_68198a1db4', 'G3_d28b48362c', 'G3_7b0fc05966', 'G3_1ace8a6c21', 'G3_387723d3e5', 'G3_9d1ed4220b', 'G3_dfef1b2e3d', 'G3_afd1288c76', 'G3_1502e78d29', 'G3_effaff7b7d', 'G3_a5d9205b16', 'G3_b5cec8dfd2', 'G3_b8b88efe7b', 'G3_f4cc07c313', 'G3_ad105f62ac', 'G3_1921349ee4', 'G3_fcdcd4e680', 'G3_4bd6574de5', 'G3_b5df9e74e8', 'G3_362de1de5e', 'G3_28757e862e', 'G3_314c921806', 'G3_2e4abfee98', 'G3_2497d720b4', 'G3_00564c9836', 'G3_2b62d0b7bd', 'G3_fe59f2c924', 'G3_4dc0a7293b', 'G3M_b6ac32a6e5', 'G3M_96b169b02a', 'G3M_e884bbbac7', 'G3M_0c6cc9eafd', 'G3M_304aac053c', 'G3M_490061e37a', 'G3M_37ba9a2729', 'G3M_97a70da9c7', 'G3M_364aad7777', 'G3M_b6742ded57', 'G3M_5a13c5634c', 'G3M_4dba316bd9', 'G3M_68e6eef0ba', 'G3M_47d74fc67b', 'G3M_39b3f0cc3e', 'G3M_ed2818d7f7', 'G3M_67e8e34948', 'G3M_c95604b8bb', 'G3M_db586a3616', 'G3M_9af0f8b3b6', 'G3M_8f91cd3594', 'G3M_e887fcac2c', 'G3M_d8495b00ce', 'G3X_e4aeb04536', 'G3X_d664217353', 'G3X_198e52ca50', 'G3X_15a7357437', 'G3X_00ad77ba64', 'G3X_7fa015f240', 'G3X_388422d6cf', 'G3X_bfc2750b1e', 'G3X_1208b56c15', 'G3X_a36c8c53d5', 'G3X_9031cf3638', 'G3X_ef270b0f41', 'G3X_28f1f9f5fd', 'G3X_02f5169608', 'G6_0889ee2d9b', 'G6_b25eb6f861', 'G6_e6be365db0', 'G6_6d1a9bdc50', 'G6_5f312dfa22', 'G6_a8996988c5', 'G6_2e797979e8', 'G6_a4c834d7b5', 'G6_bb664143b8', 'G6_2c51a7038c', 'G6_02127ba4ee', 'G6_619f4e13d0', 'G6_a7f3c96060', 'G6_c7a6c54a33', 'G6_3e1e5e7c4b', 'G6_abb4039cbf', 'G6_1ba528dc81', 'G6_bb4f0eb457', 'G6_1634d68d0d', 'G6_20d51ffe0a', 'G6_d226c266fc', 'G6_ceb0585452', 'G6_a147084c9a', 'G6_129a956164', 'G6_3916f86446', 'G6_b9d1f1dcd4', 'G6_4754210e61', 'G6_5d52717c40', 'G6_bb34307d0e', 'G6_3fe6fdbc83', 'G6_017ac70594', 'G6_c8736cbfac', 'G6_29da2fc4f3', 'G6_8ce7589b87', 'G6_1973a000c3', 'G6_e2411a179d', 'G6_1a7af51b7e', 'G6_b801fc96e3', 'G6_b4ba8b1792', 'G6_109062dd31', 'G6_3749ba9a32', 'G6_65d2c6a2b2', 'G6_4338ce7458', 'G6_9f86c6dd29', 'G6_7e150b31ee', 'G6_4b0b3e21b0', 'G6_ab01076a54', 'G6_2d9a985b42', 'G6_a935cea0da', 'G6_e1d4de372f', 'G6_c1057de329', 'G6_025ae70be3', 'G6_9d6d4ec4df', 'G6_c09d1d2663', 'G6_0acecbb33f', 'G6_60c1688aa5', 'G6_365994106a', 'G6_ce9258819c', 'G6_a2c9eb2426', 'G6_1a9e7b586c', 'G6_2e88251257', 'G6_a87c29c114', 'G6_374cdbfda7', 'G6_c3ecab6186', 'G6_45b98587aa', 'G6_8591e5fc2d', 'G6_2418a6f9d3', 'G6_1d99675de2', 'G6_697ee4cf43', 'G6_79f1e74df2', 'G6_6b3da81930', 'G6_0fd585090a', 'G6_bab759802d', 'G6_ad55dbf31f', 'G6_52c1d6b1db', 'G6_7bf7ad3186', 'G6_1e935e7dcc', 'G6_545fd803df', 'G6_b545cb9c2d', 'G6_8300107017', 'G6_60e29c8cee', 'G6_ee695fa275', 'G6_460902cfc9', 'G6_b1e4f314dd', 'G6_5fe4569c46', 'G6_3b27e6d50c', 'G6_96edc9f227', 'G6_f3bcdddd2f', 'G6_6b2f421ff0', 'G6_40ca1197a8', 'G6_57908a3820', 'G6_80548836be', 'G6_5513f25f60', 'G6_6467c84caf', 'G6_4f5d98aa3c', 'G6_4c81425dab', 'G6_987afdf05a', 'G6_4544cf4599', 'G6_02e026b7d7', 'G6_840c48719c', 'G6_64b9a493fe', 'G6_68f0384adc', 'G6_3bcd7b7f8c', 'G6_a98902b9b2', 'G6_e08df6052d', 'G6_4d9dce5cd2', 'G6_9ab4218572', 'G6_42f6c4e385', 'G6_ce9c325f93', 'G6_183aef100f', 'G6_2b75de6b16', 'G6_6fad0c31b4', 'G6_0d9e6a7a40', 'G6_0decf973c9', 'G6_6ee951c2e9', 'G6_097a2ab5b5', 'G6_980699eef5', 'G6_fc99f68322', 'G6_63f64dd7c0', 'G6_a154a52a3e', 'G6_fe0ac5a401', 'G6_b32385e308', 'G6_1c0056ed52', 'G6_324f548efc', 'G6_9b7f3d2f85', 'G6_afbf087535', 'G6_2adcc05b73', 'G6_f04700cc44', 'G6_97b86d401a', 'G6_99c064d4df', 'G6_4392f4326f', 'G6_6890bd6e38', 'G6_d53ce71b80', 'G6_9115de1f79', 'G6_450876c16d', 'G6_c03b372bbd', 'G6_26df4f7f6a', 'G6_22f79a9c39', 'G6_47e910aeff', 'G6_cbdd4aedf5', 'G6_ae72451e32', 'G6_26196e1aef', 'G6_ca37e8b4c5', 'G6_1166e9e874', 'G6_7488db1622', 'G6_bb66e54f7b', 'G6_41f1c758cc', 'G6_bc47af9a6b', 'G6_44de45a38b', 'G6_4dee3ac93f', 'G6_4ef1850e36', 'G6_ae256112ce', 'G6_f826f54a3e', 'G6_22619cc6e9', 'G6_e1a6337cb7', 'G6_62f125d8c8', 'G6_64fd716877', 'G6_6bd714a7c2', 'G6_18e843ee7d', 'G6_305cff8767', 'G6_0669dc8385', 'G6_a661cbe5f3', 'G6_fd27d5ebe7', 'G6_28cb066313', 'G6_51d9181fc2', 'G6_bfe80b54ff', 'G6_b0d10a401a', 'G6_bef10d3b41', 'G6_df03c4a3e9', 'G6_d5071dff9e', 'G6_731d54d9e7', 'G6_da303f0c87', 'G6_44166aa529', 'G6_bfaa7dc939', 'G6_9cc4f23e1f', 'G6_2663ff0c79', 'G6_ad4807c633', 'G6_e2ab4d178a', 'G6_fc44d4388f', 'G6_c5414909bb', 'G6_918e6489a9', 'G6_9315d9b26a', 'G6_665a897642', 'G6_9b60e3cd91', 'G6_5dd023b221', 'G6_a1234cf405', 'G6_aab768862f', 'G6_ab77ab0727', 'G6_2b3dfbdeac', 'G6_52388ce669', 'G6_739077da98', 'G6_518c311998', 'G6_9362db47a6', 'G6_33ec450e06', 'G6_144538a6c4', 'G6_739971b6f4', 'G6_0c2fd82d1f', 'G6_6ccc0945e2', 'G6_463a648b3f', 'G6_fc8ead846c', 'G6_6c32943b83', 'G6_2d4aa7ea53', 'G6_52f10f4251', 'G6_839726e30b', 'G6_a6516a887e', 'G6_6f156d032e', 'G6_9b83505914', 'G6_7f6ce0b7cf', 'G6_9e50fa1eec', 'G6_8eb86ffef4', 'G6_3a277225e7', 'G6_1bda08df80', 'G6_295a2dff8a', 'G6_e8cc817e5d', 'G6_b912e541d5', 'G6_ffc80a3cd1', 'G6_15fbbd4152', 'G6_4c91daa8c8', 'G6_71579737f0', 'G6_53bdddfedf', 'G6_cd47828253', 'G6_d2e8c150cf', 'G6_172c636a0a']

## 15 SHADOW CANDIDATES (PROMISING)

- `G6_871e6e0ca9` fit=0.06683466635915379 IS_n=40 OOS_n=12
- `G6_0de69f9494` fit=0.06420940898759556 IS_n=42 OOS_n=12
- `G6_e604fc7102` fit=0.06308651984975416 IS_n=37 OOS_n=12
- `G6_085e34f46d` fit=0.06158049418721261 IS_n=38 OOS_n=12
- `G6_83123eeb90` fit=0.053570742101624574 IS_n=36 OOS_n=12
- `G6_fa5984baed` fit=0.05111958474690021 IS_n=42 OOS_n=12
- `G3_989212f0ff` fit=0.05057589866240427 IS_n=50 OOS_n=13
- `G3_4644b9497c` fit=0.04909920453336325 IS_n=41 OOS_n=12
- `G6_d4d2a5d0ee` fit=0.04890901147506754 IS_n=36 OOS_n=12
- `G6_4d04e7bdf5` fit=0.04883330430984879 IS_n=46 OOS_n=13
- `G6_8bbf02e271` fit=0.04837303201064609 IS_n=46 OOS_n=13
- `G6_cab0788aa1` fit=0.048164184307014864 IS_n=35 OOS_n=13
- `G3_41f8b0d4bc` fit=0.046883209982340905 IS_n=42 OOS_n=13
- `G6_a775d5e663` fit=0.04649505796227138 IS_n=37 OOS_n=12
- `G3X_3ad813eaba` fit=0.046390302107480796 IS_n=40 OOS_n=12
- `G6_35d9cffad1` fit=0.046390302107480796 IS_n=40 OOS_n=12
- `G6_881dbc7c65` fit=0.046298127425567326 IS_n=39 OOS_n=12
- `G6_76ceef689b` fit=0.0460301298505332 IS_n=36 OOS_n=12
- `G3M_39a5380248` fit=0.04570413834180089 IS_n=38 OOS_n=13
- `G6_ca2ec49b33` fit=0.045278980813462544 IS_n=37 OOS_n=12

## 16 NEXT RESEARCH QUESTIONS

1. Which PROMISING genes fail leave-one-crisis when OOS crises are weighted equally?
2. Does adding TermSlope filter improve OOS stability or only shrink n?
3. Are anti-signal passes concentrated in a single transition family (OVERFIT proxy)?
4. How does cost×10bps change the Pareto frontier of EV vs |ES|?
5. Conditional hazard: does persist_age interaction with vol_expansion change Stage1 pass rate?
6. Should gen3 mutate only diversity-tagged underrepresented mechanisms?
7. OPRA-blocked: which spot PROMISING parents are priority for option expression stubs?
8. Walk-forward: does expanding-window EV stay positive for top-10 fitness genes?
9. Secondary split (≤2022 / 2023+) — which genes flip sign on OOS2?
10. Event-clock conditional: do entries near pulse events inflate apparent EV?

## 17 COMPUTE ALLOCATION FOR NEXT ROUND

- Genes tested this round: **14113** (document if <20k: target was 8k–12k+gen2).
- Next: deepen OOS walk-forward on PROMISING; gen3 diversity mutations; Phase 7 resurrection scan.
- Do NOT spend compute on BS option P/L until OPRA.
- Keep progress under `evolution/progress/` for recoverability.

candidate_pool: `genes/candidate_pool.json` n=47
