"""Phase 6 — Evolution engine: promote/demote, mutate PROMISING, diversity pool."""
from __future__ import annotations

import json
import random
from collections import Counter
from datetime import datetime, timezone
from typing import Any

from . import gene_store, hypothesis_lab, mass_backtest
from .paths import EVOLUTION, GENES

PROGRESS = EVOLUTION / "progress"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def hard_active_gates(g: dict) -> tuple[bool, str]:
    """ACTIVE rare: IS n≥30, OOS n≥15, both EV>0, OOS tlike>1, anti fail,
    cost×2, not single-crisis, walk-forward lite, secondary mean>0, ES/MDD caps.
    """
    is_ = g.get("is") or {}
    oos = g.get("oos") or {}
    n_is = int(is_.get("n") or 0)
    n_oos = int(oos.get("n") or 0)
    mean_is = is_.get("mean")
    mean_oos = oos.get("mean")
    if n_is < 30:
        return False, f"IS_n={n_is}<30"
    if n_oos < 15:
        return False, f"OOS_n={n_oos}<15"
    if not (isinstance(mean_is, (int, float)) and mean_is > 0):
        return False, "IS_EV<=0"
    if not (isinstance(mean_oos, (int, float)) and mean_oos > 0):
        return False, "OOS_EV<=0"
    tlike = oos.get("tlike")
    if not (isinstance(tlike, (int, float)) and tlike > 1.0):
        return False, f"OOS_tlike={tlike}"
    cost = g.get("cost_sensitivity") or {}
    if not cost.get("survive_10bps"):
        return False, "cost_10bps_fail"
    reg = g.get("regime_stability") or {}
    loc = reg.get("leave_one_crisis") or {}
    if loc.get("single_crisis_driven"):
        return False, "single_crisis_driven"
    anti = reg.get("anti_signal") or {}
    if anti.get("also_passes"):
        return False, "anti_also_passes"
    wf = reg.get("walk_forward_lite") or g.get("walk_forward") or {}
    if not wf.get("pass"):
        return False, "walk_forward_lite_fail"
    sec_is = is_.get("secondary_IS") or {}
    sec_oos = oos.get("secondary_OOS") or {}
    if isinstance(sec_is.get("mean"), (int, float)) and not (sec_is["mean"] > 0):
        return False, "IS2_mean<=0"
    if int(sec_oos.get("n") or 0) >= 8 and not (
        isinstance(sec_oos.get("mean"), (int, float)) and sec_oos["mean"] > 0
    ):
        return False, "OOS2_mean<=0"
    es = is_.get("es5", g.get("es95"))
    if isinstance(es, (int, float)) and es < -0.35:
        return False, f"es5_too_bad={es}"
    mdd = g.get("max_drawdown")
    if isinstance(mdd, (int, float)) and mdd < -0.60:
        return False, f"maxdd={mdd}"
    if g.get("evidence_tag") == "Hypothetical":
        return False, "hypothetical_option"
    fit = float(g.get("fitness") or -999)
    if fit < 0.001:
        return False, f"fitness_low={fit}"
    return True, "ok_strict"


def promote_demote_population(pop: list[dict] | None = None) -> dict[str, Any]:
    pop = list(pop if pop is not None else gene_store.load_population())
    dead = gene_store.load_dead()
    dead_ids = {d["gene_id"] for d in dead}
    keep = []
    stats = Counter()
    for g in pop:
        if g.get("evidence_tag") == "Hypothetical":
            keep.append(g)
            stats[g.get("state", "INCUBATING")] += 1
            continue
        st = g.get("state")
        if st == "PROMISING":
            ok, reason = hard_active_gates(g)
            if ok:
                g["state"] = "ACTIVE"
                g["notes"] = (g.get("notes") or "") + f" | ACTIVE_gate={reason}"
                gene_store.append_evolution(
                    {
                        "event": "PROMOTION",
                        "gene_id": g["gene_id"],
                        "from_state": "PROMISING",
                        "to_state": "ACTIVE",
                        "reason": reason,
                    }
                )
            keep.append(g)
            stats[g["state"]] += 1
        elif st in ("DEAD",):
            if g["gene_id"] not in dead_ids:
                dead.append(g)
                dead_ids.add(g["gene_id"])
            stats["DEAD"] += 1
        else:
            # Fill resurrection for DORMANT/DEAD-ish
            if st == "DORMANT" and not g.get("resurrection_condition"):
                g["resurrection_condition"] = (
                    "cost improves OR regime_persistent_drawdown returns with positive OOS retest"
                )
            keep.append(g)
            stats[st] += 1
    gene_store.save_population(keep)
    gene_store.save_dead(dead)
    return {"state_counts": dict(stats), "population": keep, "dead": dead}


def mutate_promising_generation(
    n_children: int = 2500,
    seed: int = 7,
) -> list[dict]:
    """Mutate top PROMISING into new children; return new gene dicts (not yet tested)."""
    rng = random.Random(seed)
    pop = gene_store.load_population()
    parents = [g for g in pop if g.get("state") in ("PROMISING", "ACTIVE") and mass_backtest.is_spot_testable(g)]
    if not parents:
        # fallback: best TESTING by fitness
        parents = sorted(
            [g for g in pop if g.get("state") == "TESTING" and mass_backtest.is_spot_testable(g)],
            key=lambda x: float(x.get("fitness") or -999),
            reverse=True,
        )[:50]
    if not parents:
        return []

    existing = {g["gene_id"] for g in pop}
    genomes = {
        (g.get("entry_logic") or {}).get("genome_id")
        for g in pop
        if (g.get("entry_logic") or {}).get("genome_id")
    }
    children = []
    attempts = 0
    while len(children) < n_children and attempts < n_children * 8:
        attempts += 1
        p = rng.choice(parents)
        el = dict(p.get("entry_logic") or {})
        el.setdefault("horizon", (p.get("exit_logic") or {}).get("horizon_trading_days", 5))
        if rng.random() < 0.7:
            me = hypothesis_lab.mutate_entry(el, rng)
            src = "gen2_mutation"
            event = "MUTATION"
            parents_ids = [p["gene_id"]]
        else:
            p2 = rng.choice(parents)
            e2 = dict(p2.get("entry_logic") or {})
            e2.setdefault("horizon", 5)
            me = hypothesis_lab.crossover_entry(el, e2, rng)
            src = "gen2_crossover"
            event = "CROSSOVER"
            parents_ids = [p["gene_id"], p2["gene_id"]]
        if me["genome_id"] in genomes:
            continue
        genomes.add(me["genome_id"])
        gid = hypothesis_lab._stable_id("G6", me)
        if gid in existing:
            continue
        g = hypothesis_lab.make_spot_gene(
            gid, me, parent_ids=parents_ids, source=src, state="INCUBATING"
        )
        children.append(g)
        existing.add(gid)
        gene_store.append_evolution(
            {
                "event": event,
                "gene_id": gid,
                "parent_ids": parents_ids,
                "child": gid,
                "to_state": "INCUBATING",
                "reason": "phase6_second_generation",
            }
        )

    # Bulk add
    pop = gene_store.load_population()
    pop.extend(children)
    gene_store.save_population(pop)
    return children


def maintain_candidate_pool(pop: list[dict] | None = None) -> dict:
    pop = pop if pop is not None else gene_store.load_population()
    candidates = [
        g
        for g in pop
        if g.get("state") in ("PROMISING", "ACTIVE", "TESTING")
        and g.get("evidence_tag") != "Hypothetical"
        and float(g.get("fitness") or -999) > -1
    ]
    candidates.sort(key=lambda x: float(x.get("fitness") or -999), reverse=True)
    # Diversity: keep mechanism tag coverage
    tag_seen = set()
    diverse = []
    for g in candidates:
        tags = tuple((g.get("hypothesis") or {}).get("mechanism_tags") or [])
        if tags not in tag_seen or len(diverse) < 40:
            diverse.append(
                {
                    "gene_id": g["gene_id"],
                    "state": g["state"],
                    "fitness": g.get("fitness"),
                    "is_n": (g.get("is") or {}).get("n"),
                    "oos_n": (g.get("oos") or {}).get("n"),
                    "is_mean": (g.get("is") or {}).get("mean"),
                    "oos_mean": (g.get("oos") or {}).get("mean"),
                    "mechanism_tags": list(tags),
                    "evidence_tag": g.get("evidence_tag"),
                }
            )
            tag_seen.add(tags)
        if len(diverse) >= 100:
            break
    pool = {
        "updated_utc": _now(),
        "n": len(diverse),
        "candidates": diverse,
        "diversity_tags": sorted({t for c in diverse for t in c.get("mechanism_tags") or []}),
    }
    GENES.mkdir(parents=True, exist_ok=True)
    (GENES / "candidate_pool.json").write_text(json.dumps(pool, indent=2), encoding="utf-8")
    return pool


def run_evolution(
    gen2_children: int = 2500,
    rescreen: bool = True,
) -> dict[str, Any]:
    PROGRESS.mkdir(parents=True, exist_ok=True)
    promo = promote_demote_population()
    children = mutate_promising_generation(n_children=gen2_children)
    gen2_summary = {"born": len(children)}
    if rescreen and children:
        # Only re-screen the new children (fast path)
        mb = mass_backtest.run_mass_backtest(
            genes=children + [
                g
                for g in gene_store.load_population()
                if g.get("state") in ("PROMISING", "ACTIVE", "TESTING", "WEAKENING", "DORMANT")
                and g["gene_id"] not in {c["gene_id"] for c in children}
            ],
            progress_name="phase6_gen2_mass.json",
        )
        gen2_summary["rescreen"] = mb["summary"]
        promo = promote_demote_population()
    pool = maintain_candidate_pool()
    out = {
        "promo": {k: v for k, v in promo.items() if k != "population" and k != "dead"},
        "gen2": gen2_summary,
        "candidate_pool_n": pool["n"],
        "state_counts": promo.get("state_counts"),
        "ts": _now(),
    }
    # Recount from disk
    pop = gene_store.load_population()
    out["state_counts"] = dict(Counter(g.get("state") for g in pop))
    out["dead_bank_n"] = len(gene_store.load_dead())
    out["active_ids"] = [g["gene_id"] for g in pop if g.get("state") == "ACTIVE"]
    out["promising_ids"] = [g["gene_id"] for g in pop if g.get("state") == "PROMISING"][:50]
    (PROGRESS / "phase6_evolution.json").write_text(json.dumps(out, indent=2, default=str), encoding="utf-8")
    return out


if __name__ == "__main__":
    print(run_evolution(gen2_children=100, rescreen=False))
