"""State Engine — relative vol, trend, persistence ages → market_state.json."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

import numpy as np
import pandas as pd

from .paths import STATE


def _ensure_core_features(df: pd.DataFrame) -> pd.DataFrame:
    """Compute missing core features if panel-only columns are present."""
    out = df.copy()
    if "QQQ" not in out.columns:
        raise ValueError("QQQ column required")
    if "MA20" not in out.columns:
        out["MA20"] = out["QQQ"].rolling(20).mean()
    if "QQQ_over_MA20" not in out.columns:
        out["QQQ_over_MA20"] = out["QQQ"] / out["MA20"] - 1.0
    if "MA50" not in out.columns:
        out["MA50"] = out["QQQ"].rolling(50).mean()
    if "QQQ_over_MA50" not in out.columns:
        out["QQQ_over_MA50"] = out["QQQ"] / out["MA50"] - 1.0
    if "QQQ_ret1" not in out.columns:
        out["QQQ_ret1"] = out["QQQ"].pct_change()
    if "DD20" not in out.columns:
        roll_max = out["QQQ"].rolling(20).max()
        out["DD20"] = out["QQQ"] / roll_max - 1.0
    if "persist_below_MA20" not in out.columns:
        below = (out["QQQ"] < out["MA20"]).astype(int)
        # age while continuously below
        age = []
        a = 0
        for b in below.fillna(0).tolist():
            a = a + 1 if b else 0
            age.append(a)
        out["persist_below_MA20"] = age
    if "RV20" not in out.columns:
        out["RV20"] = out["QQQ_ret1"].rolling(20).std() * np.sqrt(252)
    if "RV5" not in out.columns:
        out["RV5"] = out["QQQ_ret1"].rolling(5).std() * np.sqrt(252)
    if "RV5_over_RV20" not in out.columns:
        out["RV5_over_RV20"] = out["RV5"] / out["RV20"]
    if "backwardation" not in out.columns and "VIX" in out.columns and "VIX3M" in out.columns:
        out["backwardation"] = (out["VIX"] > out["VIX3M"]).astype(float)
        out.loc[out["VIX3M"].isna(), "backwardation"] = np.nan
    if "TermSlope" not in out.columns and "VIX" in out.columns and "VIX3M" in out.columns:
        out["TermSlope"] = out["VIX3M"] / out["VIX"]
    if "VolPremium" not in out.columns and "VIX" in out.columns and "RV20" in out.columns:
        # crude: VIX / (RV20*100) style premium if RV is decimal
        out["VolPremium"] = out["VIX"] / (out["RV20"] * 100.0)
    return out


def compute_market_state(df: pd.DataFrame) -> dict[str, Any]:
    feat = _ensure_core_features(df)
    last = feat.iloc[-1]
    idx = feat.index[-1]
    asof = str(pd.Timestamp(idx).date())

    def g(col: str, default=None):
        if col not in feat.columns:
            return default
        v = last[col]
        if pd.isna(v):
            return None
        if isinstance(v, (np.floating, float)):
            return float(v)
        if isinstance(v, (np.integer, int)):
            return int(v)
        if isinstance(v, (np.bool_, bool)):
            return bool(v)
        return v.item() if hasattr(v, "item") else v

    below_ma20 = bool(g("QQQ", 0) is not None and g("MA20") is not None and g("QQQ") < g("MA20"))
    trend = "below_MA20" if below_ma20 else "above_MA20"
    if g("QQQ_over_MA50") is not None:
        if g("QQQ_over_MA50") < -0.05:
            trend = "deep_below_MA50"
        elif g("QQQ_over_MA50") > 0.05:
            trend = "strong_above_MA50"

    rv_ratio = g("RV5_over_RV20")
    if rv_ratio is None:
        vol_state = "unknown"
    elif rv_ratio > 1.2:
        vol_state = "expansion"
    elif rv_ratio < 0.8:
        vol_state = "compression"
    else:
        vol_state = "neutral"

    regime_hints = []
    if vol_state == "expansion":
        regime_hints.append("vol_expansion")
    if below_ma20 and (g("persist_below_MA20") or 0) >= 5 and (g("DD20") or 0) <= -0.04:
        regime_hints.append("persistent_drawdown")
    if g("backwardation") == 1.0 or g("backwardation") is True:
        regime_hints.append("term_backwardation")
    if (g("VIX") or 0) < 15 and not below_ma20:
        regime_hints.append("low_vol_trend")

    state = {
        "asof": asof,
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "evidence_tag": "Derived from Observed panel",
        "prices": {
            "QQQ": g("QQQ"),
            "VIX": g("VIX"),
            "VIX3M": g("VIX3M"),
            "VIX9D": g("VIX9D"),
            "VIX6M": g("VIX6M"),
            "VXX": g("VXX"),
            "SPY": g("SPY"),
            "TLT": g("TLT"),
        },
        "trend": {
            "label": trend,
            "MA20": g("MA20"),
            "MA50": g("MA50"),
            "QQQ_over_MA20": g("QQQ_over_MA20"),
            "QQQ_over_MA50": g("QQQ_over_MA50"),
            "QQQ_ret1": g("QQQ_ret1"),
            "DD20": g("DD20"),
            "DD60": g("DD60"),
        },
        "relative_vol": {
            "label": vol_state,
            "RV5": g("RV5"),
            "RV20": g("RV20"),
            "RV5_over_RV20": rv_ratio,
            "VolPremium": g("VolPremium"),
            "VolPremium_z": g("VolPremium_z"),
            "TermSlope": g("TermSlope"),
            "backwardation": g("backwardation"),
            "ShortVolRel": g("ShortVolRel"),
        },
        "persistence": {
            "persist_below_MA20": g("persist_below_MA20"),
            "consec_down": g("consec_down"),
            "mom2": g("mom2"),
            "mom2_improve": g("mom2_improve"),
            "QQQ_1d_up": g("QQQ_1d_up"),
            "VolPremium_z_falling": g("VolPremium_z_falling"),
            "ShortVolRel_falling": g("ShortVolRel_falling"),
        },
        "regime_hints": regime_hints,
        "notes_zh": "狀態為 Derived；非預測。Event age ≠ 買入訊號。",
    }
    return state


def write_market_state(df: pd.DataFrame, path=None) -> dict[str, Any]:
    STATE.mkdir(parents=True, exist_ok=True)
    state = compute_market_state(df)
    out = path or (STATE / "market_state.json")
    out.write_text(json.dumps(state, indent=2), encoding="utf-8")
    return state
