"""Phase 3 — Hypothesis Lab / Gene population explosion."""
from __future__ import annotations

import hashlib
import itertools
import json
import random
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import gene_store
from .paths import EVOLUTION, GENES, OPTIONS, ROOT

PROGRESS = EVOLUTION / "progress"
MECH_TAGS = ("trend_persist", "meanrev_fail", "vol_rel", "term")

MA_BELOW = [0.01, 0.02, 0.03, 0.05]
DD20 = [0.02, 0.04, 0.06, 0.08, 0.10]
PERSIST = [3, 5, 7, 10, 15, 20]
HOLD = [5, 10, 15, 20]
VPZ = [0.0, 0.5, 1.0, 1.5]  # 0 = off
TERM_SLOPE = [0, 1]  # 1 = require TermSlope < 1 (backwardation-ish)
USE_BACK = [0, 1]

# Transition patterns: (1d_up, mom_improve, vpz_fall, vix_down)
TRANS_PATTERNS = [
    (1, 0, 0, 0),
    (0, 1, 0, 0),
    (0, 0, 1, 0),
    (0, 0, 0, 1),
    (1, 1, 0, 0),
    (1, 0, 1, 0),
    (0, 1, 1, 0),
    (1, 0, 0, 1),
    (0, 1, 0, 1),
    (0, 0, 1, 1),
    (1, 1, 1, 0),
    (1, 1, 0, 1),
    (0, 1, 1, 1),
    (1, 0, 1, 1),
]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def genome_key(el: dict) -> str:
    return (
        f"ma{el['ma_below']}_dd{abs(el['dd20'])}_age{el['persist_age']}"
        f"_vpz{el.get('vpz', 0)}_bk{el.get('use_back', 0)}_term{el.get('use_term', 0)}"
        f"_t1{el.get('trans_1d_up', 0)}_tm{el.get('trans_mom_improve', 0)}"
        f"_tv{el.get('trans_vpz_fall', 0)}_tx{el.get('trans_vix_down', 0)}"
        f"_h{el['horizon']}_anti{el.get('anti', 0)}"
    )


def mechanism_tags(el: dict) -> list[str]:
    tags = []
    if el.get("persist_age", 0) >= 10:
        tags.append("trend_persist")
    if el.get("ma_below", 0) >= 0.02 and el.get("dd20", 0) <= -0.04:
        tags.append("meanrev_fail")
    if el.get("vpz", 0) > 0 or el.get("trans_vpz_fall"):
        tags.append("vol_rel")
    if el.get("use_term") or el.get("use_back"):
        tags.append("term")
    if not tags:
        tags.append("meanrev_fail")
    return tags


def entry_from_params(**kw) -> dict:
    dd = kw.get("dd20", 0.04)
    if dd > 0:
        dd = -dd
    el = {
        "ma_below": float(kw["ma_below"]),
        "dd20": float(dd),
        "persist_age": int(kw["persist_age"]),
        "vpz": float(kw.get("vpz", 0.0)),
        "use_back": int(kw.get("use_back", 0)),
        "use_term": int(kw.get("use_term", 0)),
        "trans_1d_up": int(kw.get("trans_1d_up", 0)),
        "trans_mom_improve": int(kw.get("trans_mom_improve", 0)),
        "trans_vpz_fall": int(kw.get("trans_vpz_fall", 0)),
        "trans_vix_down": int(kw.get("trans_vix_down", 0)),
        "horizon": int(kw["horizon"]),
        "anti": int(kw.get("anti", 0)),
    }
    el["genome_id"] = genome_key(el)
    return el


def make_spot_gene(
    gene_id: str,
    entry: dict,
    *,
    parent_ids: list[str] | None = None,
    source: str = "hypothesis_lab_grid",
    state: str = "INCUBATING",
    evidence_tag: str = "Observed",
    notes: str = "",
) -> dict:
    tags = mechanism_tags(entry)
    hyp = {
        "statement": (
            f"QQQ <= -{entry['ma_below']:.0%} MA20, DD20<={entry['dd20']:.0%}, "
            f"persist>={entry['persist_age']}, transition filters, hold {entry['horizon']}d "
            f"→ positive mean forward QQQ (spot)."
        ),
        "instrument": "QQQ_spot",
        "mechanism_tags": tags,
        "not_active": True,
    }
    return gene_store.empty_gene(
        gene_id=gene_id,
        parent_ids=parent_ids or [],
        birth_time=_now(),
        state=state,
        hypothesis=hyp,
        features=["QQQ_over_MA20", "DD20", "persist_below_MA20"],
        relative_features=["VolPremium_z"] if entry.get("vpz", 0) > 0 else [],
        persistence_features=["persist_below_MA20"],
        regime_features=tags,
        entry_logic=entry,
        exit_logic={"horizon_trading_days": entry["horizon"], "timeout_is_outcome": True},
        option_structure={"status": "none_spot_only"},
        hedge_structure={},
        risk_budget={"phase": "research_only", "live_capital": 0},
        evidence_tag=evidence_tag,
        source=source,
        notes=notes or f"mech={','.join(tags)}",
        next_review="phase4_mass_backtest",
    )


def _stable_id(prefix: str, entry: dict) -> str:
    h = hashlib.sha1(genome_key(entry).encode()).hexdigest()[:10]
    return f"{prefix}_{h}"


def build_grid_entries(max_n: int = 12000, seed: int = 42) -> list[dict]:
    """Full combinatorial grid, then subsample if over max_n."""
    entries = []
    for ma, dd, age, vpz, bk, term, (t1, tm, tv, tx), h in itertools.product(
        MA_BELOW, DD20, PERSIST, VPZ, USE_BACK, TERM_SLOPE, TRANS_PATTERNS, HOLD
    ):
        # require at least one transition
        if t1 + tm + tv + tx == 0:
            continue
        entries.append(
            entry_from_params(
                ma_below=ma,
                dd20=dd,
                persist_age=age,
                vpz=vpz,
                use_back=bk,
                use_term=term,
                trans_1d_up=t1,
                trans_mom_improve=tm,
                trans_vpz_fall=tv,
                trans_vix_down=tx,
                horizon=h,
                anti=0,
            )
        )
    # Dedup by genome_id
    seen = set()
    uniq = []
    for e in entries:
        k = e["genome_id"]
        if k not in seen:
            seen.add(k)
            uniq.append(e)
    if len(uniq) > max_n:
        rng = random.Random(seed)
        rng.shuffle(uniq)
        uniq = uniq[:max_n]
    return uniq


def mutate_entry(el: dict, rng: random.Random) -> dict:
    e = dict(el)
    knobs = [
        ("ma_below", MA_BELOW),
        ("persist_age", PERSIST),
        ("horizon", HOLD),
        ("vpz", VPZ),
    ]
    k, choices = rng.choice(knobs)
    e[k] = rng.choice(choices)
    if rng.random() < 0.3:
        e["dd20"] = -abs(rng.choice(DD20))
    if rng.random() < 0.25:
        e["use_back"] = 1 - int(e.get("use_back", 0))
    if rng.random() < 0.25:
        e["use_term"] = 1 - int(e.get("use_term", 0))
    # flip one transition bit occasionally
    if rng.random() < 0.4:
        bit = rng.choice(
            ["trans_1d_up", "trans_mom_improve", "trans_vpz_fall", "trans_vix_down"]
        )
        e[bit] = 1 - int(e.get(bit, 0))
    if sum(int(e.get(b, 0)) for b in (
        "trans_1d_up", "trans_mom_improve", "trans_vpz_fall", "trans_vix_down"
    )) == 0:
        e["trans_mom_improve"] = 1
    e["anti"] = 0
    e["genome_id"] = genome_key(e)
    return e


def crossover_entry(a: dict, b: dict, rng: random.Random) -> dict:
    e = {}
    for k in (
        "ma_below", "dd20", "persist_age", "vpz", "use_back", "use_term",
        "trans_1d_up", "trans_mom_improve", "trans_vpz_fall", "trans_vix_down",
        "horizon",
    ):
        e[k] = a.get(k) if rng.random() < 0.5 else b.get(k)
    e["dd20"] = -abs(float(e["dd20"]))
    e["anti"] = 0
    if sum(int(e.get(b, 0)) for b in (
        "trans_1d_up", "trans_mom_improve", "trans_vpz_fall", "trans_vix_down"
    )) == 0:
        e["trans_mom_improve"] = 1
    e["genome_id"] = genome_key(e)
    return e


def seed_entries_from_survivors(path: Path | None = None, limit: int = 50) -> list[dict]:
    """Ideas only from RVTE survivors.csv — re-test required."""
    p = path or Path("/workspace/qqq-vxx-desk/backtest/rvte/survivors.csv")
    out = []
    if not p.exists():
        return out
    import pandas as pd

    df = pd.read_csv(p).head(limit)
    for _, r in df.iterrows():
        try:
            out.append(
                entry_from_params(
                    ma_below=float(r["ma_below"]),
                    dd20=float(r["dd20"]),
                    persist_age=int(r["persist_age"]),
                    vpz=float(r.get("vpz", 0) or 0),
                    use_back=int(r.get("use_back", 0) or 0),
                    use_term=0,
                    trans_1d_up=int(r.get("trans_1d_up", 0) or 0),
                    trans_mom_improve=int(r.get("trans_mom_improve", 0) or 0),
                    trans_vpz_fall=int(r.get("trans_vpz_fall", 0) or 0),
                    trans_vix_down=0,
                    horizon=int(r["horizon"]),
                    anti=0,
                )
            )
        except Exception:
            continue
    return out


def expand_option_catalog_stubs() -> dict:
    """Phase 3/8: catalog stubs only — Hypothetical, no BS scoring."""
    OPTIONS.mkdir(parents=True, exist_ok=True)
    lib_path = OPTIONS / "option_library.json"
    base = {
        "version": 2,
        "evidence_tag": "OPRA-blocked",
        "disclaimer": (
            "Structure catalog only. No verified option P/L. "
            "BS/proxy IV results are Hypothetical — DO NOT use as fitness."
        ),
        "expiries_days": [0, 1, 3, 7, 14, 21, 30, 45, 60, 90],
        "deltas": ["ATM", "5D", "10D", "15D", "20D", "25D", "30D"],
        "strikes": ["ATM", "5D", "10D", "15D", "20D", "25D", "30D"],
        "relative_expiries": ["7/14", "7/21", "14/30", "21/45", "30/60"],
        "ratio_grid": ["1:1", "1:2", "1:3", "2:1", "1:4", "3:1"],
        "structures": [
            {"id": "CALL", "legs": ["long_call"]},
            {"id": "PUT", "legs": ["long_put"]},
            {"id": "VERTICAL_CALL", "legs": ["long_call", "short_higher_call"]},
            {"id": "VERTICAL_PUT", "legs": ["long_put", "short_lower_put"]},
            {"id": "CALENDAR", "legs": ["long_far_call", "short_near_call"]},
            {"id": "DIAGONAL", "legs": ["long_far_otm", "short_near_atm"]},
            {"id": "RATIO_CALL", "legs": ["long_call", "short_nx_otm_call"]},
            {"id": "RATIO_PUT", "legs": ["long_put", "short_nx_otm_put"]},
            {"id": "CALL_PUT", "legs": ["long_call", "long_put"]},
            {"id": "ASYMMETRIC_HEDGE", "legs": ["directional_leg", "smaller_opposite_convex"]},
            {"id": "DOUBLE_DIAGONAL", "legs": ["call_diagonal", "put_diagonal"]},
            {"id": "BROKEN_WING", "legs": ["broken_wing_butterfly"]},
            {"id": "IRON_CONDOR", "legs": ["short_put_spread", "short_call_spread"]},
            {"id": "BUTTERFLY_CALL", "legs": ["long_low", "short_2x_mid", "long_high"]},
            {"id": "RISK_REVERSAL", "legs": ["long_call", "short_put"]},
        ],
        "catalog_combos_note": "Cartesian product enumerated as stubs; not scored",
        "verified_pnl": None,
        "fitness_scoring": "FORBIDDEN_until_OPRA",
    }
    # Expand a few representative combo stubs
    stubs = []
    for struct in base["structures"][:8]:
        for exp in [7, 14, 30]:
            for delta in ["ATM", "10D", "25D"]:
                for ratio in ["1:1", "1:2"]:
                    stubs.append(
                        {
                            "stub_id": f"{struct['id']}_e{exp}_{delta}_{ratio.replace(':', 'x')}",
                            "structure": struct["id"],
                            "expiry_days": exp,
                            "delta": delta,
                            "ratio": ratio,
                            "evidence_tag": "Hypothetical",
                            "scored": False,
                        }
                    )
    base["combo_stubs"] = stubs
    base["n_combo_stubs"] = len(stubs)
    lib_path.write_text(json.dumps(base, indent=2), encoding="utf-8")
    return base


def birth_option_incubating_stubs(n: int = 4) -> list[dict]:
    """A few option genes marked Hypothetical — never scored as fitness."""
    pop = gene_store.load_population()
    existing = {g["gene_id"] for g in pop}
    born = []
    for i in range(n):
        gid = f"OPT_STUB_HYP_{i+1:02d}"
        if gid in existing:
            continue
        g = gene_store.empty_gene(
            gene_id=gid,
            parent_ids=[],
            state="INCUBATING",
            hypothesis={
                "statement": f"Option structure stub #{i+1} — catalog only",
                "instrument": "QQQ_options",
            },
            option_structure={
                "status": "catalog_only",
                "evidence_tag": "Hypothetical",
                "opra": "blocked",
                "stub_index": i,
            },
            evidence_tag="Hypothetical",
            source="option_library_stub",
            notes="Hypothetical — OPRA-blocked. Must not score BS P/L as fitness.",
            next_review="await_OPRA",
            resurrection_condition="OPRA EOD available",
        )
        gene_store.birth(g)
        born.append(g)
    return born


def explode_population(
    target: int = 10000,
    seed: int = 42,
    mutate_extra: int = 1500,
    crossover_extra: int = 500,
) -> dict[str, Any]:
    """Generate ≥5000 spot genes via grid + mutation/crossover; log BIRTH/MUTATION/CROSSOVER."""
    PROGRESS.mkdir(parents=True, exist_ok=True)
    rng = random.Random(seed)
    pop = gene_store.load_population()
    existing_ids = {g["gene_id"] for g in pop}
    existing_genomes = {
        (g.get("entry_logic") or {}).get("genome_id")
        for g in pop
        if (g.get("entry_logic") or {}).get("genome_id")
    }

    # Keep seed spot genes; skip option hyps for grid
    seed_spot = [
        g
        for g in pop
        if g.get("evidence_tag") != "Hypothetical"
        and (g.get("entry_logic") or {}).get("ma_below") is not None
    ]

    grid = build_grid_entries(max_n=target, seed=seed)
    survivors_ideas = seed_entries_from_survivors(limit=80)
    # Prefer survivors first in list for diversity of parents
    all_entries = survivors_ideas + grid

    # Dedup
    seen = set(existing_genomes)
    unique_entries = []
    for e in all_entries:
        if e["genome_id"] in seen:
            continue
        seen.add(e["genome_id"])
        unique_entries.append(e)

    born_count = 0
    mut_count = 0
    xo_count = 0
    new_genes: list[dict] = []

    for e in unique_entries:
        if born_count >= target:
            break
        gid = _stable_id("G3", e)
        if gid in existing_ids:
            continue
        g = make_spot_gene(gid, e, source="hypothesis_lab_grid", state="INCUBATING")
        new_genes.append(g)
        existing_ids.add(gid)
        born_count += 1

    # Mutations from seeds + top of new
    parents_el = []
    for g in seed_spot:
        el = dict(g.get("entry_logic") or {})
        if "ma_below" not in el:
            continue
        if "horizon" not in el:
            el["horizon"] = (g.get("exit_logic") or {}).get("horizon_trading_days", 5)
        el.setdefault("dd20", -0.04)
        el.setdefault("persist_age", el.get("persist_age_min", 5))
        el.setdefault("trans_mom_improve", el.get("trans_mom_improve", 1))
        try:
            el = entry_from_params(
                ma_below=el.get("ma_below", 0.01),
                dd20=el.get("dd20", -0.04),
                persist_age=int(el.get("persist_age", 5)),
                horizon=int(el.get("horizon", 5)),
                vpz=float(el.get("vpz", 0) or 0),
                use_back=int(el.get("use_back", 0) or 0),
                trans_1d_up=int(el.get("trans_1d_up", 0) or 0),
                trans_mom_improve=int(el.get("trans_mom_improve", 1) or 0),
                trans_vpz_fall=int(el.get("trans_vpz_fall", 0) or 0),
                trans_vix_down=int(el.get("trans_vix_down", 0) or 0),
            )
        except Exception:
            continue
        parents_el.append((g["gene_id"], el))
    for g in new_genes[:200]:
        parents_el.append((g["gene_id"], g["entry_logic"]))

    for _ in range(mutate_extra):
        if not parents_el:
            break
        pid, pel = rng.choice(parents_el)
        me = mutate_entry(pel, rng)
        if me["genome_id"] in seen:
            continue
        seen.add(me["genome_id"])
        gid = _stable_id("G3M", me)
        if gid in existing_ids:
            continue
        g = make_spot_gene(
            gid, me, parent_ids=[pid], source="hypothesis_lab_mutation", state="INCUBATING"
        )
        new_genes.append(g)
        existing_ids.add(gid)
        mut_count += 1
        gene_store.append_evolution(
            {
                "event": "MUTATION",
                "gene_id": gid,
                "parent": pid,
                "child": gid,
                "to_state": "INCUBATING",
                "reason": "phase3_mutation",
            }
        )

    for _ in range(crossover_extra):
        if len(parents_el) < 2:
            break
        (p1, e1), (p2, e2) = rng.sample(parents_el, 2)
        ce = crossover_entry(e1, e2, rng)
        if ce["genome_id"] in seen:
            continue
        seen.add(ce["genome_id"])
        gid = _stable_id("G3X", ce)
        if gid in existing_ids:
            continue
        g = make_spot_gene(
            gid,
            ce,
            parent_ids=[p1, p2],
            source="hypothesis_lab_crossover",
            state="INCUBATING",
        )
        new_genes.append(g)
        existing_ids.add(gid)
        xo_count += 1
        gene_store.append_evolution(
            {
                "event": "CROSSOVER",
                "gene_id": gid,
                "parent_ids": [p1, p2],
                "child": gid,
                "to_state": "INCUBATING",
                "reason": "phase3_crossover",
            }
        )

    # Bulk birth (avoid N× save) — append then single save + log BIRTH batch
    pop = gene_store.load_population()
    for g in new_genes:
        # state BORN → INCUBATING already set
        if g["gene_id"] not in {x["gene_id"] for x in pop}:
            pop.append(g)
            gene_store.append_evolution(
                {
                    "event": "BIRTH",
                    "gene_id": g["gene_id"],
                    "parent": (g.get("parent_ids") or [None])[0] if g.get("parent_ids") else None,
                    "child": g["gene_id"],
                    "from_state": None,
                    "to_state": g["state"],
                    "reason": g.get("source") or "",
                }
            )
    gene_store.save_population(pop)

    # Option stubs
    expand_option_catalog_stubs()
    opt_born = birth_option_incubating_stubs(4)

    # Diversity summary
    tag_counts: dict[str, int] = {t: 0 for t in MECH_TAGS}
    for g in pop:
        for t in (g.get("hypothesis") or {}).get("mechanism_tags") or []:
            if t in tag_counts:
                tag_counts[t] += 1

    summary = {
        "generated_utc": _now(),
        "grid_unique": len(unique_entries),
        "born_grid": born_count,
        "mutations": mut_count,
        "crossovers": xo_count,
        "option_stubs_incubating": len(opt_born),
        "population_size": len(gene_store.load_population()),
        "mechanism_tag_counts": tag_counts,
        "target": target,
        "evidence": "Derived genomes from Observed features; option stubs Hypothetical",
    }
    (PROGRESS / "phase3_explosion.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    return summary


if __name__ == "__main__":
    print(json.dumps(explode_population(target=10000), indent=2))
