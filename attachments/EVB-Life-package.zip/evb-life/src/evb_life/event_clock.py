"""Event Memory / Event Clock — ages, intervals, crude conditional hazard."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Callable

import numpy as np
import pandas as pd

from .paths import EVENTS, REPORTS
from .state_engine import _ensure_core_features

IS_END = "2018-12-31"


def _event_definitions(df: pd.DataFrame) -> list[dict[str, Any]]:
    """~20–40 event definitions as boolean Series factories."""

    def col(name: str) -> pd.Series:
        if name not in df.columns:
            return pd.Series(False, index=df.index)
        return df[name]

    defs: list[tuple[str, str, Callable[[], pd.Series]]] = [
        ("qqq_m3pct_day", "QQQ daily return <= -3%", lambda: col("QQQ_ret1") <= -0.03),
        ("qqq_m2pct_day", "QQQ daily return <= -2%", lambda: col("QQQ_ret1") <= -0.02),
        ("qqq_m1pct_day", "QQQ daily return <= -1%", lambda: col("QQQ_ret1") <= -0.01),
        ("qqq_p2pct_day", "QQQ daily return >= +2%", lambda: col("QQQ_ret1") >= 0.02),
        ("qqq_p3pct_day", "QQQ daily return >= +3%", lambda: col("QQQ_ret1") >= 0.03),
        ("vix_p20pct_day", "VIX daily %chg >= +20%", lambda: col("VIX").pct_change() >= 0.20),
        ("vix_p10pct_day", "VIX daily %chg >= +10%", lambda: col("VIX").pct_change() >= 0.10),
        ("vix_m10pct_day", "VIX daily %chg <= -10%", lambda: col("VIX").pct_change() <= -0.10),
        ("vxx_p10pct_day", "VXX daily %chg >= +10% (overlay)", lambda: col("VXX").pct_change() >= 0.10),
        ("vxx_p20pct_day", "VXX daily %chg >= +20% (overlay)", lambda: col("VXX").pct_change() >= 0.20),
        ("below_ma20", "QQQ below MA20", lambda: col("QQQ") < col("MA20")),
        ("below_ma20_1pct", "QQQ <= MA20 - 1%", lambda: col("QQQ_over_MA20") <= -0.01),
        ("below_ma20_2pct", "QQQ <= MA20 - 2%", lambda: col("QQQ_over_MA20") <= -0.02),
        ("below_ma20_3pct", "QQQ <= MA20 - 3%", lambda: col("QQQ_over_MA20") <= -0.03),
        ("below_ma50", "QQQ below MA50", lambda: col("QQQ") < col("MA50")),
        ("dd20_m4", "DD20 <= -4%", lambda: col("DD20") <= -0.04),
        ("dd20_m6", "DD20 <= -6%", lambda: col("DD20") <= -0.06),
        ("dd20_m10", "DD20 <= -10%", lambda: col("DD20") <= -0.10),
        ("qqq_5d_m5", "QQQ 5D return < -5%", lambda: col("QQQ").pct_change(5) <= -0.05),
        ("qqq_5d_m8", "QQQ 5D return < -8%", lambda: col("QQQ").pct_change(5) <= -0.08),
        ("persist_below_ma20_ge5", "persist_below_MA20 >= 5", lambda: col("persist_below_MA20") >= 5),
        ("persist_below_ma20_ge10", "persist_below_MA20 >= 10", lambda: col("persist_below_MA20") >= 10),
        ("persist_below_ma20_ge15", "persist_below_MA20 >= 15", lambda: col("persist_below_MA20") >= 15),
        ("vol_expansion", "RV5/RV20 > 1.2", lambda: col("RV5_over_RV20") > 1.2),
        ("vol_compression", "RV5/RV20 < 0.8", lambda: col("RV5_over_RV20") < 0.8),
        (
            "term_backwardation",
            "VIX > VIX3M (when available)",
            lambda: (col("VIX") > col("VIX3M")) & col("VIX3M").notna(),
        ),
        (
            "term_steep_contango",
            "VIX3M/VIX > 1.15",
            lambda: (col("VIX3M") / col("VIX") > 1.15) & col("VIX3M").notna(),
        ),
        ("vix_above_25", "VIX > 25", lambda: col("VIX") > 25),
        ("vix_above_30", "VIX > 30", lambda: col("VIX") > 30),
        ("vix_above_40", "VIX > 40", lambda: col("VIX") > 40),
        ("vix_below_15", "VIX < 15", lambda: col("VIX") < 15),
        (
            "winning_state_phase_a",
            "belowMA>=1% & DD20<=-4% & persist_age>=15",
            lambda: (col("QQQ_over_MA20") <= -0.01)
            & (col("DD20") <= -0.04)
            & (col("persist_below_MA20") >= 15),
        ),
        (
            "mom_improve_while_below",
            "below MA20 & mom2_improve",
            lambda: (col("QQQ") < col("MA20")) & (col("mom2_improve") == True),  # noqa: E712
        ),
        (
            "vpz_falling_while_below",
            "below MA20 & VolPremium_z falling",
            lambda: (col("QQQ") < col("MA20")) & (col("VolPremium_z_falling") == True),  # noqa: E712
        ),
        ("spy_below_ma20", "SPY below its MA20 flag", lambda: col("SPY_below_MA20") == True),  # noqa: E712
        (
            "qqq_vxx_rel_shock",
            "VXX_rel_shock high (if present)",
            lambda: col("VXX_rel_shock") > col("VXX_rel_shock").quantile(0.95)
            if "VXX_rel_shock" in df.columns and col("VXX_rel_shock").notna().any()
            else pd.Series(False, index=df.index),
        ),
        (
            "corr_breakdown_proxy",
            "QQQ down >1% while VIX down (same day)",
            lambda: (col("QQQ_ret1") <= -0.01) & (col("VIX").pct_change() < 0),
        ),
        (
            "vol_dislocation_neg",
            "VolDislocation < -2 (if present)",
            lambda: col("VolDislocation") < -2
            if "VolDislocation" in df.columns
            else pd.Series(False, index=df.index),
        ),
    ]
    return [{"event_id": eid, "event_definition": desc, "_fn": fn} for eid, desc, fn in defs]


def _intervals(dates: pd.DatetimeIndex) -> np.ndarray:
    if len(dates) < 2:
        return np.array([])
    return np.diff(dates.values).astype("timedelta64[D]").astype(float)




def _onsets(mask: pd.Series) -> pd.Series:
    """Rising-edge True days (enter event / pulse day)."""
    s = mask.fillna(False).astype(bool)
    return s & ~s.shift(1, fill_value=False)

def _hazard_by_age(
    mask: pd.Series,
    regime_mask: pd.Series | None,
    buckets: list[tuple[int, int]],
) -> dict[str, Any]:
    """Crude hazard using days-since-last-True as age."""
    s = mask.fillna(False).astype(bool)
    ages: list[int] = []
    hits: list[int] = []
    last = -(10**9)
    for i, (idx, val) in enumerate(s.items()):
        age = i - last if last >= 0 else None
        in_regime = True if regime_mask is None else bool(regime_mask.loc[idx])
        if age is not None and in_regime:
            ages.append(int(age))
            hits.append(1 if val else 0)
        if val:
            last = i
    if not ages:
        return {"buckets": {}, "note": "insufficient"}
    ages_a = np.array(ages)
    hits_a = np.array(hits)
    bucket_out: dict[str, Any] = {}
    for lo, hi in buckets:
        m = (ages_a >= lo) & (ages_a <= hi)
        n = int(m.sum())
        bucket_out[f"{lo}-{hi}"] = {
            "n": n,
            "hazard": float(hits_a[m].mean()) if n else None,
        }
    early = bucket_out.get("1-5", {}).get("hazard")
    late = bucket_out.get("21-60", {}).get("hazard") or bucket_out.get("11-20", {}).get("hazard")
    delta = None
    if early is not None and late is not None:
        delta = float(late - early)
    return {
        "buckets": bucket_out,
        "late_minus_early_hazard": delta,
        "anti_gambler_note": (
            "Rising age alone is NOT a buy. Prefer P(event|state,age). "
            "If late-early<=0, age is not a timing edge."
        ),
    }


def compute_event_memory(df: pd.DataFrame, market_state: dict | None = None) -> dict[str, Any]:
    feat = _ensure_core_features(df)
    if "QQQ_ret1" not in feat.columns:
        feat["QQQ_ret1"] = feat["QQQ"].pct_change()

    asof = pd.Timestamp(feat.index[-1])
    is_mask = feat.index <= IS_END
    vol_exp = feat.get("RV5_over_RV20", pd.Series(np.nan, index=feat.index))
    vol_exp = (vol_exp > 1.2).fillna(False)
    below = (feat["QQQ"] < feat["MA20"]).fillna(False)

    events_out = []
    for d in _event_definitions(feat):
        eid = d["event_id"]
        try:
            series = d["_fn"]().reindex(feat.index).fillna(False).astype(bool)
        except Exception as e:
            events_out.append(
                {
                    "event_id": eid,
                    "event_definition": d["event_definition"],
                    "error": str(e),
                    "confidence": "none",
                }
            )
            continue

        onsets = _onsets(series)
        occ = onsets[onsets].index
        last_occ = str(occ[-1].date()) if len(occ) else None
        days_since = int((asof - occ[-1]).days) if len(occ) else None
        occ_is = onsets[is_mask & onsets].index
        intervals = _intervals(occ_is)
        median_iv = float(np.median(intervals)) if len(intervals) else None
        mean_iv = float(np.mean(intervals)) if len(intervals) else None
        dist = None
        if len(intervals):
            dist = {
                "p25": float(np.percentile(intervals, 25)),
                "p50": float(np.percentile(intervals, 50)),
                "p75": float(np.percentile(intervals, 75)),
                "p90": float(np.percentile(intervals, 90)),
                "n_intervals_IS": int(len(intervals)),
            }
        age_vs_median = None
        if days_since is not None and median_iv and median_iv > 0:
            age_vs_median = days_since / median_iv

        hazard_uncond = _hazard_by_age(series, None, [(1, 5), (6, 10), (11, 20), (21, 60), (61, 120)])
        hazard_vol_exp = _hazard_by_age(series, vol_exp, [(1, 5), (6, 10), (11, 20), (21, 60)])
        hazard_below = _hazard_by_age(series, below, [(1, 5), (6, 10), (11, 20), (21, 60)])

        events_out.append(
            {
                "event_id": eid,
                "event_definition": d["event_definition"],
                "last_occurrence": last_occ,
                "days_since_occurrence": days_since,
                "median_interval_IS": median_iv,
                "mean_interval_IS": mean_iv,
                "distribution_IS": dist,
                "age_over_median_IS": age_vs_median,
                "n_occurrences_full": int(onsets.sum()),
                "n_occurrences_IS": int((is_mask & onsets).sum()),
                "n_days_in_state_full": int(series.sum()),
                "current_regime": (market_state or {}).get("regime_hints") or [],
                "hazard_estimate_unconditional": hazard_uncond,
                "conditional_frequency": {
                    "given_vol_expansion": hazard_vol_exp,
                    "given_below_MA20": hazard_below,
                },
                "confidence": "Estimated"
                if len(intervals) >= 20
                else ("low_sample" if len(intervals) >= 5 else "insufficient"),
                "honesty": "NOT a buy signal when overdue. Use conditional hazard.",
            }
        )

    return {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "asof": str(asof.date()),
        "IS_end": IS_END,
        "evidence_tag": "Estimated intervals/hazard; Observed event triggers",
        "anti_gambler_rule": "P(Event|State,Age) over P(Event|Age); overdue≠buy",
        "events": events_out,
    }


def write_event_memory(df: pd.DataFrame, market_state: dict | None = None) -> dict[str, Any]:
    EVENTS.mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)
    mem = compute_event_memory(df, market_state)
    (EVENTS / "event_memory.json").write_text(json.dumps(mem, indent=2), encoding="utf-8")

    rows = [e for e in mem["events"] if e.get("days_since_occurrence") is not None]
    rows_sorted = sorted(rows, key=lambda e: e["days_since_occurrence"], reverse=True)
    lines = [
        f"# Event Clock Latest — asof {mem['asof']}",
        "",
        f"Generated UTC: {mem['generated_utc']}",
        "",
        f"**Honesty:** {mem['anti_gambler_rule']}",
        "",
        "傳統中文摘要：事件年齡只是時鐘，不是買入訊號；若 late−early hazard ≤ 0，年齡沒有 timing edge。",
        "",
        "| event_id | days_since | median_IS | age/median | n_IS | late−early haz | confidence |",
        "|---|---:|---:|---:|---:|---:|---|",
    ]
    for e in rows_sorted[:40]:
        haz = (e.get("hazard_estimate_unconditional") or {}).get("late_minus_early_hazard")
        haz_s = f"{haz:.4f}" if isinstance(haz, float) else "—"
        med = e.get("median_interval_IS")
        med_s = f"{med:.1f}" if isinstance(med, float) else "—"
        aom = e.get("age_over_median_IS")
        aom_s = f"{aom:.2f}" if isinstance(aom, float) else "—"
        lines.append(
            f"| `{e['event_id']}` | {e['days_since_occurrence']} | {med_s} | {aom_s} | "
            f"{e.get('n_occurrences_IS')} | {haz_s} | {e.get('confidence')} |"
        )
    lines.extend(["", "## Definitions (top by age)", ""])
    for e in rows_sorted[:15]:
        lines.append(f"- `{e['event_id']}`: {e['event_definition']}")
    (REPORTS / "event_clock_latest.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return mem
