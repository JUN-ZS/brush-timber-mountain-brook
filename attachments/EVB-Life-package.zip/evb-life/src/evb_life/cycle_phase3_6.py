"""Phase 3–6 cycle CLI."""
from __future__ import annotations

import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from . import (
    data_hub,
    evolution_engine,
    gene_store,
    hypothesis_lab,
    mass_backtest,
    state_engine,
    event_clock,
)
from .paths import REPORTS, ROOT, EVOLUTION, GENES


def _ymd_hkt() -> str:
    # user Asia/Hong_Kong UTC+8
    return (datetime.now(timezone.utc).astimezone()).strftime("%Y%m%d")


def run_phase3_6(
    target_genes: int = 10000,
    gen2_children: int = 2500,
) -> dict:
    REPORTS.mkdir(parents=True, exist_ok=True)
    (EVOLUTION / "progress").mkdir(parents=True, exist_ok=True)

    df = data_hub.load_or_build_market_data()
    state = state_engine.write_market_state(df)
    mem = event_clock.write_event_memory(df, state)
    gene_store.seed_phase_a_and_v01()

    p3 = hypothesis_lab.explode_population(target=target_genes, mutate_extra=1500, crossover_extra=500)
    p45 = mass_backtest.run_mass_backtest(progress_name="phase4_mass.json")
    # Gen2: mutate then screen ONLY children
    children = evolution_engine.mutate_promising_generation(n_children=gen2_children)
    gen2_summary = {"born": len(children)}
    if children:
        # Test children only, merge into population
        child_ids = {c["gene_id"] for c in children}
        # Reload pop — children already inserted as INCUBATING
        pop_all = gene_store.load_population()
        child_genes = [g for g in pop_all if g["gene_id"] in child_ids]
        mb2 = mass_backtest.run_mass_backtest(
            genes=child_genes, progress_name="phase6_gen2_mass.json"
        )
        gen2_summary["rescreen"] = mb2["summary"]
        # Merge: mass_backtest saved only child_genes survivors — NEED full merge
        # Fix: reload dead, merge non-child prior pop with new child results
        prior = [g for g in pop_all if g["gene_id"] not in child_ids]
        after_children = gene_store.load_population()  # only what mb saved = processed children leftover
        # mass_backtest overwrote population with only updated child set — restore prior + children leftover
        merged = prior + after_children
        # dedup
        seen = set()
        uniq = []
        for g in merged:
            if g["gene_id"] in seen:
                continue
            seen.add(g["gene_id"])
            uniq.append(g)
        gene_store.save_population(uniq)

    promo = evolution_engine.promote_demote_population()
    pool = evolution_engine.maintain_candidate_pool()

    pop = gene_store.load_population()
    dead = gene_store.load_dead()
    state_counts = dict(Counter(g.get("state") for g in pop))
    active_ids = [g["gene_id"] for g in pop if g.get("state") == "ACTIVE"]
    promising = [g for g in pop if g.get("state") == "PROMISING"]
    promising.sort(key=lambda x: float(x.get("fitness") or -999), reverse=True)

    tested = p45["summary"]["tested"] + (gen2_summary.get("rescreen") or {}).get("tested", 0)

    asof = state.get("asof") or "unknown"
    ymd = asof.replace("-", "")
    report_path = REPORTS / f"cycle_phase3_6_{ymd}.md"
    report = _build_report(
        state=state,
        mem=mem,
        pop=pop,
        dead=dead,
        p3=p3,
        p45_summary=p45["summary"],
        gen2=gen2_summary,
        pool=pool,
        tested=tested,
        active_ids=active_ids,
        promising=promising,
        state_counts=state_counts,
    )
    report_path.write_text(report, encoding="utf-8")
    (REPORTS / "cycle_phase3_6_latest.md").write_text(report, encoding="utf-8")

    out = {
        "report": str(report_path),
        "genes_tested": tested,
        "state_counts": state_counts,
        "active_ids": active_ids,
        "promising_ids": [g["gene_id"] for g in promising[:30]],
        "dead_bank": len(dead),
        "population": len(pop),
        "phase3": p3,
    }
    (EVOLUTION / "progress" / "cycle_phase3_6_result.json").write_text(
        json.dumps(out, indent=2, default=str), encoding="utf-8"
    )
    return out


def _build_report(**kw) -> str:
    state = kw["state"]
    mem = kw["mem"]
    pop = kw["pop"]
    dead = kw["dead"]
    p3 = kw["p3"]
    promising = kw["promising"]
    active_ids = kw["active_ids"]
    state_counts = kw["state_counts"]
    tested = kw["tested"]
    asof = state.get("asof")

    top = promising[:15]
    failed_sample = dead[:12] if dead else [g for g in pop if g.get("state") in ("WEAKENING", "DORMANT")][:12]

    # Pareto points
    pareto_rows = []
    for g in pop:
        if g.get("evidence_tag") == "Hypothetical":
            continue
        is_ = g.get("is") or {}
        if not is_.get("n"):
            continue
        pareto_rows.append(
            (
                g["gene_id"],
                is_.get("mean"),
                abs(is_.get("es5") or g.get("es95") or 0),
                is_.get("n"),
                g.get("fitness"),
                g.get("state"),
            )
        )
    pareto_rows.sort(key=lambda x: float(x[4] or -999), reverse=True)

    lines = [
        f"# EVB LIFEFORM Cycle Phase 3–6 — {asof}",
        "",
        f"Generated UTC: {datetime.now(timezone.utc).isoformat()}",
        f"Root: `{ROOT}`",
        "",
        "## 傳統中文摘要",
        "",
        f"- 本輪 Phase 3–6：基因爆炸 → 批量回測 → 穩健性 → 進化；測試約 **{tested}** 條。",
        f"- 狀態計數：`{json.dumps(state_counts, ensure_ascii=False)}`",
        f"- ACTIVE：{len(active_ids)}；PROMISING：{len(promising)}；dead_bank={len(dead)}。",
        "- Fitness ≠ CAGR；期權僅 Hypothetical 目錄；不過度宣稱。",
        "- 標籤：Observed 現貨報酬 / Derived 特徵 / Estimated 適性與 hazard / Hypothetical 期權。",
        "",
        "## 1 MARKET STATE",
        "",
        "```json",
        json.dumps(
            {
                "asof": state.get("asof"),
                "prices": state.get("prices"),
                "trend": state.get("trend"),
                "relative_vol": state.get("relative_vol"),
                "persistence": state.get("persistence"),
                "regime_hints": state.get("regime_hints"),
            },
            indent=2,
            default=str,
        ),
        "```",
        "",
        "## 2 NEW DISCOVERIES",
        "",
        f"- Phase3 born≈{p3.get('born_grid')} + mut={p3.get('mutations')} + xo={p3.get('crossovers')}",
        f"- Population size after explosion: {p3.get('population_size')}",
        f"- Mechanism tags: {p3.get('mechanism_tag_counts')}",
        f"- Gen2 children: {kw['gen2'].get('born')}",
        "",
        "## 3 TOP GENES",
        "",
    ]
    if not top and not active_ids:
        lines.append("_No PROMISING/ACTIVE yet — see TESTING survivors in candidate_pool._")
    for g in ( [x for x in pop if x['gene_id'] in active_ids] + top )[:20]:
        is_ = g.get("is") or {}
        oos = g.get("oos") or {}
        lines.append(
            f"- `{g['gene_id']}` **{g['state']}** fit={g.get('fitness')} "
            f"IS n={is_.get('n')} mean={is_.get('mean')} | OOS n={oos.get('n')} mean={oos.get('mean')}"
        )
    lines += ["", "## 4 FAILED GENES (sample)", ""]
    for g in failed_sample:
        lines.append(
            f"- `{g.get('gene_id')}` reason=`{(g.get('failure_reason') or '')[:160]}` "
            f"resurrect=`{(g.get('resurrection_condition') or '')[:80]}`"
        )
    lines += [
        "",
        "## 5 RESURRECTED",
        "",
        "_Stub schedule — full Phase 7 runs in cycle_full._",
        "",
        "## 6 TURNING BOUNDARIES",
        "",
    ]
    # crude: persist age distribution among positive-mean genes
    ages = []
    for g in pop:
        if (g.get("is") or {}).get("mean") and (g.get("is") or {}).get("mean") > 0:
            ages.append((g.get("entry_logic") or {}).get("persist_age"))
    lines.append(f"- Among positive IS-mean genes, persist_age values observed: {sorted(set(a for a in ages if a))[:20]} (Derived)")
    lines += [
        "",
        "## 7 EVENT CLOCK snapshot",
        "",
    ]
    rows = [e for e in mem.get("events", []) if e.get("days_since_occurrence") is not None]
    rows = sorted(rows, key=lambda e: e["days_since_occurrence"], reverse=True)[:12]
    lines.append("| event_id | days_since | median_IS | n_IS |")
    lines.append("|---|---:|---:|---:|")
    for e in rows:
        med = e.get("median_interval_IS")
        med_s = f"{med:.1f}" if isinstance(med, float) else "—"
        lines.append(
            f"| `{e['event_id']}` | {e['days_since_occurrence']} | {med_s} | {e.get('n_occurrences_IS')} |"
        )
    lines += [
        "",
        "## 8 OPTION STRUCTURE FRONTIER",
        "",
        "**blocked / Hypothetical catalog only** — no BS option P/L as fitness. OPRA-blocked.",
        "",
        "## 9 RISK TRANSFER",
        "",
        "N/A spot phase",
        "",
        "## 10 PARETO FRONTIER (EV vs |ES| vs n)",
        "",
        "| gene_id | EV(mean IS) | |ES5| | n | fitness | state |",
        "|---|---:|---:|---:|---:|---|",
    ]
    for row in pareto_rows[:25]:
        lines.append(
            f"| `{row[0]}` | {row[1]} | {row[2]} | {row[3]} | {row[4]} | {row[5]} |"
        )
    lines += ["", "## 11 OOS RESULTS", ""]
    oos_ok = [g for g in pop if (g.get("oos") or {}).get("n", 0) >= 12 and (g.get("oos") or {}).get("mean", -1) > 0]
    lines.append(f"- Genes with OOS n≥12 and mean>0: **{len(oos_ok)}** (Observed forwards)")
    for g in sorted(oos_ok, key=lambda x: float(x.get("fitness") or -999), reverse=True)[:15]:
        o = g.get("oos") or {}
        lines.append(f"- `{g['gene_id']}` OOS n={o.get('n')} mean={o.get('mean')} wr={o.get('wr')} state={g['state']}")
    lines += ["", "## 12 COST ROBUSTNESS", ""]
    c5 = sum(1 for g in pop if (g.get("cost_sensitivity") or {}).get("survive_5bps"))
    c10 = sum(1 for g in pop if (g.get("cost_sensitivity") or {}).get("survive_10bps"))
    lines.append(f"- survive 5bps: {c5} | survive 10bps: {c10} (among remaining population)")
    lines += ["", "## 13 TAIL RISK", ""]
    tails = sorted(
        [g for g in pop if g.get("es95")],
        key=lambda x: float(x.get("es95") or 0),
    )[:10]
    for g in tails:
        lines.append(f"- `{g['gene_id']}` es95={g.get('es95')} maxDD={g.get('max_drawdown')} n_IS={(g.get('is') or {}).get('n')}")
    lines += [
        "",
        "## 14 LIVE CANDIDATES",
        "",
        f"ACTIVE ids: {active_ids or '**(none — honesty)**'}",
        "",
        "## 15 SHADOW CANDIDATES (PROMISING)",
        "",
    ]
    for g in promising[:20]:
        lines.append(
            f"- `{g['gene_id']}` fit={g.get('fitness')} IS_n={(g.get('is') or {}).get('n')} "
            f"OOS_n={(g.get('oos') or {}).get('n')}"
        )
    if not promising:
        lines.append("_None yet._")
    qs = [
        "Which PROMISING genes fail leave-one-crisis when OOS crises are weighted equally?",
        "Does adding TermSlope filter improve OOS stability or only shrink n?",
        "Are anti-signal passes concentrated in a single transition family (OVERFIT proxy)?",
        "How does cost×10bps change the Pareto frontier of EV vs |ES|?",
        "Conditional hazard: does persist_age interaction with vol_expansion change Stage1 pass rate?",
        "Should gen3 mutate only diversity-tagged underrepresented mechanisms?",
        "OPRA-blocked: which spot PROMISING parents are priority for option expression stubs?",
        "Walk-forward: does expanding-window EV stay positive for top-10 fitness genes?",
        "Secondary split (≤2022 / 2023+) — which genes flip sign on OOS2?",
        "Event-clock conditional: do entries near pulse events inflate apparent EV?",
    ]
    lines += ["", "## 16 NEXT RESEARCH QUESTIONS", ""]
    for i, q in enumerate(qs, 1):
        lines.append(f"{i}. {q}")
    lines += [
        "",
        "## 17 COMPUTE ALLOCATION FOR NEXT ROUND",
        "",
        f"- Genes tested this round: **{tested}** (document if <20k: target was 8k–12k+gen2).",
        "- Next: deepen OOS walk-forward on PROMISING; gen3 diversity mutations; Phase 7 resurrection scan.",
        "- Do NOT spend compute on BS option P/L until OPRA.",
        "- Keep progress under `evolution/progress/` for recoverability.",
        "",
        f"candidate_pool: `genes/candidate_pool.json` n={kw['pool'].get('n')}",
        "",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    print(json.dumps(run_phase3_6(), indent=2, default=str))
