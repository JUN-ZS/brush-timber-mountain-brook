"""Phase 11 — Live Candidate Engine (cards; honesty if empty)."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from . import gene_store
from .evolution_engine import hard_active_gates
from .paths import REPORTS, EVOLUTION

PROGRESS = EVOLUTION / "progress"


def run_live_candidates() -> dict[str, Any]:
    REPORTS.mkdir(parents=True, exist_ok=True)
    pop = gene_store.load_population()
    active = [g for g in pop if g.get("state") == "ACTIVE"]
    promising = [g for g in pop if g.get("state") == "PROMISING"]
    # Re-verify ACTIVE gates
    true_active = []
    demoted = []
    for g in active:
        ok, reason = hard_active_gates(g)
        if ok:
            true_active.append(g)
        else:
            g["state"] = "PROMISING"
            g["failure_reason"] = f"ACTIVE_gate_fail:{reason}"
            demoted.append(g["gene_id"])
            gene_store.append_evolution(
                {
                    "event": "DEMOTION",
                    "gene_id": g["gene_id"],
                    "from_state": "ACTIVE",
                    "to_state": "PROMISING",
                    "reason": reason,
                }
            )
    if demoted:
        # persist demotions
        by = {g["gene_id"]: g for g in pop}
        for g in pop:
            if g["gene_id"] in {x["gene_id"] for x in true_active}:
                continue
            if g["gene_id"] in demoted:
                g["state"] = "PROMISING"
        gene_store.save_population(pop)
        promising = [g for g in gene_store.load_population() if g.get("state") == "PROMISING"]

    lines = [
        "# Live Candidates",
        "",
        f"Generated UTC: {datetime.now(timezone.utc).isoformat()}",
        "",
        "## Honesty",
        "",
        "- Fitness ≠ CAGR; gates require IS n≥30, OOS n≥15, both EV>0, anti fail, cost×2, not single-crisis.",
        "- Option genes are Hypothetical / OPRA-blocked — never live.",
        "- Shadow ≠ live capital.",
        "",
    ]
    if not true_active:
        lines += [
            "## ACTIVE",
            "",
            "**None.** No gene passed hard ACTIVE gates this cycle. (Observed honesty)",
            "",
        ]
    else:
        lines += ["## ACTIVE", ""]
        for g in true_active:
            lines += _card(g)
    lines += ["## SHADOW / PROMISING (not live)", ""]
    if not promising:
        lines.append("_No PROMISING genes._")
    else:
        for g in sorted(promising, key=lambda x: float(x.get("fitness") or -999), reverse=True)[:25]:
            lines += _card(g, prefix="PROMISING")

    path = REPORTS / "live_candidates.md"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    out = {
        "active_ids": [g["gene_id"] for g in true_active],
        "promising_n": len(promising),
        "demoted_from_active": demoted,
        "report": str(path),
    }
    PROGRESS.mkdir(parents=True, exist_ok=True)
    (PROGRESS / "phase11_live.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    return out


def _card(g: dict, prefix: str = "ACTIVE") -> list[str]:
    is_ = g.get("is") or {}
    oos = g.get("oos") or {}
    return [
        f"### `{g['gene_id']}` — {prefix}",
        "",
        f"- evidence: **{g.get('evidence_tag')}**",
        f"- fitness: `{g.get('fitness')}` (multi-dim, not CAGR)",
        f"- IS: n={is_.get('n')} mean={is_.get('mean')} wr={is_.get('wr')} es5={is_.get('es5')}",
        f"- OOS: n={oos.get('n')} mean={oos.get('mean')} wr={oos.get('wr')}",
        f"- maxDD linked: {g.get('max_drawdown')}",
        f"- cost: `{json.dumps(g.get('cost_sensitivity') or {}, default=str)[:200]}`",
        f"- hypothesis: {(g.get('hypothesis') or {}).get('statement', '')[:240]}",
        "",
    ]


if __name__ == "__main__":
    print(run_live_candidates())
