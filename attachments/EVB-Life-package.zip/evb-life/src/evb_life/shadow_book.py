"""Phase 10 — Shadow trading book (paper marks, no real money)."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

import pandas as pd

from . import gene_store, state_engine
from .paths import ROOT, DATA, EVOLUTION
from .mass_backtest import prepare_features, entry_mask_from_logic, build_shared_payload, _pool_init

PROGRESS = EVOLUTION / "progress"
SHADOW = ROOT / "shadow"


def run_shadow_book() -> dict[str, Any]:
    SHADOW.mkdir(parents=True, exist_ok=True)
    df = pd.read_parquet(DATA / "market_data.parquet")
    state = state_engine.compute_market_state(df)
    payload = build_shared_payload(df)
    _pool_init(payload)
    pop = gene_store.load_population()
    targets = [g for g in pop if g.get("state") in ("PROMISING", "ACTIVE")]
    asof = state.get("asof")
    entries = []
    for g in targets:
        el = dict(g.get("entry_logic") or {})
        if "ma_below" not in el:
            continue
        el.setdefault("horizon", (g.get("exit_logic") or {}).get("horizon_trading_days", 5))
        mask = entry_mask_from_logic(el)
        would_enter = bool(mask[-1]) if mask is not None and len(mask) else False
        entries.append(
            {
                "gene_id": g["gene_id"],
                "state": g["state"],
                "asof": asof,
                "would_enter_today": would_enter,
                "horizon": el.get("horizon"),
                "predicted_entry_fields": {
                    "ma_below": el.get("ma_below"),
                    "dd20": el.get("dd20"),
                    "persist_age": el.get("persist_age"),
                    "transitions": {
                        "1d_up": el.get("trans_1d_up"),
                        "mom_improve": el.get("trans_mom_improve"),
                        "vpz_fall": el.get("trans_vpz_fall"),
                        "vix_down": el.get("trans_vix_down"),
                    },
                },
                "fitness": g.get("fitness"),
                "is_n": (g.get("is") or {}).get("n"),
                "oos_n": (g.get("oos") or {}).get("n"),
                "capital": 0,
                "mark": "shadow_only",
            }
        )
    book = {
        "updated_utc": datetime.now(timezone.utc).isoformat(),
        "asof": asof,
        "n_shadow": len(entries),
        "live_capital": 0,
        "disclaimer": "Shadow / paper only — no real money",
        "entries": entries,
        "market_state_snapshot": {
            "regime_hints": state.get("regime_hints"),
            "persistence": state.get("persistence"),
            "trend": state.get("trend"),
        },
    }
    (SHADOW / "shadow_book.json").write_text(json.dumps(book, indent=2, default=str), encoding="utf-8")
    PROGRESS.mkdir(parents=True, exist_ok=True)
    (PROGRESS / "phase10_shadow.json").write_text(
        json.dumps({"n": len(entries), "asof": asof}, indent=2), encoding="utf-8"
    )
    return book


if __name__ == "__main__":
    print(json.dumps(run_shadow_book(), indent=2, default=str)[:2000])
