"""Event combo research — independent co-occurrence lift on IS window."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from itertools import combinations
from typing import Any

import numpy as np
import pandas as pd

from .event_clock import IS_END, _event_definitions, _onsets
from .paths import EVENTS
from .state_engine import _ensure_core_features

DEFAULT_K_DAYS = 5
TOP_N_EVENTS = 12
LIFT_THRESHOLD = 1.3
MIN_N_COMBO = 20


def _onset_dates(mask: pd.Series) -> pd.DatetimeIndex:
    on = _onsets(mask.fillna(False).astype(bool))
    return on[on].index


def _pair_stats(
    dates_a: pd.DatetimeIndex,
    dates_b: pd.DatetimeIndex,
    k: int,
    span_days: float,
) -> dict[str, Any]:
    """P(both within k days) vs independent baseline on calendar span."""
    if span_days <= 0 or len(dates_a) == 0 or len(dates_b) == 0:
        return {
            "n_a": int(len(dates_a)),
            "n_b": int(len(dates_b)),
            "n_joint": 0,
            "p_joint": None,
            "p_indep": None,
            "lift": None,
            "k_days": k,
        }

    a = np.array(dates_a.values.astype("datetime64[D]"), dtype="datetime64[D]")
    b = np.array(dates_b.values.astype("datetime64[D]"), dtype="datetime64[D]")
    # count A onsets that have at least one B within ±k days
    joint = 0
    for da in a:
        # searchsorted on sorted b
        lo = da - np.timedelta64(k, "D")
        hi = da + np.timedelta64(k, "D")
        i0 = np.searchsorted(b, lo, side="left")
        i1 = np.searchsorted(b, hi, side="right")
        if i1 > i0:
            joint += 1
    n_a = len(a)
    n_b = len(b)
    p_a = n_a / span_days
    p_b = n_b / span_days
    # window probability under independence: rough 2k+1 day window hit rate
    # P(B in window | A) ≈ 1 - (1-p_b)^(2k+1) ≈ min(1, p_b*(2k+1)) for small p
    win = 2 * k + 1
    p_b_in_win = 1.0 - (1.0 - min(1.0, p_b)) ** win
    p_indep = float(p_a * p_b_in_win)  # per-day joint density proxy; report rate per A
    p_joint = float(joint / n_a) if n_a else None  # empirical P(B near | A)
    lift = None
    if p_joint is not None and p_b_in_win > 0:
        lift = float(p_joint / p_b_in_win)
    return {
        "n_a": int(n_a),
        "n_b": int(n_b),
        "n_joint": int(joint),
        "p_joint": p_joint,
        "p_indep": float(p_b_in_win),
        "lift": lift,
        "k_days": k,
        "span_days": float(span_days),
    }


def _triple_stats(
    dates_a: pd.DatetimeIndex,
    dates_b: pd.DatetimeIndex,
    dates_c: pd.DatetimeIndex,
    k: int,
) -> dict[str, Any]:
    if not len(dates_a) or not len(dates_b) or not len(dates_c):
        return {"n_joint": 0, "n_anchor": 0, "p_joint": None, "k_days": k}
    a = np.array(dates_a.values.astype("datetime64[D]"), dtype="datetime64[D]")
    b = np.array(dates_b.values.astype("datetime64[D]"), dtype="datetime64[D]")
    c = np.array(dates_c.values.astype("datetime64[D]"), dtype="datetime64[D]")
    joint = 0
    for da in a:
        lo = da - np.timedelta64(k, "D")
        hi = da + np.timedelta64(k, "D")
        has_b = np.searchsorted(b, hi, side="right") > np.searchsorted(b, lo, side="left")
        has_c = np.searchsorted(c, hi, side="right") > np.searchsorted(c, lo, side="left")
        if has_b and has_c:
            joint += 1
    n_a = len(a)
    return {
        "n_joint": int(joint),
        "n_anchor": int(n_a),
        "p_joint": float(joint / n_a) if n_a else None,
        "k_days": k,
    }


def _leg_active(days_since: int | None, median: float | None, recently_fired_days: int = 5) -> bool:
    """ACTIVE today if recently fired OR currently aged toward/past median."""
    if days_since is None:
        return False
    if days_since <= recently_fired_days:
        return True
    if median is not None and median > 0 and days_since >= 0.7 * median:
        return True
    return False


def compute_event_combos(
    df: pd.DataFrame,
    event_memory: dict | None = None,
    k_days: int = DEFAULT_K_DAYS,
    top_n: int = TOP_N_EVENTS,
) -> dict[str, Any]:
    feat = _ensure_core_features(df)
    if "QQQ_ret1" not in feat.columns:
        feat["QQQ_ret1"] = feat["QQQ"].pct_change()

    is_mask = feat.index <= IS_END
    is_df = feat.loc[is_mask]
    span_days = float((is_df.index[-1] - is_df.index[0]).days) if len(is_df) > 1 else 0.0

    defs = _event_definitions(feat)
    onset_map: dict[str, pd.DatetimeIndex] = {}
    meta: dict[str, dict] = {}
    for d in defs:
        eid = d["event_id"]
        try:
            series = d["_fn"]().reindex(feat.index).fillna(False).astype(bool)
        except Exception:
            continue
        on_full = _onset_dates(series)
        on_is = on_full[on_full <= pd.Timestamp(IS_END)]
        onset_map[eid] = on_is
        meta[eid] = {
            "event_definition": d["event_definition"],
            "n_occurrences_IS": int(len(on_is)),
            "n_occurrences_full": int(len(on_full)),
            "last_occurrence": str(on_full[-1].date()) if len(on_full) else None,
            "days_since_occurrence": int((feat.index[-1] - on_full[-1]).days) if len(on_full) else None,
        }

    # enrich median from event_memory if present
    mem_by_id = {}
    if isinstance(event_memory, dict):
        for e in event_memory.get("events") or []:
            if isinstance(e, dict) and e.get("event_id"):
                mem_by_id[e["event_id"]] = e
                if e["event_id"] in meta:
                    meta[e["event_id"]]["median_interval_IS"] = e.get("median_interval_IS")
                    meta[e["event_id"]]["days_since_occurrence"] = e.get(
                        "days_since_occurrence", meta[e["event_id"]].get("days_since_occurrence")
                    )

    # pick top frequent by IS count
    ranked = sorted(meta.items(), key=lambda kv: kv[1].get("n_occurrences_IS") or 0, reverse=True)
    top_ids = [eid for eid, _ in ranked[:top_n] if (meta[eid].get("n_occurrences_IS") or 0) >= 5]

    pairs_out: list[dict[str, Any]] = []
    for a, b in combinations(top_ids, 2):
        st = _pair_stats(onset_map[a], onset_map[b], k_days, span_days)
        # also count from B side for symmetry note
        st_ba = _pair_stats(onset_map[b], onset_map[a], k_days, span_days)
        n_joint = min(st["n_joint"], st_ba["n_joint"]) if st["n_joint"] and st_ba["n_joint"] else st["n_joint"]
        # use max lift of either direction for flagging; report A→B primary by name order
        lift = st.get("lift")
        lift_ba = st_ba.get("lift")
        lift_best = None
        for lv in (lift, lift_ba):
            if lv is None:
                continue
            if lift_best is None or lv > lift_best:
                lift_best = lv
        n_for_flag = max(st["n_joint"], st_ba["n_joint"])
        flagged = (
            lift_best is not None
            and lift_best > LIFT_THRESHOLD
            and n_for_flag >= MIN_N_COMBO
        )
        ma = meta[a]
        mb = meta[b]
        active_a = _leg_active(ma.get("days_since_occurrence"), ma.get("median_interval_IS"))
        active_b = _leg_active(mb.get("days_since_occurrence"), mb.get("median_interval_IS"))
        pairs_out.append(
            {
                "combo_id": f"{a}+{b}",
                "legs": [a, b],
                "definitions": [ma.get("event_definition"), mb.get("event_definition")],
                "k_days": k_days,
                "n_joint": int(n_for_flag),
                "n_joint_a_anchor": st["n_joint"],
                "n_joint_b_anchor": st_ba["n_joint"],
                "p_joint_given_a": st.get("p_joint"),
                "p_indep_window": st.get("p_indep"),
                "lift": lift_best,
                "lift_a_to_b": lift,
                "lift_b_to_a": lift_ba,
                "evidence_tag": "Estimated" if flagged else (
                    "low_sample" if n_for_flag >= 5 else "insufficient"
                ),
                "flagged_lift": bool(flagged),
                "active_today": bool(active_a and active_b),
                "legs_active": {"a": active_a, "b": active_b},
                "days_since": {
                    "a": ma.get("days_since_occurrence"),
                    "b": mb.get("days_since_occurrence"),
                },
            }
        )

    pairs_out.sort(
        key=lambda r: (
            0 if r.get("flagged_lift") else 1,
            -(r.get("lift") or 0),
            -(r.get("n_joint") or 0),
        )
    )

    # optional top triples among flagged pair members (or top 6 events)
    triple_pool = top_ids[:6]
    triples_out: list[dict[str, Any]] = []
    for a, b, c in combinations(triple_pool, 3):
        st = _triple_stats(onset_map[a], onset_map[b], onset_map[c], k_days)
        if (st.get("n_joint") or 0) < 10:
            continue
        ma, mb, mc = meta[a], meta[b], meta[c]
        act = all(
            _leg_active(m.get("days_since_occurrence"), m.get("median_interval_IS"))
            for m in (ma, mb, mc)
        )
        triples_out.append(
            {
                "combo_id": f"{a}+{b}+{c}",
                "legs": [a, b, c],
                "k_days": k_days,
                "n_joint": st["n_joint"],
                "n_anchor": st["n_anchor"],
                "p_joint": st.get("p_joint"),
                "evidence_tag": "Estimated" if st["n_joint"] >= MIN_N_COMBO else "low_sample",
                "active_today": act,
                "note": "triple co-occurrence exploratory; no indep lift (higher-order)",
            }
        )
    triples_out.sort(key=lambda r: -(r.get("n_joint") or 0))

    return {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "asof": str(feat.index[-1].date()),
        "IS_end": IS_END,
        "k_days": k_days,
        "top_event_ids": top_ids,
        "lift_threshold": LIFT_THRESHOLD,
        "min_n_combo": MIN_N_COMBO,
        "evidence_tag": "Estimated pairwise lift on IS; Observed triggers",
        "honesty_zh": "配搭提升≠交易訊號；僅研究級共現統計。overdue≠buy。",
        "pairs": pairs_out,
        "triples": triples_out[:15],
        "top_flagged": [p for p in pairs_out if p.get("flagged_lift")][:20],
    }


def write_event_combos(
    df: pd.DataFrame,
    event_memory: dict | None = None,
    k_days: int = DEFAULT_K_DAYS,
) -> dict[str, Any]:
    EVENTS.mkdir(parents=True, exist_ok=True)
    payload = compute_event_combos(df, event_memory=event_memory, k_days=k_days)
    path = EVENTS / "event_combos.json"
    path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    return payload
