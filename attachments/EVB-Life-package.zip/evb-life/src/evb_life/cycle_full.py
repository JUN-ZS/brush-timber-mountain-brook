"""Full LIFEFORM cycle: Phase 1–2 + 3–6 + 7–11."""
from __future__ import annotations

import json
from collections import Counter
from datetime import datetime, timezone

from . import (
    cycle_phase1_2,
    cycle_phase3_6,
    gene_store,
    live_candidates,
    option_lab,
    resurrection,
    risk_auction,
    shadow_book,
)
from .paths import REPORTS, ROOT, EVOLUTION


def run_full(
    target_genes: int = 10000,
    gen2_children: int = 2500,
    skip_phase1_2: bool = False,
) -> dict:
    REPORTS.mkdir(parents=True, exist_ok=True)
    (EVOLUTION / "progress").mkdir(parents=True, exist_ok=True)

    p12 = None
    if not skip_phase1_2:
        p12 = cycle_phase1_2.run_cycle()

    p36 = cycle_phase3_6.run_phase3_6(
        target_genes=target_genes, gen2_children=gen2_children
    )
    p7 = resurrection.run_resurrection()
    p8 = option_lab.run_option_lab()
    p9 = risk_auction.run_risk_auction()
    p10 = shadow_book.run_shadow_book()
    p11 = live_candidates.run_live_candidates()

    pop = gene_store.load_population()
    dead = gene_store.load_dead()
    state_counts = dict(Counter(g.get("state") for g in pop))
    active = [g["gene_id"] for g in pop if g.get("state") == "ACTIVE"]
    promising = [g["gene_id"] for g in pop if g.get("state") == "PROMISING"]

    report_path = REPORTS / "LIFEFORM_FULL_CYCLE.md"
    report = _full_report(
        p12=p12,
        p36=p36,
        p7=p7,
        p8=p8,
        p9=p9,
        p10=p10,
        p11=p11,
        state_counts=state_counts,
        active=active,
        promising=promising,
        dead_n=len(dead),
        pop_n=len(pop),
    )
    report_path.write_text(report, encoding="utf-8")

    out = {
        "report": str(report_path),
        "genes_tested": p36.get("genes_tested"),
        "state_counts": state_counts,
        "active_ids": active,
        "promising_ids": promising[:40],
        "promising_n": len(promising),
        "dead_bank": len(dead),
        "population": len(pop),
        "phase3_6_report": p36.get("report"),
        "live_candidates_report": p11.get("report"),
        "shadow_book": str(ROOT / "shadow" / "shadow_book.json"),
        "option_frontier": p8.get("message"),
        "resurrected": p7.get("resurrected"),
    }
    (EVOLUTION / "progress" / "cycle_full_result.json").write_text(
        json.dumps(out, indent=2, default=str), encoding="utf-8"
    )
    return out


def _full_report(**kw) -> str:
    p36 = kw["p36"]
    p7 = kw["p7"]
    p8 = kw["p8"]
    p9 = kw["p9"]
    p10 = kw["p10"]
    p11 = kw["p11"]
    lines = [
        "# EVB LIFEFORM — FULL CYCLE (Phase 1–11)",
        "",
        f"Generated UTC: {datetime.now(timezone.utc).isoformat()}",
        f"Root: `{ROOT}`",
        "",
        "## 傳統中文摘要",
        "",
        f"- 全週期已跑完 Phase 1–11；基因測試約 **{p36.get('genes_tested')}**。",
        f"- 狀態：`{json.dumps(kw['state_counts'], ensure_ascii=False)}`",
        f"- ACTIVE={len(kw['active'])} PROMISING={kw.get('promising') and len(kw['promising'])} "
        f"pop={kw['pop_n']} dead_bank={kw['dead_n']}",
        "- 期權前沿：blocked / Hypothetical catalog only；禁止 BS fitness。",
        "- Shadow 無真金；Risk Auction 為 Estimated stub。",
        "",
        "## 1 MARKET STATE",
        "",
        f"See Phase1–2 / Phase3–6 reports. Phase3–6 report: `{p36.get('report')}`",
        "",
        "## 2 NEW DISCOVERIES",
        "",
        f"- Explosion + gen2; tested={p36.get('genes_tested')}",
        f"- Phase3 summary: `{json.dumps(p36.get('phase3') or {}, default=str)[:500]}`",
        "",
        "## 3 TOP GENES",
        "",
        f"- ACTIVE: {kw['active'] or '**(none)**'}",
        f"- PROMISING (first 20): {(kw['promising'] or [])[:20]}",
        "",
        "## 4 FAILED GENES",
        "",
        f"- dead_gene_bank size: {kw['dead_n']} (never deleted)",
        "",
        "## 5 RESURRECTED",
        "",
        f"- schedule_n: {p7.get('schedule_n')}",
        f"- resurrected: {json.dumps(p7.get('resurrected') or [], default=str)[:1500]}",
        f"- regime_hints: {p7.get('current_regime_hints')}",
        "",
        "## 6 TURNING BOUNDARIES",
        "",
        "_See cycle_phase3_6 report for persist_age boundary notes (Derived)._",
        "",
        "## 7 EVENT CLOCK",
        "",
        "_See `events/event_memory.json` / phase1_2 report._",
        "",
        "## 8 OPTION STRUCTURE FRONTIER",
        "",
        f"**{p8.get('message')}**",
        f"- n_structures={p8.get('n_structures')} stubs={p8.get('n_combo_stubs_materialized')} "
        f"theoretical_grid={p8.get('n_theoretical_grid')}",
        "- evidence_tag=Hypothetical / OPRA-blocked / fitness_scoring=FORBIDDEN",
        "",
        "## 9 RISK TRANSFER / RISK AUCTION",
        "",
        f"- {p9.get('risk_transfer')}",
        f"- allocations_n={len(p9.get('allocations') or [])} live_capital={p9.get('live_capital')}",
        f"- regime_state_probs (Estimated): {p9.get('regime_state_probs')}",
        "",
        "## 10 PARETO / SHADOW",
        "",
        f"- shadow entries: {p10.get('n_shadow')} asof={p10.get('asof')} capital=0",
        f"- path: `shadow/shadow_book.json`",
        "",
        "## 11 OOS / COST / TAIL",
        "",
        "_Detailed tables in `reports/cycle_phase3_6_*.md` sections 11–13._",
        "",
        "## 12 COST ROBUSTNESS",
        "",
        "_See Phase 3–6 report §12._",
        "",
        "## 13 TAIL RISK",
        "",
        "_See Phase 3–6 report §13._",
        "",
        "## 14 LIVE CANDIDATES",
        "",
        f"- true ACTIVE: {p11.get('active_ids') or '**(none — honesty)**'}",
        f"- report: `{p11.get('report')}`",
        "",
        "## 15 SHADOW CANDIDATES (PROMISING)",
        "",
        f"- n={p11.get('promising_n')} ids sample: {(kw['promising'] or [])[:25]}",
        "",
        "## 16 NEXT RESEARCH QUESTIONS",
        "",
        "1. Which resurrected genes keep OOS>0 after cost×2 on the latest window?",
        "2. Does regime_similarity threshold 0.55 over-trigger false resurrection?",
        "3. Gen3: mutate underrepresented mechanism tags only?",
        "4. Secondary OOS (2023+) sign-flip rate among PROMISING?",
        "5. Shadow would_enter_today cluster — correlated entries risk?",
        "6. Risk auction: should PROMISING get zero budget until ACTIVE?",
        "7. OPRA: priority parent list for option expression (still Hypothetical)?",
        "8. Anti-signal families that repeatedly also-pass → retire mechanism?",
        "9. Event-clock pulse proximity vs entry EV (Estimated conditional)?",
        "10. Walk-forward expanding window stability of top fitness genes?",
        "",
        "## 17 COMPUTE ALLOCATION FOR NEXT ROUND",
        "",
        f"- Tested this full cycle: **{p36.get('genes_tested')}** (8k–12k+gen2 class if <20k).",
        "- Next compute: PROMISING walk-forward depth > new random grid.",
        "- Resurrection retests weekly per next_review schedule.",
        "- No BS option scoring until OPRA EOD.",
        "",
        "## Artifact index",
        "",
        f"- `{p36.get('report')}`",
        f"- `{REPORTS / 'live_candidates.md'}`",
        f"- `{ROOT / 'shadow' / 'shadow_book.json'}`",
        f"- `{ROOT / 'risk' / 'risk_budget.json'}`",
        f"- `{ROOT / 'options' / 'option_library.json'}`",
        f"- `{ROOT / 'genes' / 'gene_population.json'}`",
        f"- `{ROOT / 'genes' / 'candidate_pool.json'}`",
        f"- `{ROOT / 'genes' / 'dead_gene_bank.json'}`",
        "",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    print(json.dumps(run_full(), indent=2, default=str))
