"""Market Data Hub — load / verify / version panel; write DATA_MANIFEST."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from .paths import DATA, EVB_HIST_SPOTS, RVTE_DATA

MARKET_PARQUET = DATA / "market_data.parquet"
MARKET_CSV = DATA / "market_data.csv"
MANIFEST = DATA / "DATA_MANIFEST.json"


def _file_sha256(path: Path) -> str | None:
    if not path.exists():
        return None
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _overlay_vxx(panel: pd.DataFrame) -> pd.DataFrame:
    """Merge VXX from evb-hist spots when available; prefer non-null overlay."""
    out = panel.copy()
    if "VXX" not in out.columns:
        out["VXX"] = pd.NA
    if not EVB_HIST_SPOTS.exists():
        return out
    spots = pd.read_csv(EVB_HIST_SPOTS, parse_dates=["Date"]).set_index("Date").sort_index()
    if "VXX" not in spots.columns:
        return out
    vxx = spots["VXX"].dropna()
    # Align index (normalize to date)
    out.index = pd.to_datetime(out.index)
    aligned = vxx.reindex(out.index)
    # Fill missing VXX from overlay; do not overwrite existing non-null with null
    out["VXX"] = out["VXX"].combine_first(aligned)
    # Where overlay has values and existing is NaN already handled; also refresh overlap from overlay
    mask = aligned.notna()
    out.loc[mask, "VXX"] = aligned.loc[mask]
    return out


def _rebuild_via_yfinance() -> pd.DataFrame:
    import yfinance as yf

    tickers = {
        "QQQ": "QQQ",
        "VIX": "^VIX",
        "VIX3M": "^VIX3M",
        "VIX9D": "^VIX9D",
        "VIX6M": "^VIX6M",
        "SPY": "SPY",
        "TLT": "TLT",
    }
    frames: dict[str, pd.Series] = {}
    qqq = yf.download("QQQ", start="1999-01-01", auto_adjust=True, progress=False)
    if isinstance(qqq.columns, pd.MultiIndex):
        qqq.columns = qqq.columns.get_level_values(0)
    base = qqq[["Open", "High", "Low", "Close", "Volume"]].copy()
    base.columns = ["QQQ_Open", "QQQ_High", "QQQ_Low", "QQQ", "QQQ_Volume"]
    for name, yahoo in tickers.items():
        if name == "QQQ":
            continue
        try:
            d = yf.download(yahoo, start="1999-01-01", auto_adjust=True, progress=False)
            if d is None or d.empty:
                continue
            if isinstance(d.columns, pd.MultiIndex):
                d.columns = d.columns.get_level_values(0)
            frames[name] = d["Close"].rename(name)
        except Exception:
            continue
    out = base
    for name, s in frames.items():
        out = out.join(s, how="left")
    out["VXX"] = pd.NA
    return out.sort_index()


def load_or_build_market_data(force_rebuild: bool = False) -> pd.DataFrame:
    """Prefer RVTE features/panel; else rebuild via yfinance; overlay VXX."""
    DATA.mkdir(parents=True, exist_ok=True)
    sources: list[dict[str, Any]] = []

    if not force_rebuild and MARKET_PARQUET.exists():
        df = pd.read_parquet(MARKET_PARQUET)
        df.index = pd.to_datetime(df.index)
        sources.append({"path": str(MARKET_PARQUET), "role": "cached"})
    elif (RVTE_DATA / "features.parquet").exists():
        df = pd.read_parquet(RVTE_DATA / "features.parquet")
        df.index = pd.to_datetime(df.index)
        sources.append(
            {
                "path": str(RVTE_DATA / "features.parquet"),
                "role": "rvte_features",
                "sha256": _file_sha256(RVTE_DATA / "features.parquet"),
            }
        )
        # Also note panel sources
        for name in (
            "QQQ_daily.parquet",
            "VIX_daily.parquet",
            "VIX3M_daily.parquet",
            "VIX9D_daily.parquet",
            "VIX6M_daily.parquet",
            "SPY_daily.parquet",
            "TLT_daily.parquet",
        ):
            p = RVTE_DATA / name
            if p.exists():
                sources.append({"path": str(p), "role": "rvte_series", "sha256": _file_sha256(p)})
    elif (RVTE_DATA / "panel_expanded.parquet").exists():
        df = pd.read_parquet(RVTE_DATA / "panel_expanded.parquet")
        df.index = pd.to_datetime(df.index)
        sources.append({"path": str(RVTE_DATA / "panel_expanded.parquet"), "role": "rvte_panel"})
    else:
        df = _rebuild_via_yfinance()
        sources.append({"path": "yfinance", "role": "rebuild", "start": "1999-01-01"})

    before_vxx = int(df["VXX"].notna().sum()) if "VXX" in df.columns else 0
    df = _overlay_vxx(df)
    after_vxx = int(df["VXX"].notna().sum()) if "VXX" in df.columns else 0
    if EVB_HIST_SPOTS.exists():
        sources.append(
            {
                "path": str(EVB_HIST_SPOTS),
                "role": "vxx_overlay",
                "sha256": _file_sha256(EVB_HIST_SPOTS),
                "vxx_nonnull_before": before_vxx,
                "vxx_nonnull_after": after_vxx,
            }
        )

    df = df.sort_index()
    df.to_parquet(MARKET_PARQUET)
    # CSV for durability / inspection (may be large)
    df.to_csv(MARKET_CSV)

    manifest = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "rows": int(len(df)),
        "start": str(df.index.min().date()) if len(df) else None,
        "end": str(df.index.max().date()) if len(df) else None,
        "columns": list(df.columns),
        "nonnull": {c: int(df[c].notna().sum()) for c in df.columns},
        "sources": sources,
        "evidence_tag": "Observed+Derived (features from RVTE if reused)",
        "splits": {
            "primary_IS_end": "2018-12-31",
            "primary_OOS_start": "2019-01-02",
            "secondary_IS_end": "2022-12-30",
            "secondary_OOS_start": "2023-01-03",
        },
        "output": {"parquet": str(MARKET_PARQUET), "csv": str(MARKET_CSV)},
        "version": "evb-life-market-v1",
    }
    MANIFEST.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return df


def verify_market_data(df: pd.DataFrame | None = None) -> dict[str, Any]:
    if df is None:
        df = pd.read_parquet(MARKET_PARQUET)
        df.index = pd.to_datetime(df.index)
    required = ["QQQ", "VIX"]
    missing = [c for c in required if c not in df.columns]
    gaps = []
    if "QQQ" in df.columns:
        q = df["QQQ"].isna().sum()
        if q:
            gaps.append(f"QQQ nulls={q}")
    return {
        "ok": not missing and len(df) > 1000,
        "missing_required": missing,
        "rows": len(df),
        "gaps": gaps,
        "end": str(df.index.max().date()) if len(df) else None,
    }


if __name__ == "__main__":
    d = load_or_build_market_data()
    print(verify_market_data(d))
