"""Phase 7 — Resurrection engine for DEAD/DORMANT genes."""
from __future__ import annotations

import json
from datetime import datetime, timezone, timedelta
from typing import Any

from . import gene_store, mass_backtest, state_engine
from .paths import EVOLUTION, DATA
import pandas as pd

PROGRESS = EVOLUTION / "progress"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def regime_similarity(state: dict, gene: dict) -> float:
    """Crude Estimated similarity 0–1 between current regime and gene's regime_features."""
    hints = set(state.get("regime_hints") or [])
    gtags = set(gene.get("regime_features") or [])
    gtags |= set((gene.get("hypothesis") or {}).get("mechanism_tags") or [])
    persist = (state.get("persistence") or {}).get("persist_below_MA20") or 0
    score = 0.0
    if "persistent_drawdown" in hints and (
        "persistent_drawdown" in gtags or "trend_persist" in gtags or "meanrev_fail" in gtags
    ):
        score += 0.5
    if persist and persist >= int((gene.get("entry_logic") or {}).get("persist_age", 99) or 99):
        score += 0.3
    vol = (state.get("relative_vol") or {}).get("label")
    if vol == "expansion" and "vol_rel" in gtags:
        score += 0.2
    if not hints and not gtags:
        score = 0.1
    return min(1.0, score)


def schedule_reviews(pop: list[dict], dead: list[dict]) -> list[dict]:
    """Fill next_review for DORMANT/DEAD."""
    base = datetime.now(timezone.utc)
    schedule = []
    for i, g in enumerate(dead + [x for x in pop if x.get("state") == "DORMANT"]):
        nxt = (base + timedelta(days=7 + (i % 28))).date().isoformat()
        g["next_review"] = nxt
        schedule.append(
            {
                "gene_id": g["gene_id"],
                "state": g.get("state"),
                "next_review": nxt,
                "resurrection_condition": g.get("resurrection_condition") or "",
            }
        )
    return schedule


def run_resurrection(similarity_threshold: float = 0.55) -> dict[str, Any]:
    PROGRESS.mkdir(parents=True, exist_ok=True)
    df = pd.read_parquet(DATA / "market_data.parquet")
    state = state_engine.compute_market_state(df)
    pop = gene_store.load_population()
    dead = gene_store.load_dead()
    schedule = schedule_reviews(pop, dead)
    gene_store.save_population(pop)
    gene_store.save_dead(dead)

    resurrected = []
    retest_results = []
    # Rank dead+dormant by similarity
    candidates = []
    for g in dead:
        sim = regime_similarity(state, g)
        candidates.append((sim, "dead", g))
    for g in pop:
        if g.get("state") == "DORMANT":
            sim = regime_similarity(state, g)
            candidates.append((sim, "dormant", g))
    candidates.sort(key=lambda x: x[0], reverse=True)

    # Only resurrect if similarity high AND spot-testable; cap to avoid thrash
    for sim, src, g in candidates[:15]:
        if sim < similarity_threshold:
            continue
        if g.get("evidence_tag") == "Hypothetical":
            continue
        el = g.get("entry_logic") or {}
        if "ma_below" not in el:
            continue
        try:
            if src == "dead":
                gene_store.resurrect(g["gene_id"], reason=f"regime_sim={sim:.2f}")
            else:
                gene_store.set_state(
                    g["gene_id"], "INCUBATING", reason=f"regime_sim={sim:.2f}", event="RESURRECTION"
                )
        except Exception as e:
            continue
        # Retest immediately
        payload = mass_backtest.build_shared_payload(df)
        mass_backtest._pool_init(payload)
        el = dict(el)
        el.setdefault("horizon", (g.get("exit_logic") or {}).get("horizon_trading_days", 5))
        res = mass_backtest.evaluate_entry_logic(el, g["gene_id"])
        retest_results.append({"gene_id": g["gene_id"], "sim": sim, "result": {
            "stage1": res["stage1_pass"],
            "fitness": res["fitness"],
            "IS1_n": res["IS1"]["n"],
            "OOS1_n": res["OOS1"]["n"],
            "suggested": (res.get("robustness") or {}).get("suggested_state"),
        }})
        # Apply gates on fresh population copy
        pop2 = gene_store.load_population()
        for i, gg in enumerate(pop2):
            if gg["gene_id"] != g["gene_id"]:
                continue
            ug = mass_backtest.apply_result_to_gene(gg, res)
            sug = ug.pop("_suggested_state", "TESTING")
            ug.pop("_stage1_pass", None)
            ug.pop("_killed", None)
            ok_active = False
            if sug == "PROMISING":
                from .evolution_engine import hard_active_gates

                ok_active, _ = hard_active_gates(ug)
                ug["state"] = "ACTIVE" if ok_active else "PROMISING"
            elif sug == "DEAD":
                ug["state"] = "DEAD"
            elif sug == "DORMANT":
                ug["state"] = "DORMANT"
            elif sug == "WEAKENING":
                ug["state"] = "WEAKENING"
            else:
                ug["state"] = "TESTING"
            pop2[i] = ug
            resurrected.append(
                {
                    "gene_id": ug["gene_id"],
                    "sim": sim,
                    "new_state": ug["state"],
                    "fitness": ug.get("fitness"),
                }
            )
            gene_store.append_evolution(
                {
                    "event": "RESURRECTION",
                    "gene_id": ug["gene_id"],
                    "to_state": ug["state"],
                    "reason": f"retested_after_sim={sim:.2f}",
                    "result": ug["state"],
                }
            )
            break
        # If ended DEAD, move to bank
        final = [x for x in pop2 if x["gene_id"] == g["gene_id"]]
        if final and final[0]["state"] == "DEAD":
            dead2 = gene_store.load_dead()
            if final[0]["gene_id"] not in {d["gene_id"] for d in dead2}:
                dead2.append(final[0])
                gene_store.save_dead(dead2)
            pop2 = [x for x in pop2 if x["gene_id"] != g["gene_id"]]
        gene_store.save_population(pop2)

    out = {
        "ts": _now(),
        "current_regime_hints": state.get("regime_hints"),
        "schedule_n": len(schedule),
        "schedule_sample": schedule[:20],
        "resurrected": resurrected,
        "retest_results": retest_results,
        "similarity_threshold": similarity_threshold,
        "note": "Estimated regime similarity; resurrected genes must pass gates again",
    }
    (PROGRESS / "phase7_resurrection.json").write_text(json.dumps(out, indent=2, default=str), encoding="utf-8")
    return out


if __name__ == "__main__":
    print(json.dumps(run_resurrection(), indent=2, default=str)[:2000])
