"""Phase 4–5 — Mass backtest + robustness gates."""
from __future__ import annotations

import json
import math
from datetime import datetime, timezone
from multiprocessing import Pool, cpu_count
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from . import gene_store
from .paths import EVOLUTION, EXPERIMENTS, DATA

PROGRESS = EVOLUTION / "progress"
IS1_END = pd.Timestamp("2018-12-31")
OOS1_START = pd.Timestamp("2019-01-02")
IS2_END = pd.Timestamp("2022-12-30")
OOS2_START = pd.Timestamp("2023-01-03")
CRISIS = {
    "2008": (pd.Timestamp("2008-09-01"), pd.Timestamp("2009-03-31")),
    "2020": (pd.Timestamp("2020-02-15"), pd.Timestamp("2020-04-30")),
    "2022": (pd.Timestamp("2022-01-01"), pd.Timestamp("2022-12-31")),
}
COST_5BPS = 0.0005
COST_10BPS = 0.0010

_SHARED: dict[str, Any] = {}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def episodes_from_mask(entry: np.ndarray, horizon: int) -> np.ndarray:
    idx = []
    i = 0
    n = len(entry)
    while i < n:
        if entry[i] and i + horizon < n:
            idx.append(i)
            i += horizon
            continue
        i += 1
    return np.array(idx, dtype=int)


def trade_stats(rets: np.ndarray) -> dict:
    if len(rets) == 0:
        return {
            "n": 0,
            "mean": float("nan"),
            "median": float("nan"),
            "wr": float("nan"),
            "es5": float("nan"),
            "std": float("nan"),
            "tlike": float("nan"),
        }
    mean = float(np.mean(rets))
    med = float(np.median(rets))
    wr = float(np.mean(rets > 0))
    k = max(1, int(np.ceil(0.05 * len(rets))))
    es = float(np.mean(np.sort(rets)[:k]))
    std = float(np.std(rets, ddof=1)) if len(rets) > 1 else float("nan")
    tlike = mean / (std / math.sqrt(len(rets))) if std and std > 0 else float("nan")
    return {"n": int(len(rets)), "mean": mean, "median": med, "wr": wr, "es5": es, "std": std, "tlike": tlike}


def linked_maxdd(rets: np.ndarray) -> float:
    if len(rets) == 0:
        return float("nan")
    eq = np.cumsum(rets)
    peak = np.maximum.accumulate(eq)
    return float((eq - peak).min())


def prepare_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.index = pd.to_datetime(out.index)
    if "VIX_falling" not in out.columns and "VIX" in out.columns:
        out["VIX_falling"] = out["VIX"].diff() < 0
    for h in (5, 10, 15, 20):
        col = f"fwd{h}"
        if col not in out.columns:
            out[col] = out["QQQ"].shift(-h) / out["QQQ"] - 1.0
    return out


def build_shared_payload(df: pd.DataFrame) -> dict:
    feat = prepare_features(df)
    dates = feat.index.to_numpy(dtype="datetime64[ns]")

    def arr(col, default=False):
        if col not in feat.columns:
            if isinstance(default, bool):
                return np.zeros(len(feat), dtype=bool)
            return np.full(len(feat), np.nan)
        s = feat[col]
        if s.dtype == bool or s.dtype == object:
            return s.fillna(False).astype(bool).to_numpy()
        return s.to_numpy(dtype=float)

    payload = {
        "dates": dates,
        "QQQ_over_MA20": arr("QQQ_over_MA20"),
        "DD20": arr("DD20"),
        "persist_below_MA20": arr("persist_below_MA20"),
        "VolPremium_z": arr("VolPremium_z"),
        "backwardation": arr("backwardation"),
        "TermSlope": arr("TermSlope"),
        "QQQ_1d_up": arr("QQQ_1d_up", False),
        "mom2_improve": arr("mom2_improve", False),
        "VolPremium_z_falling": arr("VolPremium_z_falling", False),
        "VIX_falling": arr("VIX_falling", False),
        "fwd5": arr("fwd5"),
        "fwd10": arr("fwd10"),
        "fwd15": arr("fwd15"),
        "fwd20": arr("fwd20"),
    }
    # boolize transitions if they came as float
    for k in ("QQQ_1d_up", "mom2_improve", "VolPremium_z_falling", "VIX_falling"):
        payload[k] = np.asarray(payload[k]).astype(bool)
    if "backwardation" in feat.columns:
        payload["backwardation"] = np.nan_to_num(arr("backwardation"), nan=0.0)
    return payload


def _pool_init(payload):
    _SHARED.clear()
    _SHARED.update(payload)


def entry_mask_from_logic(el: dict) -> np.ndarray | None:
    ma = _SHARED["QQQ_over_MA20"]
    dd = _SHARED["DD20"]
    age = _SHARED["persist_below_MA20"]
    ma_below = float(el.get("ma_below", 0.01))
    dd20 = float(el.get("dd20", -0.04))
    if dd20 > 0:
        dd20 = -dd20
    persist = int(el.get("persist_age", el.get("persist_age_min", 5)))
    m = (ma <= -ma_below) & (dd <= dd20) & (age >= persist)
    vpz = float(el.get("vpz", 0) or 0)
    if vpz > 0:
        m = m & (_SHARED["VolPremium_z"] > vpz)
    if int(el.get("use_back", 0) or 0):
        m = m & (_SHARED["backwardation"] == 1)
    if int(el.get("use_term", 0) or 0):
        # TermSlope < 1 ≈ contango inverted / short end rich
        m = m & (_SHARED["TermSlope"] < 1.0)

    anti = int(el.get("anti", 0) or 0)
    mom = _SHARED["mom2_improve"]
    mom_use = (~mom) if anti else mom

    parts = []
    if int(el.get("trans_1d_up", 0) or 0):
        parts.append(_SHARED["QQQ_1d_up"])
    if int(el.get("trans_mom_improve", 0) or 0):
        parts.append(mom_use)
    if int(el.get("trans_vpz_fall", 0) or 0):
        parts.append(_SHARED["VolPremium_z_falling"])
    if int(el.get("trans_vix_down", 0) or 0):
        parts.append(_SHARED["VIX_falling"])
    # V01-style string reversal
    rev = el.get("reversal")
    if isinstance(rev, str) and "QQQ_1d_up" in rev:
        parts.append(_SHARED["QQQ_1d_up"])
        if "VIX" in rev:
            parts.append(_SHARED["VIX_falling"])

    if not parts:
        return None
    trans = parts[0]
    for p in parts[1:]:
        trans = trans & p
    return (m & trans)


def fitness_score(mean_is: float, mean_oos: float, es5: float, n: int, stab: float) -> float:
    """EV * stability_proxy / (1+|ES|) * log(1+n) — NEVER CAGR alone."""
    if not np.isfinite(mean_is) or mean_is <= 0 or n <= 0:
        return -999.0
    es = es5 if np.isfinite(es5) else -1.0
    ev = mean_is if not (np.isfinite(mean_oos) and mean_oos > 0) else (mean_is * max(mean_oos, 1e-9)) ** 0.5
    return float(ev * (0.35 + 0.65 * stab) / (1.0 + abs(es)) * math.log1p(n))


def evaluate_entry_logic(el: dict, gene_id: str = "") -> dict:
    h = int(el.get("horizon") or el.get("horizon_trading_days") or 5)
    if h not in (5, 10, 15, 20):
        h = 5
    mask = entry_mask_from_logic(el)
    empty = trade_stats(np.array([]))
    if mask is None:
        return {
            "gene_id": gene_id,
            "killed": ["no_transition"],
            "stage1_pass": False,
            "IS1": empty,
            "OOS1": empty,
            "IS2": empty,
            "OOS2": empty,
            "fitness": -999.0,
            "maxdd_IS1": float("nan"),
            "robustness": {},
        }
    entry = np.asarray(mask, dtype=bool)
    fwd = _SHARED[f"fwd{h}"]
    dates = _SHARED["dates"]
    ep = episodes_from_mask(entry, h)
    if len(ep) == 0:
        return {
            "gene_id": gene_id,
            "killed": ["no_episodes"],
            "stage1_pass": False,
            "IS1": empty,
            "OOS1": empty,
            "IS2": empty,
            "OOS2": empty,
            "fitness": -999.0,
            "maxdd_IS1": float("nan"),
            "robustness": {},
        }
    ep_dates = dates[ep]
    ep_rets = fwd[ep]

    def clean(mask_):
        r = ep_rets[mask_]
        d = ep_dates[mask_]
        ok = np.isfinite(r)
        return r[ok], d[ok]

    is1_r, is1_d = clean(ep_dates <= np.datetime64(IS1_END))
    oos1_r, oos1_d = clean(ep_dates >= np.datetime64(OOS1_START))
    is2_r, is2_d = clean(ep_dates <= np.datetime64(IS2_END))
    oos2_r, oos2_d = clean(ep_dates >= np.datetime64(OOS2_START))

    s_is1 = trade_stats(is1_r)
    s_oos1 = trade_stats(oos1_r)
    s_is2 = trade_stats(is2_r)
    s_oos2 = trade_stats(oos2_r)
    mdd = linked_maxdd(is1_r)

    killed = []
    # Stage1 kill: n_IS<25 or mean_IS<=0
    stage1_pass = s_is1["n"] >= 25 and np.isfinite(s_is1["mean"]) and s_is1["mean"] > 0
    if s_is1["n"] < 25:
        killed.append("stage1_n_IS<25")
    if not (np.isfinite(s_is1["mean"]) and s_is1["mean"] > 0):
        killed.append("stage1_mean_IS<=0")

    robustness: dict[str, Any] = {}
    notes = []
    state_hint = "TESTING"

    if stage1_pass:
        # OOS
        oos_ok = s_oos1["n"] >= 12 and np.isfinite(s_oos1["mean"]) and s_oos1["mean"] > 0
        robustness["oos"] = {"pass": oos_ok, "n": s_oos1["n"], "mean": s_oos1["mean"]}
        if not oos_ok:
            notes.append("OOS_fail_or_thin")
            state_hint = "WEAKENING" if s_oos1["n"] >= 12 else "PROMISING"  # thin → not ACTIVE; PROMISING only if mean>0 thin?
            if s_oos1["n"] < 12:
                state_hint = "TESTING"  # keep testing / will demote to WEAK later
            elif not (s_oos1["mean"] > 0):
                state_hint = "WEAKENING"

        # Cost stress
        mean5 = s_is1["mean"] - COST_5BPS
        mean10 = s_is1["mean"] - COST_10BPS
        oos5 = (s_oos1["mean"] - COST_5BPS) if s_oos1["n"] else float("nan")
        oos10 = (s_oos1["mean"] - COST_10BPS) if s_oos1["n"] else float("nan")
        cost_ok_5 = mean5 > 0 and (not np.isfinite(oos5) or oos5 > 0)
        cost_ok_10 = mean10 > 0 and (not np.isfinite(oos10) or oos10 > 0)
        robustness["cost"] = {
            "mean_is_5bps": mean5,
            "mean_is_10bps": mean10,
            "oos_5bps": oos5,
            "oos_10bps": oos10,
            "survive_5bps": cost_ok_5,
            "survive_10bps": cost_ok_10,
        }
        if not cost_ok_5:
            notes.append("FRAGILE_cost_5bps")
            state_hint = "DORMANT"
            killed.append("cost_fragile")
        elif not cost_ok_10:
            notes.append("FRAGILE_cost_10bps")
            # soft fragility — WEAKENING not instant kill
            if state_hint not in ("DORMANT", "DEAD"):
                state_hint = "WEAKENING"

        # Leave-one-crisis
        crisis_results = {}
        fail_crises = []
        for cname, (c0, c1) in CRISIS.items():
            keep = ~((is1_d >= np.datetime64(c0)) & (is1_d <= np.datetime64(c1)))
            st = trade_stats(is1_r[keep])
            crisis_results[cname] = {"n": st["n"], "mean": st["mean"]}
            if st["n"] >= 10 and not (st["mean"] > 0):
                fail_crises.append(cname)
                notes.append(f"fail_without_{cname}")
        crisis_only = bool(s_is1["mean"] > 0 and len(fail_crises) == 1)
        robustness["leave_one_crisis"] = {
            "results": crisis_results,
            "fail_crises": fail_crises,
            "single_crisis_driven": crisis_only,
        }
        if crisis_only:
            notes.append(f"single_crisis_{fail_crises[0]}")
            if state_hint not in ("DORMANT", "DEAD"):
                state_hint = "WEAKENING"

        # Anti-signal: flip mom transition
        anti_el = dict(el)
        anti_el["anti"] = 1
        # If gene doesn't use mom, flip 1d_up instead
        if not int(el.get("trans_mom_improve", 0) or 0):
            anti_el["trans_1d_up"] = 1 - int(el.get("trans_1d_up", 0) or 0)
            anti_el["anti"] = 0
        anti_mask = entry_mask_from_logic(anti_el)
        anti_pass = False
        if anti_mask is not None:
            a_ep = episodes_from_mask(np.asarray(anti_mask, dtype=bool), h)
            if len(a_ep):
                a_dates = dates[a_ep]
                a_rets = fwd[a_ep]
                a_is = a_rets[(a_dates <= np.datetime64(IS1_END)) & np.isfinite(a_rets)]
                a_oos = a_rets[(a_dates >= np.datetime64(OOS1_START)) & np.isfinite(a_rets)]
                a_is_s = trade_stats(a_is)
                a_oos_s = trade_stats(a_oos)
                anti_pass = (
                    a_is_s["n"] >= 25
                    and a_is_s["mean"] > 0
                    and a_oos_s["n"] >= 12
                    and a_oos_s["mean"] > 0
                )
                robustness["anti_signal"] = {
                    "IS": a_is_s,
                    "OOS": a_oos_s,
                    "also_passes": anti_pass,
                }
                if anti_pass:
                    notes.append("OVERFIT_PROXY_anti_also_passes")
                    killed.append("anti_also_passes")
                    state_hint = "DEAD"
            else:
                robustness["anti_signal"] = {"also_passes": False, "note": "no_anti_episodes"}
        else:
            robustness["anti_signal"] = {"also_passes": False, "note": "no_anti_mask"}

        # Walk-forward lite: 2-block on IS1 (pre-2012 vs 2012-2018)
        mid = np.datetime64(pd.Timestamp("2012-01-01"))
        b1 = trade_stats(is1_r[is1_d < mid])
        b2 = trade_stats(is1_r[is1_d >= mid])
        wf_ok = (
            b1["n"] >= 8
            and b2["n"] >= 8
            and np.isfinite(b1["mean"])
            and np.isfinite(b2["mean"])
            and b1["mean"] > 0
            and b2["mean"] > 0
        )
        robustness["walk_forward_lite"] = {"block1": b1, "block2": b2, "pass": wf_ok}
        if not wf_ok:
            notes.append("walk_forward_lite_fail")

        # Stability proxy
        stab = 0.0
        if s_oos1["n"] and s_oos1["mean"] > 0:
            stab += 0.4
        if s_oos2["n"] and s_oos2["mean"] > 0:
            stab += 0.3
        if wf_ok:
            stab += 0.2
        if cost_ok_10:
            stab += 0.1
        fit = fitness_score(s_is1["mean"], s_oos1["mean"], s_is1["es5"], s_is1["n"], stab)

        # Hard ACTIVE gates checked later in evolution; here assign interim
        if state_hint == "TESTING" and oos_ok and cost_ok_5 and not anti_pass and not crisis_only:
            state_hint = "PROMISING"
    else:
        fit = -999.0
        state_hint = "DEAD" if s_is1["n"] >= 5 else "DEAD"
        notes.append("stage1_kill")

    robustness["adversarial_notes"] = notes
    robustness["suggested_state"] = state_hint

    return {
        "gene_id": gene_id,
        "horizon": h,
        "killed": killed,
        "stage1_pass": stage1_pass,
        "IS1": s_is1,
        "OOS1": s_oos1,
        "IS2": s_is2,
        "OOS2": s_oos2,
        "fitness": fit if stage1_pass else -999.0,
        "maxdd_IS1": mdd,
        "robustness": robustness,
        "es95": s_is1.get("es5", float("nan")),
    }


def _worker(item: tuple[str, dict]) -> dict:
    gene_id, el = item
    return evaluate_entry_logic(el, gene_id)


def is_spot_testable(g: dict) -> bool:
    if g.get("evidence_tag") == "Hypothetical":
        return False
    el = g.get("entry_logic") or {}
    if el.get("inherits"):
        return False
    if "ma_below" not in el:
        return False
    return True


def apply_result_to_gene(g: dict, res: dict) -> dict:
    g = dict(g)
    g["state"] = "TESTING"
    g["last_test"] = _now()
    g["is"] = {
        "n": res["IS1"]["n"],
        "mean": res["IS1"]["mean"],
        "wr": res["IS1"]["wr"],
        "es5": res["IS1"]["es5"],
        "split": "primary_IS_end_2018-12-31",
        "secondary_IS": res["IS2"],
    }
    g["oos"] = {
        "n": res["OOS1"]["n"],
        "mean": res["OOS1"]["mean"],
        "wr": res["OOS1"]["wr"],
        "tlike": res["OOS1"]["tlike"],
        "secondary_OOS": res["OOS2"],
    }
    g["sample_count"] = int(res["IS1"]["n"] + res["OOS1"]["n"])
    g["fitness"] = float(res["fitness"]) if np.isfinite(res["fitness"]) else -999.0
    g["max_drawdown"] = float(res["maxdd_IS1"]) if np.isfinite(res.get("maxdd_IS1", np.nan)) else 0.0
    g["es95"] = float(res["es95"]) if np.isfinite(res.get("es95", np.nan)) else 0.0
    rob = res.get("robustness") or {}
    g["cost_sensitivity"] = rob.get("cost") or {}
    g["regime_stability"] = {
        "leave_one_crisis": rob.get("leave_one_crisis"),
        "walk_forward_lite": rob.get("walk_forward_lite"),
        "anti_signal": rob.get("anti_signal"),
    }
    g["walk_forward"] = rob.get("walk_forward_lite") or {}
    notes = rob.get("adversarial_notes") or []
    sug = rob.get("suggested_state") or "TESTING"
    g["_suggested_state"] = sug
    g["_stage1_pass"] = res.get("stage1_pass", False)
    g["_killed"] = res.get("killed") or []
    if sug == "DEAD" or (not res.get("stage1_pass")):
        g["failure_reason"] = ";".join((res.get("killed") or []) + notes)[:500]
        if "anti" in g["failure_reason"] or "OVERFIT" in g["failure_reason"]:
            g["resurrection_condition"] = "revisit if anti-signal fails under new regime features"
        elif "cost" in g["failure_reason"]:
            g["resurrection_condition"] = "if round-trip costs fall below 5bps or EV rises"
        elif "stage1" in g["failure_reason"]:
            g["resurrection_condition"] = "if n_IS grows or mean_IS turns positive with same mechanism"
        else:
            g["resurrection_condition"] = "regime similarity high + retest OOS/cost/anti"
    elif sug == "DORMANT":
        g["failure_reason"] = ";".join(notes)[:500]
        g["resurrection_condition"] = "cost environment improves OR EV after cost >0 on retest"
    elif sug == "WEAKENING":
        g["failure_reason"] = ";".join(notes)[:500]
        g["resurrection_condition"] = ""
    return g


def run_mass_backtest(
    genes: list[dict] | None = None,
    n_workers: int | None = None,
    progress_name: str = "phase4_mass.json",
) -> dict[str, Any]:
    PROGRESS.mkdir(parents=True, exist_ok=True)
    EXPERIMENTS.mkdir(parents=True, exist_ok=True)
    df = pd.read_parquet(DATA / "market_data.parquet")
    payload = build_shared_payload(df)
    pop = genes if genes is not None else gene_store.load_population()
    jobs = []
    for g in pop:
        if not is_spot_testable(g):
            continue
        el = dict(g.get("entry_logic") or {})
        if "horizon" not in el:
            el["horizon"] = (g.get("exit_logic") or {}).get("horizon_trading_days", 5)
        jobs.append((g["gene_id"], el))

    n_workers = n_workers or max(1, min(cpu_count(), 8))
    results = []
    chunk = max(50, len(jobs) // (n_workers * 4) or 50)
    with Pool(processes=n_workers, initializer=_pool_init, initargs=(payload,)) as pool:
        for i, res in enumerate(pool.imap_unordered(_worker, jobs, chunksize=chunk)):
            results.append(res)
            if (i + 1) % 500 == 0 or (i + 1) == len(jobs):
                prog = {
                    "done": i + 1,
                    "total": len(jobs),
                    "ts": _now(),
                }
                (PROGRESS / progress_name).write_text(json.dumps(prog), encoding="utf-8")

    by_id = {r["gene_id"]: r for r in results}
    # Write experiment log
    log_path = EXPERIMENTS / "experiment_log.jsonl"
    with log_path.open("a", encoding="utf-8") as f:
        for r in results:
            row = {
                "ts": _now(),
                "gene_id": r["gene_id"],
                "stage1_pass": r["stage1_pass"],
                "fitness": r["fitness"],
                "IS1_n": r["IS1"]["n"],
                "IS1_mean": r["IS1"]["mean"],
                "OOS1_n": r["OOS1"]["n"],
                "OOS1_mean": r["OOS1"]["mean"],
                "IS2_n": r["IS2"]["n"],
                "IS2_mean": r["IS2"]["mean"],
                "killed": r["killed"],
                "suggested": (r.get("robustness") or {}).get("suggested_state"),
                "maxdd_IS1": r.get("maxdd_IS1"),
            }
            f.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")

    # Update population in memory
    updated = []
    dead_bank = gene_store.load_dead()
    dead_ids = {d["gene_id"] for d in dead_bank}
    survivors_stage1 = 0
    for g in pop:
        if g["gene_id"] not in by_id:
            updated.append(g)
            continue
        ug = apply_result_to_gene(g, by_id[g["gene_id"]])
        sug = ug.pop("_suggested_state", "TESTING")
        stage1 = ug.pop("_stage1_pass", False)
        killed = ug.pop("_killed", [])
        if stage1:
            survivors_stage1 += 1
        if sug == "DEAD" or (not stage1 and is_spot_testable(g)):
            ug["state"] = "DEAD"
            if ug["gene_id"] not in dead_ids:
                dead_bank.append(ug)
                dead_ids.add(ug["gene_id"])
            gene_store.append_evolution(
                {
                    "event": "KILL",
                    "gene_id": ug["gene_id"],
                    "from_state": g.get("state"),
                    "to_state": "DEAD",
                    "reason": ug.get("failure_reason", "")[:200],
                }
            )
            # do not keep in active population
            continue
        elif sug == "DORMANT":
            ug["state"] = "DORMANT"
            gene_store.append_evolution(
                {
                    "event": "DORMANCY",
                    "gene_id": ug["gene_id"],
                    "from_state": g.get("state"),
                    "to_state": "DORMANT",
                    "reason": ug.get("failure_reason", "")[:200],
                }
            )
            updated.append(ug)
        elif sug == "PROMISING":
            ug["state"] = "PROMISING"
            gene_store.append_evolution(
                {
                    "event": "PROMOTION",
                    "gene_id": ug["gene_id"],
                    "from_state": "TESTING",
                    "to_state": "PROMISING",
                    "reason": "stage1+oos+cost5+anti_ok",
                }
            )
            updated.append(ug)
        elif sug == "WEAKENING":
            ug["state"] = "WEAKENING"
            gene_store.append_evolution(
                {
                    "event": "DEMOTION",
                    "gene_id": ug["gene_id"],
                    "from_state": "TESTING",
                    "to_state": "WEAKENING",
                    "reason": ug.get("failure_reason", "")[:200],
                }
            )
            updated.append(ug)
        else:
            ug["state"] = "TESTING"
            updated.append(ug)

    # If we only tested a subset, merge into full population
    full_pop = gene_store.load_population()
    tested_ids = set(by_id.keys())
    merged = []
    for g in full_pop:
        if g["gene_id"] in tested_ids:
            continue  # will use updated versions
        merged.append(g)
    # Also handle genes that were only in `pop` arg but not on disk yet
    full_ids = {g["gene_id"] for g in merged}
    for g in updated:
        if g["gene_id"] not in full_ids:
            merged.append(g)
            full_ids.add(g["gene_id"])
        else:
            # replace
            merged = [g if x["gene_id"] != g["gene_id"] else g for x in merged]
    # Fix replace properly
    by_updated = {g["gene_id"]: g for g in updated}
    final = []
    seen = set()
    for g in full_pop:
        gid = g["gene_id"]
        if gid in by_updated:
            final.append(by_updated[gid])
        elif gid not in tested_ids:
            final.append(g)
        # if tested and DEAD, skip (already in dead bank)
        seen.add(gid)
    for g in updated:
        if g["gene_id"] not in seen:
            final.append(g)
            seen.add(g["gene_id"])

    gene_store.save_population(final)
    gene_store.save_dead(dead_bank)

    summary = {
        "tested": len(results),
        "stage1_pass": survivors_stage1,
        "population_remaining": len(final),
        "dead_bank": len(dead_bank),
        "state_counts": _count_states(final),
        "ts": _now(),
    }
    (PROGRESS / "phase4_5_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return {"summary": summary, "results": results, "population": updated}


def _count_states(pop: list[dict]) -> dict[str, int]:
    from collections import Counter

    return dict(Counter(g.get("state") for g in pop))


if __name__ == "__main__":
    # quick smoke on existing 3
    df = pd.read_parquet(DATA / "market_data.parquet")
    _pool_init(build_shared_payload(df))
    pop = gene_store.load_population()
    for g in pop:
        if is_spot_testable(g):
            el = dict(g["entry_logic"])
            el.setdefault("horizon", 5)
            print(g["gene_id"], evaluate_entry_logic(el, g["gene_id"])["IS1"])
