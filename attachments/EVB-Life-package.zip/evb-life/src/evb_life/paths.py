"""Root paths for durable external memory."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data"
STATE = ROOT / "state"
GENES = ROOT / "genes"
EVENTS = ROOT / "events"
REGIMES = ROOT / "regimes"
OPTIONS = ROOT / "options"
EVOLUTION = ROOT / "evolution"
EXPERIMENTS = ROOT / "experiments"
REPORTS = ROOT / "reports"
DOCS = ROOT / "docs"
SHADOW = ROOT / "shadow"
RISK = ROOT / "risk"

RVTE_DATA = Path("/workspace/qqq-vxx-desk/backtest/rvte/data")
EVB_HIST_SPOTS = Path("/workspace/evb-hist/spots_qqq_vxx_vix.csv")
