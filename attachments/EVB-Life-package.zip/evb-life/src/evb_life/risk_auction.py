"""Phase 9 — Risk Auction stub (Estimated allocations)."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import gene_store, state_engine
from .paths import ROOT, DATA, EVOLUTION, STATE
import pandas as pd

PROGRESS = EVOLUTION / "progress"
RISK_DIR = ROOT / "risk"


def run_risk_auction() -> dict[str, Any]:
    RISK_DIR.mkdir(parents=True, exist_ok=True)
    df = pd.read_parquet(DATA / "market_data.parquet")
    state = state_engine.compute_market_state(df)
    pop = gene_store.load_population()
    live = [g for g in pop if g.get("state") in ("ACTIVE", "PROMISING")]
    # Estimated state probabilities (crude)
    hints = state.get("regime_hints") or []
    probs = {
        "persistent_drawdown": 0.35 if "persistent_drawdown" in hints else 0.10,
        "vol_expansion": 0.30 if "vol_expansion" in hints else 0.15,
        "baseline": 0.55,
    }
    s = sum(probs.values())
    probs = {k: v / s for k, v in probs.items()}

    # Softmax-ish by fitness among candidates
    scored = []
    for g in live:
        fit = float(g.get("fitness") or 0)
        if fit < 0:
            fit = 0
        scored.append((g, fit))
    total = sum(f for _, f in scored) or 1.0
    allocations = []
    budget_units = 100.0
    for g, fit in sorted(scored, key=lambda x: -x[1]):
        w = (fit / total) if scored else 0
        # Cap single name
        w = min(w, 0.25)
        allocations.append(
            {
                "gene_id": g["gene_id"],
                "state": g["state"],
                "fitness": g.get("fitness"),
                "risk_budget_pct": round(w * 100, 3),
                "evidence_tag": g.get("evidence_tag"),
                "note": "Estimated — research allocation only, not live capital",
            }
        )
    # Renormalize if capped
    s2 = sum(a["risk_budget_pct"] for a in allocations) or 1.0
    for a in allocations:
        a["risk_budget_pct"] = round(a["risk_budget_pct"] / s2 * 100, 3)

    out = {
        "updated_utc": datetime.now(timezone.utc).isoformat(),
        "evidence_tag": "Estimated",
        "regime_state_probs": probs,
        "total_budget_units": budget_units,
        "live_capital": 0,
        "phase": "research_stub",
        "allocations": allocations,
        "unallocated_pct": round(100 - sum(a["risk_budget_pct"] for a in allocations), 3)
        if allocations
        else 100.0,
        "risk_transfer": "N/A spot phase",
    }
    (RISK_DIR / "risk_budget.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    (STATE / "risk_budget.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    PROGRESS.mkdir(parents=True, exist_ok=True)
    (PROGRESS / "phase9_risk_auction.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    return out


if __name__ == "__main__":
    print(json.dumps(run_risk_auction(), indent=2)[:1500])
