"""Phase 1–2 cycle CLI: data → state → event clock → cycle report."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from . import data_hub, event_clock, event_combos, gene_store, state_engine
from .paths import REPORTS, ROOT


def _research_questions(state: dict, mem: dict, pop: list) -> list[str]:
    qs = []
    persist = (state.get("persistence") or {}).get("persist_below_MA20")
    vol = (state.get("relative_vol") or {}).get("label")
    regime = state.get("regime_hints") or []
    qs.append(
        f"Given current regime_hints={regime} and persist_below_MA20={persist}, "
        "does conditional hazard for winning_state_phase_a rise with age, or is it flat/falling "
        "(anti-gambler check)?"
    )
    qs.append(
        "For pulse events (qqq_m3pct_day, vix_p20pct_day), is P(event|vol_expansion, age) "
        "materially different from unconditional P(event|age)?"
    )
    qs.append(
        "Should CE_PHASEA_SOLE_A remain INCUBATING until secondary OOS n improves, "
        "or move only to TESTING with walk-forward gates (never ACTIVE yet)?"
    )
    qs.append(
        "Which relative features (QQQ/SPY, ShortVolRel, TermSlope) currently diverge from "
        f"vol_state={vol}, and do historical analogs of that divergence precede turns?"
    )
    qs.append(
        "OPRA-blocked: until option chains exist, what spot-only adversarial tests "
        "(leave-one-crisis, cost×5, anti-signal) should Phase 4 run on the incubating population "
        f"(n_genes={len(pop)}) before any promotion?"
    )
    # bonus honest questions
    overdue = [
        e
        for e in mem.get("events", [])
        if isinstance(e.get("age_over_median_IS"), float) and e["age_over_median_IS"] > 2.0
    ]
    overdue.sort(key=lambda e: e.get("age_over_median_IS") or 0, reverse=True)
    if overdue:
        top = overdue[0]
        qs.append(
            f"Event `{top['event_id']}` is age/median≈{top['age_over_median_IS']:.2f} — "
            "what is the *conditional* hazard in the current regime, and does it justify "
            "any research attention without treating overdue as a buy?"
        )
    else:
        qs.append(
            "No event is >2× median age on IS clock — which near-median clocks still deserve "
            "state-conditional monitoring this week?"
        )
    return qs[:8]


def run_cycle() -> dict:
    REPORTS.mkdir(parents=True, exist_ok=True)
    df = data_hub.load_or_build_market_data()
    verify = data_hub.verify_market_data(df)
    state = state_engine.write_market_state(df)
    mem = event_clock.write_event_memory(df, state)
    combos = event_combos.write_event_combos(df, event_memory=mem)
    pop = gene_store.seed_phase_a_and_v01()

    asof = state.get("asof") or "unknown"
    ymd = asof.replace("-", "")
    report_path = REPORTS / f"cycle_{ymd}.md"

    # top event rows by days_since among Estimated/low_sample
    rows = [e for e in mem.get("events", []) if e.get("days_since_occurrence") is not None]
    rows_sorted = sorted(rows, key=lambda e: e["days_since_occurrence"], reverse=True)
    questions = _research_questions(state, mem, pop)

    lines = [
        f"# EVB LIFEFORM Cycle Report — {asof}",
        "",
        f"Generated UTC: {datetime.now(timezone.utc).isoformat()}",
        f"Root: `{ROOT}`",
        "",
        "## 傳統中文摘要",
        "",
        "- 本輪只跑 Phase 1–2：資料核對、市場狀態、事件時鐘；**沒有**把任何基因升到 ACTIVE。",
        "- 事件「很久沒來」≠ 買入訊號；看條件 hazard，不要賭徒謬誤。",
        "- 事件配搭（共現 lift）已刷新；配搭提升≠交易訊號。",
        "- 期權結構僅目錄／Hypothetical；OPRA 未接，禁止把 BS P/L 當 Verified。",
        "- Fitness 不是 CAGR；Phase A sole A 以 Observed 現貨分數孵化中。",
        "",
        "## MARKET STATE",
        "",
        "```json",
        json.dumps(
            {
                "asof": state.get("asof"),
                "prices": state.get("prices"),
                "trend": state.get("trend"),
                "relative_vol": state.get("relative_vol"),
                "persistence": state.get("persistence"),
                "regime_hints": state.get("regime_hints"),
            },
            indent=2,
        ),
        "```",
        "",
        f"Data verify: `{verify}`",
        "",
        "## EVENT CLOCK (top by days_since)",
        "",
        "| event_id | days_since | median_IS | age/median | n_IS | late−early | conf |",
        "|---|---:|---:|---:|---:|---:|---|",
    ]
    for e in rows_sorted[:20]:
        haz = (e.get("hazard_estimate_unconditional") or {}).get("late_minus_early_hazard")
        haz_s = f"{haz:.4f}" if isinstance(haz, float) else "—"
        med = e.get("median_interval_IS")
        med_s = f"{med:.1f}" if isinstance(med, float) else "—"
        aom = e.get("age_over_median_IS")
        aom_s = f"{aom:.2f}" if isinstance(aom, float) else "—"
        lines.append(
            f"| `{e['event_id']}` | {e['days_since_occurrence']} | {med_s} | {aom_s} | "
            f"{e.get('n_occurrences_IS')} | {haz_s} | {e.get('confidence')} |"
        )

    lines.extend(
        [
            "",
            f"Full clock: `events/event_memory.json` / `reports/event_clock_latest.md`",
            "",
            "## GENE POPULATION (seed)",
            "",
        ]
    )
    for g in pop:
        lines.append(
            f"- `{g['gene_id']}` state=**{g['state']}** tag={g.get('evidence_tag')} "
            f"source={g.get('source')}"
        )
    lines.extend(
        [
            "",
            "**No gene promoted to ACTIVE.**",
            "",
            "## NEXT RESEARCH QUESTIONS",
            "",
        ]
    )
    for i, q in enumerate(questions, 1):
        lines.append(f"{i}. {q}")
    lines.extend(
        [
            "",
            "## Artifacts",
            "",
            "- `data/market_data.parquet` + `data/DATA_MANIFEST.json`",
            "- `state/market_state.json`",
            "- `events/event_memory.json`",
            "- `events/event_combos.json`",
            "- `genes/gene_population.json`",
            "- `docs/MASTER_PROMPT_v2.md`, `docs/PHASES.md`, `docs/HONESTY.md`",
            "- Blueprint: `docs/EVB_BRAIN_BLUEPRINT_V0_2.md`",
            "",
        ]
    )
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    # also write a stable latest pointer
    (REPORTS / "cycle_latest.md").write_text(report_path.read_text(encoding="utf-8"), encoding="utf-8")

    return {
        "report": str(report_path),
        "asof": asof,
        "verify": verify,
        "n_events": len(mem.get("events", [])),
        "n_event_combos_flagged": len(combos.get("top_flagged") or []),
        "n_genes": len(pop),
        "gene_ids": [g["gene_id"] for g in pop],
        "state_summary": {
            "prices": state.get("prices"),
            "trend": state.get("trend"),
            "relative_vol": state.get("relative_vol"),
            "persistence": state.get("persistence"),
            "regime_hints": state.get("regime_hints"),
        },
        "top_events": [
            {
                "event_id": e["event_id"],
                "days_since": e["days_since_occurrence"],
                "median_IS": e.get("median_interval_IS"),
                "age_over_median": e.get("age_over_median_IS"),
                "n_IS": e.get("n_occurrences_IS"),
                "late_minus_early": (e.get("hazard_estimate_unconditional") or {}).get(
                    "late_minus_early_hazard"
                ),
            }
            for e in rows_sorted[:10]
        ],
    }


def main() -> None:
    result = run_cycle()
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
