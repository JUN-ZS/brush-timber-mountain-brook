"""Gene population store — load/save, promote/demote/kill/dormant + evolution_log."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .paths import EVOLUTION, GENES

LIFECYCLE = [
    "BORN",
    "INCUBATING",
    "TESTING",
    "PROMISING",
    "ACTIVE",
    "WEAKENING",
    "DORMANT",
    "DEAD",
    "ARCHIVED",
]

POP_PATH = GENES / "gene_population.json"
DEAD_PATH = GENES / "dead_gene_bank.json"
CAND_PATH = GENES / "candidate_pool.json"
LOG_PATH = EVOLUTION / "evolution_log.jsonl"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def empty_gene(**overrides: Any) -> dict[str, Any]:
    base = {
        "gene_id": "",
        "parent_ids": [],
        "birth_time": _now(),
        "state": "BORN",
        "hypothesis": {},
        "features": [],
        "relative_features": [],
        "persistence_features": [],
        "regime_features": [],
        "entry_logic": {},
        "exit_logic": {},
        "option_structure": {},
        "hedge_structure": {},
        "risk_budget": {},
        "sample_count": 0,
        "is": {},
        "oos": {},
        "walk_forward": {},
        "max_drawdown": 0.0,
        "es95": 0.0,
        "es99": 0.0,
        "cost_sensitivity": {},
        "regime_stability": {},
        "fitness": 0.0,
        "last_test": None,
        "next_review": None,
        "failure_reason": "",
        "resurrection_condition": "",
        "evidence_tag": "Observed",
        "source": "",
        "notes": "",
    }
    base.update(overrides)
    return base


def load_population() -> list[dict]:
    if not POP_PATH.exists():
        return []
    return json.loads(POP_PATH.read_text(encoding="utf-8"))


def save_population(pop: list[dict]) -> None:
    GENES.mkdir(parents=True, exist_ok=True)
    POP_PATH.write_text(json.dumps(pop, indent=2), encoding="utf-8")


def load_dead() -> list[dict]:
    if not DEAD_PATH.exists():
        return []
    return json.loads(DEAD_PATH.read_text(encoding="utf-8"))


def save_dead(dead: list[dict]) -> None:
    DEAD_PATH.write_text(json.dumps(dead, indent=2), encoding="utf-8")


def append_evolution(event: dict[str, Any]) -> None:
    EVOLUTION.mkdir(parents=True, exist_ok=True)
    row = {"ts": _now(), **event}
    with LOG_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def _find(pop: list[dict], gene_id: str) -> dict | None:
    for g in pop:
        if g.get("gene_id") == gene_id:
            return g
    return None


def set_state(gene_id: str, to_state: str, reason: str = "", event: str | None = None) -> dict:
    if to_state not in LIFECYCLE:
        raise ValueError(f"invalid state {to_state}")
    pop = load_population()
    g = _find(pop, gene_id)
    if g is None:
        raise KeyError(gene_id)
    from_state = g.get("state")
    g["state"] = to_state
    if to_state == "DEAD":
        g["failure_reason"] = reason or g.get("failure_reason") or ""
        dead = load_dead()
        dead.append(g)
        save_dead(dead)
        pop = [x for x in pop if x.get("gene_id") != gene_id]
        evt = event or "EXTINCTION"
    elif to_state == "DORMANT":
        evt = event or "DORMANCY"
    elif to_state in ("PROMISING", "ACTIVE") and from_state in (
        "INCUBATING",
        "TESTING",
        "PROMISING",
        "BORN",
    ):
        evt = event or "PROMOTION"
    elif to_state in ("WEAKENING", "INCUBATING", "TESTING") and from_state in (
        "ACTIVE",
        "PROMISING",
    ):
        evt = event or "DEMOTION"
    else:
        evt = event or "REGIME_ADAPTATION"
    save_population(pop)
    append_evolution(
        {
            "event": evt,
            "gene_id": gene_id,
            "from_state": from_state,
            "to_state": to_state,
            "reason": reason,
        }
    )
    return g


def promote(gene_id: str, to_state: str = "PROMISING", reason: str = "") -> dict:
    return set_state(gene_id, to_state, reason=reason, event="PROMOTION")


def demote(gene_id: str, to_state: str = "WEAKENING", reason: str = "") -> dict:
    return set_state(gene_id, to_state, reason=reason, event="DEMOTION")


def kill(gene_id: str, reason: str = "") -> dict:
    return set_state(gene_id, "DEAD", reason=reason, event="KILL")


def dormant(gene_id: str, reason: str = "") -> dict:
    return set_state(gene_id, "DORMANT", reason=reason, event="DORMANCY")


def resurrect(gene_id: str, reason: str = "") -> dict:
    """Move from dead bank back to population as INCUBATING (must retest)."""
    dead = load_dead()
    g = None
    keep = []
    for x in dead:
        if x.get("gene_id") == gene_id and g is None:
            g = x
        else:
            keep.append(x)
    if g is None:
        # try population dormant
        pop = load_population()
        g = _find(pop, gene_id)
        if g is None:
            raise KeyError(gene_id)
        from_state = g.get("state")
        g["state"] = "INCUBATING"
        save_population(pop)
    else:
        from_state = g.get("state", "DEAD")
        g["state"] = "INCUBATING"
        g["failure_reason"] = ""
        save_dead(keep)
        pop = load_population()
        pop.append(g)
        save_population(pop)
    append_evolution(
        {
            "event": "RESURRECTION",
            "gene_id": gene_id,
            "from_state": from_state,
            "to_state": "INCUBATING",
            "reason": reason or "regime_match_candidate_retest_required",
            "result": "must_retest_oos_cost_regime_before_candidate",
        }
    )
    return g


def birth(gene: dict[str, Any]) -> dict:
    pop = load_population()
    if not gene.get("gene_id"):
        raise ValueError("gene_id required")
    if _find(pop, gene["gene_id"]):
        raise ValueError(f"duplicate {gene['gene_id']}")
    if gene.get("state") not in LIFECYCLE:
        gene["state"] = "BORN"
    pop.append(gene)
    save_population(pop)
    append_evolution(
        {
            "event": "BIRTH",
            "gene_id": gene["gene_id"],
            "parent": (gene.get("parent_ids") or [None])[0] if gene.get("parent_ids") else None,
            "child": gene["gene_id"],
            "from_state": None,
            "to_state": gene["state"],
            "reason": gene.get("source") or "",
        }
    )
    return gene


def seed_phase_a_and_v01() -> list[dict]:
    """Seed 1–3 genes: Phase A sole A + interesting V0.1 spot genomes as INCUBATING."""
    GENES.mkdir(parents=True, exist_ok=True)
    pop = load_population()
    existing = {g.get("gene_id") for g in pop}
    seeds = []

    g_a = empty_gene(
        gene_id="CE_PHASEA_SOLE_A",
        parent_ids=[],
        state="INCUBATING",
        hypothesis={
            "statement": (
                "Persistent QQQ displacement below MA20 (>=1%) with DD20<=-4% and "
                "persist_age>=15, plus mom2_improve transition, has positive forward "
                "spot edge on horizon 5 (Phase A search)."
            ),
            "instrument": "QQQ_spot",
            "not_active": True,
        },
        features=["QQQ_over_MA20", "DD20", "persist_below_MA20", "mom2_improve"],
        relative_features=["VolPremium_z"],
        persistence_features=["persist_below_MA20"],
        regime_features=["persistent_drawdown"],
        entry_logic={
            "ma_below": 0.01,
            "dd20": -0.04,
            "persist_age": 15,
            "vpz": 0.0,
            "use_back": 0,
            "trans_1d_up": 0,
            "trans_mom_improve": 1,
            "trans_vpz_fall": 0,
            "trans_short_fall": 0,
            "genome_id": "ma0.01_dd0.04_age15_vpz0.0_bk0_sx0_t10_tm1_tv0_ts0_h5_anti0",
        },
        exit_logic={"horizon_trading_days": 5, "timeout_is_outcome": True},
        option_structure={"status": "none_spot_only"},
        hedge_structure={},
        risk_budget={"phase": "research_only", "live_capital": 0},
        sample_count=72 + 22,
        walk_forward={
            "secondary_IS_mean": 0.0063594323077823,
            "secondary_OOS_n": 8,
            "secondary_OOS_mean": 0.0291974259905637,
        },
        max_drawdown=-0.3888124825274384,
        es95=-0.1384048831280296,
        es99=0.0,
        cost_sensitivity={"note": "5bps stress in Phase A kill gates"},
        regime_stability={"leave_one_crisis": "passed_phase_a_filters", "anti_signal": "checked"},
        fitness=0.0001206965767101,
        last_test="2026-09-04T02:34:00+00:00",
        next_review="phase3_mass_retest",
        failure_reason="",
        resurrection_condition="if persistent_drawdown regime returns with age>=15 and mom improve",
        evidence_tag="Observed",
        source="rvte_phase_a_survivor_A",
        notes="Seeded INCUBATING only — DO NOT promote to ACTIVE without Phase 4–5 gates.",
    )
    g_a["is"] = {
        "n": 72,
        "mean_fwd5": 0.0042419445964116,
        "wr": 0.6388888888888888,
        "es5": -0.1384048831280296,
    }
    g_a["oos"] = {
        "n": 22,
        "mean_fwd5": 0.0215941170660068,
        "wr": 0.7272727272727273,
        "t_like": 3.563134938967525,
    }
    seeds.append(g_a)

    g_v01 = empty_gene(
        gene_id="CE_V01_SPOT_FAMILY_021",
        parent_ids=[],
        state="INCUBATING",
        hypothesis={
            "statement": (
                "V0.1 evolutionary family: ~2.1% below MA20, persistence 2–3 days, "
                "reversal = positive QQQ day + falling VIX / relative confirmation; "
                "horizon ~10d. Spot framing only for seed."
            ),
            "instrument": "QQQ_spot",
            "v01_option_structures": "Hypothetical / OPRA-blocked — not seeded as verified",
        },
        features=["QQQ_over_MA20", "persist_below_MA20", "QQQ_ret1", "VIX"],
        relative_features=["RV5_over_RV20"],
        persistence_features=["persist_below_MA20"],
        regime_features=["vol_compression_or_mild_displacement"],
        entry_logic={
            "ma_below": 0.021,
            "persist_age_min": 2,
            "persist_age_max_hint": 3,
            "reversal": "QQQ_1d_up and VIX falling",
            "horizon": 10,
        },
        exit_logic={"horizon_trading_days": 10, "timeout_is_outcome": True},
        option_structure={
            "status": "catalog_only",
            "evidence_tag": "Hypothetical",
            "note": "V0.1 competed BS structures — NOT verified OPRA P/L",
        },
        hedge_structure={"asymmetric_10d_put": "Hypothetical"},
        risk_budget={"phase": "research_only", "live_capital": 0},
        sample_count=0,
        walk_forward={},
        max_drawdown=0.0,
        es95=0.0,
        es99=0.0,
        cost_sensitivity={},
        regime_stability={},
        fitness=0.0,
        last_test=None,
        next_review="phase3_define_spot_metrics",
        failure_reason="",
        resurrection_condition="mild displacement + short persistence cluster reappears",
        evidence_tag="Observed",
        source="evb_evolutionary_report_v0_1_spot_family",
        notes="Option legs from V0.1 remain Hypothetical; spot family only for incubation.",
    )
    seeds.append(g_v01)

    g_opt = empty_gene(
        gene_id="CE_PHASEA_A_OPT_EXPR_HYP",
        parent_ids=["CE_PHASEA_SOLE_A"],
        state="INCUBATING",
        hypothesis={
            "statement": (
                "Same Phase A state expressed via asymmetric call vertical + small put hedge. "
                "Structure idea only — no OPRA backtest."
            ),
            "instrument": "QQQ_options",
        },
        features=["QQQ_over_MA20", "DD20", "persist_below_MA20", "mom2_improve"],
        relative_features=[],
        persistence_features=["persist_below_MA20"],
        regime_features=["persistent_drawdown"],
        entry_logic={"inherits": "CE_PHASEA_SOLE_A"},
        exit_logic={"horizon_trading_days": 5},
        option_structure={
            "structure": "CV_50_10_plus_10D_put",
            "evidence_tag": "Hypothetical",
            "opra": "blocked",
        },
        hedge_structure={"put_delta": "10D", "ratio": "small"},
        risk_budget={"phase": "research_only", "live_capital": 0},
        sample_count=0,
        walk_forward={},
        max_drawdown=0.0,
        es95=0.0,
        es99=0.0,
        cost_sensitivity={},
        regime_stability={},
        fitness=0.0,
        last_test=None,
        next_review="await_OPRA",
        failure_reason="",
        resurrection_condition="OPRA EOD available AND spot parent still PROMISING",
        evidence_tag="Hypothetical",
        source="phase_a_state_option_expression",
        notes="Hypothetical — OPRA-blocked. Must not be treated as verified P/L.",
    )
    seeds.append(g_opt)

    for g in seeds:
        if g["gene_id"] in existing:
            continue
        birth(g)
    return load_population()

