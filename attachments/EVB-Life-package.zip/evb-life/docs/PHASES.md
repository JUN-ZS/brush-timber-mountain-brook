# EVB LIFEFORM — Phases (Master Prompt v2.0)

Each phase must be independently runnable. Do not fake a full UI ahead of working engines.

## PHASE 1 — External Data + State Memory
- Market Data Hub: load / verify / version panel (QQQ, VIX term, VXX overlay)
- State Engine: relative vol, trend, persistence ages → `state/market_state.json`
- External durable memory under `/workspace/evb-life/` (not chat memory)

## PHASE 2 — Event Clock + Persistence
- Define ~20–40 event definitions
- Compute last_occurrence, days_since, median/mean interval on IS
- Age + crude hazard by age bucket, conditional on regime when possible
- Write `events/event_memory.json` + `reports/event_clock_latest.md`
- **Hard rule:** no gambler fallacy (“overdue = buy”)

## PHASE 3 — Gene Population
- Birth / incubate / promote / demote population management
- Seed from Phase A survivors + V0.1 interesting genomes as INCUBATING
- Option-linked genes tagged **Hypothetical**

## PHASE 4 — Mass Backtest
- Compete thousands of genomes on spot features first
- Record sample counts; never hide thin-n results

## PHASE 5 — OOS / Walk Forward
- Primary + secondary splits; walk-forward windows
- Overfit-suspect labeling when IS ≫ OOS

## PHASE 6 — Evolution
- Mutation, crossover, diversity preservation
- `evolution/evolution_log.jsonl` for BIRTH/MUTATION/KILL/DORMANT/RESURRECT

## PHASE 7 — Resurrection
- Periodic review of DEAD / DORMANT when regime ≈ historical working regime
- Must retest → OOS → cost → regime before candidate

## PHASE 8 — Option Structure Laboratory
- Structure catalog only until OPRA EOD available
- No BS/proxy option P/L as Verified

## PHASE 9 — Risk Auction
- Central capital / risk budget allocation across candidates

## PHASE 10 — Shadow Trading
- Paper / shadow marks without live capital

## PHASE 11 — Live Candidate Engine
- Final gate to live candidates; multi-dimensional fitness (never fitness=CAGR alone)

## Current runnable
`python3 -m src.evb_life.cycle_phase1_2` — Phase 1–2
`python3 -m src.evb_life.cycle_phase3_6` — Phase 3–6
`python3 -m src.evb_life.cycle_full` — Phase 1–11 end-to-end → `reports/LIFEFORM_FULL_CYCLE.md`.
