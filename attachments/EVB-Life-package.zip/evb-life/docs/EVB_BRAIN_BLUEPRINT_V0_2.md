# EVB Evolutionary Trading Brain — Blueprint V0.2

Status: **Research OS**, not live trader.  
Tags: Observed (spot/vol) · Hypothetical (BS option) · Blocked (OPRA unpaid)

## What we already have (do not rewrite history)

| Layer | Artifact | Verdict |
|---|---|---|
| Spot/vol survivors 1999–2026 | `../survivors_ABCD.md` | A=1 thin; champion **hazard flat** |
| V0.1 evolutionary BS pool | `evolutionary_candidate_pool_v0_1.csv` (~21k rows) | Median `oos_n≈8`; **not Production** |
| Put-hedge geometry claim | V0.1 report | **Hypothetical**: EV≈flat, left-tail better in BS model |
| 2018–2026 spots | legacy CSV | Observed timing only |

## One-sentence product

Not “best σ”. A **population of genomes** that compete on `EV / tail / stability / sample / cost / regime diversity`, with **STATE frozen before OPTION**, and **IS / OOS / LIVE** isolated.

## Five organs (build order)

1. **MEMORY** — analog bank of state vectors + outcomes (2008/2018/2020/2022/2024…)
2. **STATE** — relative weights: QQQ/MA, DD, RV, VIX/RV, term slopes, residuals `| State`
3. **EVENT CLOCK** — age, expected gap, `P(event|state,age)` hazard (may be non-monotone)
4. **REVERSAL / ESCAPE** — Armed → Trigger; Escape cancels Rotation
5. **OPTION AUCTION** — topologies compete only after Observed transition gate; until OPRA = Hypothetical paper marks

Then: RISK ALLOCATION → (later) EXECUTION → FITNESS UPDATE → survive/die/mutate/crossover.

## Genome DNA (minimum fields)

`event · persistence · state · transition · option_topology · strike · maturity · ratio · hedge · exit`

Relative-ratio genes (examples): `QQQ/ΔVIX`, `VIX/RV20`, `VIX9D/VIX`, `VXX/|QQQ|` (2018+ only).

## Fitness (CAGR is not king)

```
FIT = EV + OOS_stab + regime_div + tail_protect + sample + cost_robust + param_robust
    - MaxDD - ES - complexity - crisis_dependence - concentration
```

Kill if: look-ahead · n thin · IS EV≤0 · OOS EV≤0 · anti-signal also wins · single-crisis · cost×2 dies · STATE retuned after seeing OPTION.

## Isolation zones (hard rule)

| Zone | May train? | May rank for deploy? |
|---|---|---|
| **IS** | Yes | No (research only) |
| **OOS** | Audit only — never selection target | Soft gate |
| **LIVE / Shadow** | No rewrite of DNA | Paper → tiny size only after OPRA + shadow |

Daily mutation of live DNA from seeing yesterday’s P/L = **forbidden** (overfit organ).

## Field walk (現場怎麼走)

### Week 0 — Wire organs on long spot/vol (Observed)
- Already: Phase A data + survivor search.
- Next code: Event Clock dashboard on 1999+ series (absence, median/P90, conditional hazard by regime).
- Freeze champion spot A as **B-tier watch** only (n thin).

### Week 1 — Promote geometry gene, not “god strategy”
- Keep `50Δ/10Δ CV + 10Δ put` as **Hedge DNA candidate** (Hypothetical).
- Re-test on **Observed** transition entries from Phase A survivors only (STATE→then OPTION), no joint retune.
- Still label Hypothetical until OPRA.

### Week 2 — Candidate Pool policy automation
Promote to pool only if: IS n≥30, OOS n≥15, both EV>0, anti-signal fail, leave-one-crisis, cost stress, param jitter.  
Else: B / C / D tiers (same as Phase A).

### Week 3+ — Data war (the real compute win)
- Free: VIX history, term, QQQ 1999+ (done / extend VVIX/futures if free).
- **Paid gate**: Cboe OPRA EOD 2012+ → only then “real option P/L”.
- Without OPRA: Brain stops at **spot Transition AI + Hypothetical auction labels**.

## Hourly LIVE output (shadow UI)

Not BUY/SELL. Emit:

1. Market state snapshot  
2. Event clocks (absence vs median/P90; hazard; OVERDUE vs REGIME-CHANGED)  
3. P(reversal)/P(continuation)/P(escape) — Estimated from IS analogs  
4. Option auction table — Hypothetical until OPRA  
5. Action: `WAIT | ARMED | ENTER_SHADOW | KILL`

## What to generate next (ordered deliverables)

1. `evb_event_clock.py` + daily `event_clock_live.md` (Observed)  
2. `evb_genome_schema.json` — frozen DNA fields + fitness weights  
3. `evb_pool_gate.py` — ingest V0.1 CSV + Phase A survivors → A/B/C/D with hard n gates  
4. `evb_analog_memory.py` — nearest historical state vectors  
5. Shadow cockpit page on desk (read-only)  
6. **Stop** for OPRA purchase decision before any “real option edge” claim

## Explicit non-goals

- 100k BS genomes as “proof”
- Promoting OOS median EV ~20%+ structure returns as CAGR
- Killing hazard-flat states without checking non-monotone hazard
- Merging STATE search with OPTION search in one fitness pass

## Lineage

- Phase A: `/workspace/qqq-vxx-desk/backtest/rvte/`
- V0.1 attach: `brain/EVB_EVOLUTIONARY_REPORT_V0_1.md`, `brain/evolutionary_candidate_pool_v0_1.csv`
