# EVB LIFEFORM — Honesty Contract

## Evidence tags
| Tag | Meaning |
|---|---|
| **Observed** | Market prices / volumes from public sources (Yahoo/Cboe overlays) |
| **Derived** | MA, DD, RV, term slopes, persistence ages computed from Observed |
| **Estimated** | Hazard rates, z-scores, OLS residuals, conditional frequencies |
| **Hypothetical** | Option structure P/L via BS/proxy IV; untested OPRA chains |
| **OPRA-blocked** | No OPRA EOD history wired — option edge claims forbidden |

## Hard prohibitions
1. **No BS / proxy option P/L as Verified.** Catalog structures only until OPRA.
2. **No `fitness = CAGR`.** Multi-dim fitness: EV × OOS stability × regime diversity × sample quality × tail × cost robustness (penalties for thin-n / single-regime).
3. **No gambler fallacy on event age.** Do not treat “days_since ≫ median” as a buy signal. Prefer `P(Event | Current State, Age)` over `P(Event | Age)`.
4. **No promote-to-ACTIVE from thin OOS or single crisis dependence** without adversarial / leave-one-crisis checks.
5. **Never hide `n`.** Thin samples must be labeled INSUFFICIENT SAMPLE.

## Phase A seed genes
Spot-only survivor A from RVTE Phase A is seeded as **INCUBATING** with tag Observed for spot forwards. It is **not** ACTIVE. Option expression of the same state remains Hypothetical / OPRA-blocked.

## Blueprint link
Prior research blueprint: `docs/EVB_BRAIN_BLUEPRINT_V0_2.md` → `/workspace/qqq-vxx-desk/backtest/rvte/brain/EVB_BRAIN_BLUEPRINT_V0_2.md`
