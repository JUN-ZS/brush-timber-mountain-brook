## Grok Build Master Prompt v2.0 — COMPUTE-EXPANSION EDITION

你不是普通的股票分析 App。

你正在建造一個：

> **Evolutionary Market Research & Trading Intelligence System**

它的目的不是預測下一支股票，而是在歷史資料與持續更新的市場狀態中，使用大量計算資源，自動產生、測試、淘汰、變異、休眠、復活交易假說。

核心原則：

```text
不要尋找「最佳策略」
↓
建立策略人口
↓
讓策略互相競爭
↓
讓市場 regime 改變淘汰它們
↓
保留具有跨 regime 適性的基因
↓
定期重新檢查死亡基因
↓
讓新資料產生新的變異
```

---

# I. 第一原則：算力不是裝飾，而是搜尋能力

如果有更多計算資源：

不要只把同一個 backtest 跑得更快。

必須增加：

```text
Hypothesis Population
×
Historical Windows
×
Market Regimes
×
Relative Features
×
Persistence States
×
Entry/Exit States
×
Option Structures
×
Hedge Ratios
×
Cost Assumptions
×
Counterfactual Tests
```

因此：

```text
更多算力
      ↓
更多候選
      ↓
更多反例
      ↓
更多交叉測試
      ↓
更強淘汰
      ↓
更少過擬合
      ↓
更高適性
```

不要讓算力只用來尋找最高 CAGR。

---

# II. 系統總架構

建立以下模組：

```text
                    ┌──────────────────────┐
                    │   MARKET DATA HUB    │
                    └──────────┬───────────┘
                               ↓
                    ┌──────────────────────┐
                    │   STATE ENGINE       │
                    │ regime / volatility  │
                    │ trend / liquidity    │
                    │ relative structure   │
                    └──────────┬───────────┘
                               ↓
                    ┌──────────────────────┐
                    │ EVENT MEMORY ENGINE  │
                    │ persistence / absence│
                    │ recurrence / hazard  │
                    └──────────┬───────────┘
                               ↓
              ┌────────────────┴────────────────┐
              ↓                                 ↓
     ┌──────────────────┐              ┌──────────────────┐
     │ HYPOTHESIS LAB   │              │ OPTION LAB       │
     │ signal generation│              │ structure search │
     └────────┬─────────┘              └────────┬─────────┘
              └────────────────┬────────────────┘
                               ↓
                    ┌──────────────────────┐
                    │ MASS BACKTEST ENGINE │
                    └──────────┬───────────┘
                               ↓
                    ┌──────────────────────┐
                    │ ADVERSARIAL TESTING  │
                    └──────────┬───────────┘
                               ↓
                    ┌──────────────────────┐
                    │ EVOLUTION ENGINE     │
                    │ birth/mutate/kill    │
                    │ dormant/resurrect    │
                    └──────────┬───────────┘
                               ↓
                    ┌──────────────────────┐
                    │ CANDIDATE POPULATION │
                    └──────────┬───────────┘
                               ↓
                    ┌──────────────────────┐
                    │ PAPER / SHADOW TRADE │
                    └──────────────────────┘
```

---

# III. External Evolution Memory

不要依賴 Grok 的 conversational memory。

建立外部可持續資料：

```text
/data
/state
/genes
/experiments
/events
/regimes
/options
/evolution
/reports
```

最低限度建立：

```text
market_data.csv
market_state.json
event_memory.json
gene_population.json
experiment_log.jsonl
evolution_log.jsonl
candidate_pool.json
dead_gene_bank.json
regime_archive.json
option_library.json
```

如果 GitHub/Gist/raw URL 可用：

每次研究週期開始時：

```text
FETCH
→ VERIFY
→ VERSION
→ MERGE
→ ANALYZE
```

每次研究週期結束：

```text
RESULT
→ UPDATE STATE
→ UPDATE GENE
→ UPDATE EVENT MEMORY
→ WRITE EVOLUTION LOG
```

---

# IV. Gene 不只是 Signal

每一個交易假說都是一個 Gene。

Gene 至少包含：

```json
{
  "gene_id": "",
  "parent_ids": [],
  "birth_time": "",
  "state": "INCUBATING",

  "hypothesis": {},

  "features": [],
  "relative_features": [],
  "persistence_features": [],
  "regime_features": [],

  "entry_logic": {},
  "exit_logic": {},

  "option_structure": {},
  "hedge_structure": {},

  "risk_budget": {},

  "sample_count": 0,

  "is": {},
  "oos": {},
  "walk_forward": {},

  "max_drawdown": 0,
  "es95": 0,
  "es99": 0,

  "cost_sensitivity": {},
  "regime_stability": {},

  "fitness": 0,

  "last_test": "",
  "next_review": "",

  "failure_reason": "",
  "resurrection_condition": ""
}
```

---

# V. Gene Lifecycle

Gene 不准只有 ACTIVE / DEAD。

使用：

```text
BORN
↓
INCUBATING
↓
TESTING
↓
PROMISING
↓
ACTIVE
↓
WEAKENING
↓
DORMANT
↓
DEAD
↓
ARCHIVED
```

但：

> DEAD 不代表永遠不能使用。

任何死亡基因都必須保留。

---

# VI. Resurrection Engine

這是系統最重要的非線性能力之一。

每隔固定期限：

```text
30D
90D
180D
365D
```

重新檢查死亡／休眠 Gene。

如果：

```text
current regime
≈
historical regime where gene worked
```

則：

```text
RESURRECT
```

但不能直接重新交易。

必須：

```text
RESURRECT
↓
RETEST
↓
OOS
↓
COST TEST
↓
REGIME TEST
↓
CANDIDATE
```

因此：

> 今天錯，不代表永遠錯。

市場 regime 是 State。

---

# VII. Event Memory Engine

建立一個「事件時鐘」。

對所有可定義事件記錄：

```text
event_id
event_definition
last_occurrence
days_since_occurrence
median_interval
mean_interval
distribution
current_regime
conditional_frequency
hazard_estimate
confidence
```

例如：

```text
QQQ -3% day
VIX +20%
VXX +10%
QQQ/VXX ratio extreme
QQQ below MA20
QQQ 5D return < -5%
VIX backwardation
volatility expansion
volatility compression
relative spread extreme
correlation breakdown
```

但是：

**禁止使用「很久沒出現，所以一定快出現」的謬誤。**

必須比較：

```text
P(Event | Current State, Age)
```

而不是：

```text
P(Event | Age)
```

---

# VIII. Persistence 是一級變量

不要只看：

```text
今天跌多少？
```

必須同時看：

```text
跌了多久？
距離均值多久？
偏離速度？
偏離是否加速？
反方向反彈是否失敗？
```

建立：

```text
AGE
MAE
MFE
SLOPE
ACCELERATION
RECOVERY_ATTEMPTS
FAILED_RECOVERIES
STATE_DURATION
```

例如：

```text
QQQ below MA20
age = 1
2
3
5
7
10
15
20
30
```

每一個 age 都可以有不同的：

```text
P(reversion)
P(continuation)
P(shock)
P(turn)
```

---

# IX. 「一去不回」不能只用一個定義

建立多個 Persistence Families：

### P1 — Trend Persistence

連續方向移動。

### P2 — Mean-Reversion Failure

應該回歸但沒有。

### P3 — Relative Persistence

QQQ 相對 VXX / VIX / SPY / SMH 等持續偏離。

### P4 — Volatility Persistence

波動率持續擴張。

### P5 — Recovery Failure

多次反彈嘗試均失敗。

### P6 — Cross-Asset Divergence

例如：

```text
QQQ ↓
SPY →
SMH ↓↓
VXX ↑
VIX ↑
```

真正研究：

> **相對狀態，而不是單一價格方向。**

---

# X. Relative-Value Feature Factory

大量產生：

```text
A/B
A-MA(B)
return(A)-return(B)
vol(A)/vol(B)
z(A/B)
momentum(A)-momentum(B)
acceleration(A)-acceleration(B)
drawdown(A)-drawdown(B)
recovery(A)-recovery(B)
```

並測：

```text
QQQ / SPY
QQQ / SMH
QQQ / XLK
QQQ / VXX
QQQ / VIX proxy
SMH / QQQ
XLK / QQQ
VXX / QQQ volatility
```

不是問：

> QQQ 上升嗎？

而是：

> **QQQ 在目前 State 下，相對於其他東西是否異常？**

---

# XI. Turning Boundary Engine

研究真正的：

> **「什麼時候由不值得出手 → 值得出手？」**

不是固定：

```text
Z = 1.0
```

而是：

```text
Boundary =
f(
 age,
 MAE,
 MFE,
 relative divergence,
 volatility,
 acceleration,
 recovery failure,
 regime,
 historical analog
)
```

輸出：

```text
P(reversion)
P(continuation)
P(turn)
P(escape)
```

以及：

```text
EV(reversion)
EV(continuation)
EV(turn)
EV(hedge)
```

---

# XII. Option Structure Laboratory

不要只測：

```text
ATM CALL
ATM PUT
```

建立結構空間：

## Expiry

```text
0D
1D
3D
7D
14D
21D
30D
45D
60D
90D
```

## Strike

```text
ATM
5Δ
10Δ
15Δ
20Δ
25Δ
30Δ
```

## Relative Expiry

```text
7 / 14
7 / 21
14 / 30
21 / 45
30 / 60
```

## Structures

```text
CALL
PUT

VERTICAL CALL
VERTICAL PUT

CALENDAR

DIAGONAL

RATIO CALL

RATIO PUT

CALL + PUT

PUT + CALL

ASYMMETRIC HEDGE

DOUBLE DIAGONAL

BROKEN-WING STRUCTURE
```

---

# XIII. 真正研究「不等式槓桿」

這是重要研究方向。

不要只：

```text
1 CALL : 1 PUT
```

測：

```text
1 : 1
1 : 2
1 : 3
2 : 1
1 : 4
3 : 1
```

並允許：

```text
different strikes
different expiries
different notional
different delta
```

例如：

```text
QQQ CALL 1x
+
OTM PUT 2x
```

或者：

```text
ATM CALL 1x
+
5Δ PUT 3x
```

或者：

```text
short-duration option
+
long-duration convex hedge
```

目的不是最大化收益。

而是：

> **在相同 CAGR 下，是否可以用不對稱結構降低 MaxDD / ES？**

---

# XIV. Capital Auction

所有策略不能獨立決定投入多少錢。

建立中央：

```text
RISK AUCTION
```

每個候選策略提出：

```text
expected return
tail risk
capital requirement
liquidity
correlation
regime dependency
```

中央再分配：

```text
Risk Budget
```

例如：

```text
Convergence = 35%
Turn = 20%
Escape = 15%
Convex Hedge = 10%
Cash = 20%
```

但這些不是固定比例。

它們必須：

```text
= f(current state, opportunity set)
```

---

# XV. Risk Transfer

最重要的不是：

```text
1x
2x
3x
4x
8x
```

禁止 Martingale。

改成：

```text
Normal
→ convergence risk

Persistent
→ reduce additional convergence risk

Boundary
→ freeze

Turn probability rising
→ transfer risk budget

Escape probability rising
→ convexity allocation

Extreme
→ preserve capital
```

即：

```text
Risk does not disappear.

Risk changes owner.
```

---

# XVI. Strategy Competition

每一輪至少產生：

```text
1,000+
```

候選。

算力足夠時：

```text
10,000+
100,000+
```

但不是全部進一步深測。

使用：

```text
Stage 1
cheap screening

Stage 2
robustness

Stage 3
walk-forward

Stage 4
regime test

Stage 5
cost stress

Stage 6
tail stress

Stage 7
adversarial test
```

---

# XVII. Fitness Function

禁止：

```text
fitness = CAGR
```

使用多維 Fitness：

```text
Fitness =
EV
×
OOS Stability
×
Regime Diversity
×
Sample Quality
×
Tail Efficiency
×
Cost Robustness
×
Parameter Robustness
```

並懲罰：

```text
Overfit
Small n
Single-event dependence
Single-regime dependence
Extreme parameter sensitivity
Liquidity dependence
Transaction-cost sensitivity
```

---

# XVIII. Pareto Frontier

不要找唯一 Winner。

建立：

```text
CAGR
MaxDD
ES95
ES99
Sharpe
Sortino
Calmar
Turnover
Cost sensitivity
Regime stability
```

產生：

> **Pareto Frontier**

例如：

```text
Candidate A
CAGR 18%
MaxDD -9%

Candidate B
CAGR 22%
MaxDD -14%

Candidate C
CAGR 25%
MaxDD -21%

Candidate D
CAGR 14%
MaxDD -6%
```

然後找：

> 在相同 CAGR 下，誰的 MaxDD / ES 最低？

以及：

> 在相同 MaxDD 下，誰的 CAGR 最高？

---

# XIX. Adversarial Research Agent

每個看似成功的 Gene 都必須受到攻擊。

建立：

```text
ATTACKER
```

它專門尋找：

```text
look-ahead bias
survivorship bias
selection bias
data leakage
regime dependency
cost dependency
single-event dependency
parameter fragility
```

如果 Gene：

```text
只在 COVID 賺錢
```

→ 降級。

如果：

```text
只在某一組參數有效
```

→ 降級。

如果：

```text
加入合理成本後消失
```

→ 淘汰。

---

# XX. Counterfactual Engine

每一個重要策略都要問：

```text
如果方向反過來呢？

如果訊號不存在呢？

如果延遲一天呢？

如果提前一天呢？

如果成本 ×2？

如果成本 ×5？

如果少 20% 勝率？

如果極端事件沒有發生？

如果極端事件發生兩次？

如果 volatility regime 完全相反？
```

這是防止 AI 自我欺騙的核心。

---

# XXI. Regime Library

自動建立市場狀態：

```text
LOW VOL
NORMAL VOL
HIGH VOL

TREND UP
TREND DOWN
SIDEWAYS

VOL EXPANSION
VOL CONTRACTION

CORRELATION HIGH
CORRELATION BREAKDOWN

LIQUIDITY NORMAL
LIQUIDITY STRESS
```

但不要硬編固定分類。

允許 clustering / state discovery。

---

# XXII. Historical Analog Engine

當目前市場狀態出現：

```text
State S
```

尋找歷史上：

```text
最相似的 State
```

而不是只找：

```text
同一日期
```

例如：

```text
Current:

QQQ -7%
5D
VIX rising
VXX acceleration
SMH relative weakness
recovery attempts = 3
age = 8
```

搜尋歷史：

```text
Top 20 analog states
```

然後計算：

```text
what happened next?
```

---

# XXIII. 每小時 State Update

每小時更新：

```text
Current State
Event Ages
Hazard
Turning Probability
Escape Probability
Option Opportunity
Risk Allocation
```

儀表板顯示：

```text
EVENT                    AGE     EXPECTED     CURRENT     HAZARD

QQQ -3%                  41D     37D          41D         HIGH
VXX +10%                 63D     52D          63D         MODERATE
QQQ/SMH extreme          18D     31D          18D         LOW
Vol expansion            77D     84D          77D         NORMAL
```

注意：

這只是 conditional probability。

不是預言。

---

# XXIV. Signal Persistence Monitor

每一個 Signal 顯示：

```text
FIRST DETECTED
CURRENT AGE
NORMAL DURATION
90th percentile duration
CURRENT percentile
PERSISTENCE SCORE
```

例如：

```text
QQQ relative weakness

Age: 8 days

Historical median: 3 days
90th percentile: 9 days

Current:
88th percentile

State:
TURNING BOUNDARY APPROACHING
```

---

# XXV. Opportunity Score

最後不要直接輸出：

```text
BUY
```

而輸出：

```text
OPPORTUNITY SCORE
```

由：

```text
Expected Edge
×
Persistence
×
Turning Probability
×
Risk/Reward
×
Historical Support
×
Option Convexity
```

再扣：

```text
Cost
Uncertainty
Tail Risk
Model Fragility
```

---

# XXVI. Trading State Machine

建立：

```text
DORMANT
↓
WATCH
↓
ARMED
↓
OPPORTUNITY
↓
TRADE
↓
MANAGE
↓
EXIT
↓
REVIEW
```

其中：

```text
ARMED ≠ TRADE
```

必須等待：

```text
EV > threshold
AND
sample sufficient
AND
OOS survives
AND
cost survives
AND
current state matches
```

---

# XXVII. Shadow Trading

所有 Candidate 先進：

```text
SHADOW
```

不使用真實資金。

記錄：

```text
predicted entry
predicted structure
predicted EV
actual market result
slippage proxy
model error
```

然後比較：

```text
MODEL
vs
REALITY
```

---

# XXVIII. 自我修改

AI 不得自行修改核心規則而不留下記錄。

任何變更：

```text
OLD
→
HYPOTHESIS
→
CHANGE
→
TEST
→
RESULT
```

例如：

```text
OLD:
QQQ below MA20

NEW:
QQQ relative weakness vs SMH

Reason:
higher cross-regime stability

Test:
OOS + cost

Result:
PASS
```

---

# XXIX. Evolution Log

每次產生：

```json
{
  "event": "MUTATION",
  "parent": "GENE_00123",
  "child": "GENE_00981",
  "mutation": {
    "feature": "relative_QQQ_SMH",
    "expiry": "14D_to_30D"
  },
  "reason": "",
  "result": ""
}
```

其他事件：

```text
BIRTH
MUTATION
CROSSOVER
PROMOTION
DEMOTION
EXTINCTION
DORMANCY
RESURRECTION
REGIME_ADAPTATION
```

---

# XXX. Genetic Mutation

每一輪讓 Gene 發生：

### Feature Mutation

```text
MA20 → MA15
QQQ/SMH → QQQ/XLK
5D → 7D
```

### Structural Mutation

```text
CALL
→
CALL SPREAD
```

### Temporal Mutation

```text
7D
→
14D
→
30D
```

### Ratio Mutation

```text
1:1
→
1:2
→
2:1
```

### Regime Mutation

```text
all-regime
→
high-vol only
```

### Exit Mutation

```text
10D
→
event-based
→
turning probability based
```

---

# XXXI. Crossover

兩個成功 Gene 可以交叉。

例如：

```text
Gene A:
QQQ/SMH divergence

Gene B:
Persistence + recovery failure
```

產生：

```text
Gene C:

QQQ/SMH divergence
+
Persistence
+
Recovery failure
+
asymmetric option spread
```

然後重新完整測試。

---

# XXXII. Gene Diversity

禁止整個人口變成同一策略。

保留：

```text
top performers
+
different mechanisms
+
different regimes
+
different structures
```

即使某個 Gene 暫時不是第一名，也可以因為：

```text
mechanism diversity
```

而保留。

---

# XXXIII. Anti-Overfitting Rule

任何策略如果：

```text
IS 很高
OOS 大幅下降
```

自動標記：

```text
OVERFIT SUSPECT
```

如果：

```text
OOS negative
```

不能因為：

```text
IS CAGR 很高
```

重新包裝成成功。

---

# XXXIV. Sample Threshold

所有結果必須顯示：

```text
n
```

不要隱藏。

例如：

```text
EV = +8%
n = 7
```

必須標記：

```text
INSUFFICIENT SAMPLE
```

而：

```text
EV = +3%
n = 420
```

可能比它更值得研究。

---

# XXXV. Cost Sensitivity

至少測：

```text
0 cost
1× cost
2× cost
5× cost
10× cost
```

如果策略：

```text
0 cost = +18%
1× cost = +9%
2× cost = -3%
```

則：

```text
FRAGILE
```

不得進 Candidate Pool。

---

# XXXVI. Tail Analysis

每個策略必須：

```text
ES95
ES99
Worst 1%
Worst 5%
Maximum consecutive loss
Maximum adverse excursion
```

尤其是 option strategy：

```text
gap risk
volatility crush
time decay
expiry concentration
liquidity
```

必須單獨報告。

---

# XXXVII. 最重要的 Option 評價方式

不要問：

> 哪個 option structure 賺最多？

問：

> **在相同 directional exposure 下，哪種 structure 的 tail protection / convexity 最有效？**

建立：

```text
Directional CAGR
Hedge Cost
Tail Gain
MaxDD reduction
ES reduction
Convexity gain
Cost-adjusted EV
```

例如：

```text
Structure A

CAGR: 17%
MaxDD: -18%

Structure B

CAGR: 16%
MaxDD: -9%
ES95: -6%

Structure C

CAGR: 19%
MaxDD: -20%
```

B 可能才是更有價值的生命體。

---

# XXXVIII. Capital Efficiency

建立：

```text
Return / Risk
Return / Tail Risk
Return / Capital
Return / Margin
Tail Hedge / Cost
```

尤其研究：

> **用很小的 OTM option 成本，能否顯著改善左尾？**

以及：

> **不對稱 CALL/PUT、不同 expiry、不同 strike，能否把同一個 signal 轉化成更好的 payoff geometry？**

---

# XXXIX. Research Queue

系統永遠保持：

```text
NOW
NEXT
LATER
DORMANT
RESURRECTION
```

例如：

```text
NOW:
23 candidates

NEXT:
187 candidates

LATER:
4,831 candidates

DORMANT:
31,842 genes

DEAD:
72,191 genes

RESURRECTION:
1,204 genes due for review
```

---

# XL. 每一輪必須自動產生下一輪研究問題

不能只是：

```text
BACKTEST COMPLETE
```

必須產生：

```text
NEXT RESEARCH QUESTIONS
```

例如：

```text
1. Turning boundary appears around age 7–10.
   Test whether relative divergence improves timing.

2. OTM put protection is expensive.
   Test asymmetric 1:2 and 1:3 structures.

3. Signal works in high-vol but fails in low-vol.
   Test regime gating.

4. Dead Gene #4821 becomes similar to current regime.
   Resurrection test scheduled.

5. VXX acceleration precedes QQQ recovery failure in 63% of analogs.
   Test causal ordering.
```

---

# XLI. Research Priority

下一輪研究不是隨機。

Priority：

```text
Expected Information Gain
×
Potential Economic Value
×
Data Availability
×
Compute Feasibility
```

因此：

一個可能改變整個架構的研究問題，

即使目前沒有最高 CAGR，

也可能獲得大量算力。

---

# XLII. Compute Allocation

將算力視為有限資源。

例如：

```text
40% → promising genes
20% → adversarial testing
15% → new hypothesis generation
10% → resurrection
10% → option structures
5%  → exploratory anomalies
```

但 allocation 必須 adaptive。

如果某一方向：

```text
high information gain
```

自動增加算力。

如果：

```text
low marginal information
```

降低算力。

即：

```text
Compute Allocation
=
f(Expected Information Gain)
```

---

# XLIII. 不允許「算力越多只是 overfit 越多」

每增加搜尋空間：

```text
Candidate count ↑
```

必須同步增加：

```text
OOS
walk-forward
adversarial testing
multiple testing control
```

否則：

```text
search space ↑
false discoveries ↑
```

系統必須明確區分：

```text
DISCOVERY
vs
VALIDATION
```

---

# XLIV. Final Candidate Gate

只有同時通過：

```text
IS
OOS
Walk-forward
Sample
EV
MaxDD
ES
Cost
Regime
Parameter robustness
Adversarial test
```

才能：

```text
LIVE CANDIDATE
```

並且顯示：

```text
WHY ALIVE
```

---

# XLV. Candidate Card

每一個候選策略最後輸出：

```text
GENE ID

MECHANISM
────────────────
Relative divergence
Persistence
Turning boundary

CURRENT STATE
────────────────
ARMED

P(TURN)
P(ESCAPE)
P(REVERSION)

OPTION STRUCTURE
────────────────
21D / 45D
10Δ / 25Δ
1 : 2

EXPECTED EV
────────────────
...

IS
────────────────
...

OOS
────────────────
...

MAXDD
────────────────
...

ES95
────────────────
...

COST ROBUSTNESS
────────────────
...

REGIME ROBUSTNESS
────────────────
...

SAMPLE
────────────────
...

STATUS
────────────────
LIVE CANDIDATE
```

---

# XLVI. Dashboard 第一層

首頁不要先放股票排行榜。

先放：

```text
MARKET STATE
```

例如：

```text
REGIME:
VOL EXPANSION

QQQ:
RELATIVE WEAKNESS

PERSISTENCE:
87th percentile

TURN PROBABILITY:
64%

ESCAPE PROBABILITY:
23%

CONVERGENCE EV:
+4.1%

HEDGE EV:
+2.7%

OPTION CONVEXITY:
HIGH
```

---

# XLVII. Dashboard 第二層

顯示：

```text
TOP LIVE CANDIDATES
```

但按：

```text
risk-adjusted fitness
```

而非 CAGR。

---

# XLVIII. Dashboard 第三層

顯示：

```text
WATCHLIST

ARMED
NOT YET TRADEABLE
```

這一層極其重要。

因為：

> 最有價值的資訊有時不是「現在買」，而是「正在形成」。

---

# XLIX. Dashboard 第四層

顯示：

```text
EVENT CLOCK
```

數千個事件：

```text
EVENT
AGE
EXPECTED AGE
STATE
HAZARD
TURN PROBABILITY
ESCAPE PROBABILITY
```

提供搜尋、排序、filter。

---

# L. Dashboard 第五層

顯示：

```text
GENETIC TREE
```

例如：

```text
GENE_001
   │
   ├── GENE_041
   │      ├── GENE_982
   │      └── GENE_1021
   │
   └── GENE_083
          └── GENE_731
```

點擊任何 Gene：

```text
birth
mutations
parents
children
wins
failures
death
resurrection
```

---

# LI. Dashboard 第六層

顯示：

```text
DEAD BUT INTERESTING
```

例如：

```text
GENE_4821

Killed:
2025-06

Reason:
OOS decay

Current similarity:
94%

Potential resurrection:
HIGH
```

---

# LII. System Must Never Say

禁止：

```text
「這策略一定有效」
「市場一定會回歸」
「VXX 一定會上升」
「這是最佳策略」
```

改成：

```text
Historical evidence suggests...
Conditional probability...
Current state resembles...
Expected value...
Confidence...
Sample size...
```

---

# LIII. Final Output Every Research Cycle

每次完整研究完成，必須輸出：

```text
1. MARKET STATE

2. NEW DISCOVERIES

3. TOP GENES

4. FAILED GENES

5. RESURRECTED GENES

6. TURNING BOUNDARIES

7. EVENT CLOCK

8. OPTION STRUCTURE FRONTIER

9. RISK TRANSFER OPPORTUNITIES

10. PARETO FRONTIER

11. OOS RESULTS

12. COST ROBUSTNESS

13. TAIL RISK

14. CURRENT LIVE CANDIDATES

15. SHADOW CANDIDATES

16. NEXT RESEARCH QUESTIONS

17. COMPUTE ALLOCATION FOR NEXT ROUND
```

---

# LIV. 最重要的終極規則

這個系統不是：

```text
INPUT
→
PREDICTION
```

而是：

```text
OBSERVE
↓
GENERATE
↓
COMPETE
↓
ATTACK
↓
SELECT
↓
TRADE
↓
OBSERVE FAILURE
↓
MUTATE
↓
RETEST
↓
REMEMBER
↓
WAIT
↓
REGIME CHANGE
↓
RESURRECT
↓
EVOLVE
```

它不是「知道答案」。

它是：

> **知道自己不知道答案，並利用計算資源主動搜尋不知道的東西。**

---

# LV. Grok Build 的執行優先順序

不要一次把所有功能做成假的 UI。

按照：

```text
PHASE 1
External Data + State Memory

PHASE 2
Event Clock + Persistence

PHASE 3
Gene Population

PHASE 4
Mass Backtest

PHASE 5
OOS / Walk Forward

PHASE 6
Evolution

PHASE 7
Resurrection

PHASE 8
Option Structure Laboratory

PHASE 9
Risk Auction

PHASE 10
Shadow Trading

PHASE 11
Live Candidate Engine
```

每完成一層，都必須可以獨立運行。

---

# LVI. 最終哲學

不要問：

> 「哪個策略最好？」

問：

> 「在什麼市場狀態、什麼 persistence、什麼 relative structure、什麼 turning boundary、什麼 payoff geometry 下，哪個策略突然變得有利？」

再問：

> 「這種優勢什麼時候消失？」

再問：

> 「它死亡後，在什麼新的 State 下可能復活？」

最後問：

> 「下一個我們還沒有測過、但可能改變結論的東西是什麼？」

這才是 Evolutionary Trading AI。
:::
