# EVB LIFEFORM — Evolutionary Trading AI (COMPUTE-EXPANSION)

Organism scaffold: **birth / mutate / kill / dormant / resurrect** — not a single backtester UI.

Root: `/workspace/evb-life/`

## External memory (durable, not chat)

```
data/       market_data.parquet + DATA_MANIFEST.json
state/      market_state.json
genes/      gene_population.json, dead_gene_bank.json, candidate_pool.json, gene_schema.json
experiments/ experiment_log.jsonl
events/     event_memory.json
regimes/    regime_archive.json
options/    option_library.json  (catalog only — OPRA-blocked)
evolution/  evolution_log.jsonl  (JSONL: BIRTH/MUTATION/KILL/DORMANCY/RESURRECTION/…)
reports/    cycle_YYYYMMDD.md, event_clock_latest.md
docs/       MASTER_PROMPT_v2.md, PHASES.md, HONESTY.md, EVB_BRAIN_BLUEPRINT_V0_2.md
src/evb_life/
```

## Gene lifecycle

`BORN → INCUBATING → TESTING → PROMISING → ACTIVE → WEAKENING → DORMANT → DEAD → ARCHIVED`

Dead genes stay in `genes/dead_gene_bank.json` for resurrection review.

## Honesty (see `docs/HONESTY.md`)

- No BS option P/L as Verified
- No `fitness = CAGR`
- No “overdue = buy” (event age ≠ entry signal)
- Observed vs Hypothetical vs OPRA-blocked tags required

## Run Phase 1–2

```bash
cd /workspace/evb-life
python3 -m src.evb_life.cycle_phase1_2
```

Pipeline: **data hub → state engine → event clock → seed incubating genes → cycle report**.

Optional modules:

```bash
python3 -m src.evb_life.data_hub
```

## App (local dashboard)

Research UI under `app/` — reads external memory, can trigger **light** Phase 1–2 cycles. **Not live trading.**

```bash
bash app/start.sh
# open http://127.0.0.1:8787/
```

- Dashboard: MARKET STATE · EVENT CLOCK · TOP/SHADOW/LIVE candidates · gene population · evolution log · dead bank · reports
- Honesty banner: Observed vs Hypothetical · OPRA blocked · no BUY guarantees
- `POST /api/cycle` → `python3 -m src.evb_life.cycle_phase1_2` (or `cycle_full` if present)
- Optional: `python3 app/watchdog.py` (default every 30 min, light only — do not hammer backtests)

See `app/README.md`.

## Blueprint

Prior RVTE brain blueprint (linked):  
`docs/EVB_BRAIN_BLUEPRINT_V0_2.md` → `/workspace/qqq-vxx-desk/backtest/rvte/brain/EVB_BRAIN_BLUEPRINT_V0_2.md`

Master prompt: `docs/MASTER_PROMPT_v2.md` (Grok Build Master Prompt v2.0 — COMPUTE-EXPANSION).

## Phases

See `docs/PHASES.md`. Only Phase 1–2 are independently runnable in this scaffold.
