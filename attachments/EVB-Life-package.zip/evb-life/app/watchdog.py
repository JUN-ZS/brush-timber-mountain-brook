#!/usr/bin/env python3
"""Optional light watchdog: every N minutes run phase1_2 only and refresh reports.

Does NOT hammer 10k backtests. Prefer long intervals (default 30 min).
Usage:
  python3 app/watchdog.py              # 30 min
  EVB_WATCH_MINUTES=60 python3 app/watchdog.py
"""
from __future__ import annotations

import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MINUTES = max(5, int(os.environ.get("EVB_WATCH_MINUTES", "30")))


def log(msg: str) -> None:
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    print(f"[{ts}] {msg}", flush=True)


def run_light_cycle() -> int:
    cmd = ["python3", "-m", "src.evb_life.cycle_phase1_2"]
    log(f"light cycle: {' '.join(cmd)} (cwd={ROOT})")
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT / "src") + os.pathsep + env.get("PYTHONPATH", "")
    proc = subprocess.run(cmd, cwd=str(ROOT), env=env)
    log(f"exit={proc.returncode}")
    return proc.returncode


def main() -> int:
    log(
        f"EVB watchdog start — interval={MINUTES}m — ONLY phase1_2 (light). "
        "Heavy cycle_full / phase3_6 / mass backtests are NOT scheduled here."
    )
    while True:
        try:
            run_light_cycle()
        except Exception as e:
            log(f"error: {e}")
        log(f"sleep {MINUTES} minutes…")
        time.sleep(MINUTES * 60)


if __name__ == "__main__":
    sys.exit(main())
