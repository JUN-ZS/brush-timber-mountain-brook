/* EVB Life dashboard — reads /api/dashboard; triggers /api/cycle. No live trading. */
(function () {
  const $ = (id) => document.getElementById(id);

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function fmt(n, d) {
    if (n == null || n === "" || Number.isNaN(Number(n))) return "—";
    const x = Number(n);
    if (Math.abs(x) >= 100) return x.toFixed(d == null ? 2 : d);
    if (Math.abs(x) >= 1) return x.toFixed(d == null ? 4 : d);
    return x.toFixed(d == null ? 6 : d);
  }

  function pct(n) {
    if (n == null || Number.isNaN(Number(n))) return "—";
    return (Number(n) * 100).toFixed(2) + "%";
  }

  function tagClass(t) {
    const s = String(t || "").toLowerCase();
    if (s.includes("observed")) return "obs";
    if (s.includes("hypoth")) return "hyp";
    if (s.includes("derived")) return "derived";
    if (s.includes("estimat")) return "est";
    if (s.includes("opra")) return "opra";
    if (s.includes("active")) return "state";
    return "";
  }

  function tagsHtml(list) {
    if (!list || !list.length) return "";
    return (
      '<div class="tags">' +
      list
        .filter(Boolean)
        .map((t) => `<span class="tag ${tagClass(t)}">${esc(t)}</span>`)
        .join("") +
      "</div>"
    );
  }

  function geneTags(g) {
    const t = [];
    if (g.evidence_tag) t.push(g.evidence_tag);
    if (g.state) t.push(g.state);
    if ((g.hypothesis || {}).not_active) t.push("NOT ACTIVE");
    if ((g.option_structure || {}).status) t.push("opt:" + g.option_structure.status);
    if ((g.risk_budget || {}).phase) t.push(g.risk_budget.phase);
    const nIs = (g.is || {}).n;
    const nOos = (g.oos || {}).n;
    if (nIs != null) t.push("IS n=" + nIs);
    if (nOos != null) t.push("OOS n=" + nOos);
    if (nIs == null && nOos == null && (g.sample_count == null || g.sample_count === 0)) {
      t.push("INSUFFICIENT SAMPLE?");
    }
    return t;
  }

  function geneCard(g) {
    const hyp = (g.hypothesis || {}).statement || "";
    return (
      `<div class="card">` +
      `<div class="id">${esc(g.gene_id || "?")}</div>` +
      tagsHtml(geneTags(g)) +
      `<div class="meta">fitness=${esc(fmt(g.fitness))} · sample_count=${esc(g.sample_count ?? "—")}</div>` +
      (hyp ? `<div class="meta">${esc(hyp.slice(0, 160))}${hyp.length > 160 ? "…" : ""}</div>` : "") +
      `</div>`
    );
  }

  function progressBar(pctVal, phase, extraCls) {
    const p = pctVal == null || Number.isNaN(Number(pctVal)) ? 0 : Math.max(0, Math.min(100, Number(pctVal)));
    const cls =
      phase === "past_median" ? "bar past" : phase === "approaching" ? "bar approach" : "bar";
    return (
      `<div class="prog ${extraCls || ""}" title="${esc(p.toFixed(0))}%">` +
      `<div class="${cls}" style="width:${p.toFixed(1)}%"></div>` +
      `<span class="prog-lbl">${esc(p.toFixed(0))}%</span>` +
      `</div>`
    );
  }

  function renderMarket(state) {
    const el = $("market-state");
    if (!state || state._error) {
      el.innerHTML = `<div class="empty">無 market_state.json 或讀取失敗${state && state._error ? ": " + esc(state._error) : ""}</div>`;
      return;
    }
    const prices = state.prices || {};
    const trend = state.trend || {};
    const vol = state.relative_vol || {};
    const pers = state.persistence || {};
    const regimes = state.regime_hints || [];
    el.innerHTML =
      tagsHtml([state.evidence_tag || "Derived", "OPRA-blocked options"]) +
      `<div class="kv">` +
      `<div class="k">asof</div><div class="v">${esc(state.asof)}</div>` +
      `<div class="k">generated_utc</div><div class="v">${esc(state.generated_utc)}</div>` +
      `<div class="k">趨勢 trend</div><div class="v">${esc(trend.label)} · QQQ/MA20=${esc(fmt(trend.QQQ_over_MA20))} · DD20=${esc(pct(trend.DD20))}</div>` +
      `<div class="k">相對波動</div><div class="v">${esc(vol.label)} · RV5/RV20=${esc(fmt(vol.RV5_over_RV20))} · TermSlope=${esc(fmt(vol.TermSlope))} · VolPremium_z=${esc(fmt(vol.VolPremium_z))}</div>` +
      `<div class="k">持續性</div><div class="v">persist_below_MA20=${esc(pers.persist_below_MA20)} · mom2_improve=${esc(pers.mom2_improve)} · QQQ_1d_up=${esc(pers.QQQ_1d_up)}</div>` +
      `<div class="k">價格 (Observed)</div><div class="v">QQQ=${esc(fmt(prices.QQQ, 2))} · VIX=${esc(fmt(prices.VIX, 2))} · SPY=${esc(fmt(prices.SPY, 2))} · VXX=${esc(prices.VXX == null ? "null" : fmt(prices.VXX, 2))}</div>` +
      `<div class="k">regime_hints</div><div class="v">${esc(regimes.length ? regimes.join(", ") : "(none)")}</div>` +
      `<div class="k">notes_zh</div><div class="v">${esc(state.notes_zh || "")}</div>` +
      `</div>`;
  }

  function renderPhenomena(ph) {
    const el = $("phenomena");
    if (!ph) {
      el.innerHTML = `<div class="empty">無現象資料</div>`;
      return;
    }
    const now = ph.now || {};
    const cands = ph.elevated_turn_candidates || [];
    let html =
      tagsHtml(["研究級", "空 LIVE"]) +
      `<div class="now-box">` +
      `<div class="now-title">此刻</div>` +
      `<div class="now-text">${esc(now.now_zh || "—")}</div>` +
      `<ul class="bullet-zh">` +
      (now.bullets || []).map((b) => `<li>${esc(b)}</li>`).join("") +
      `</ul>` +
      `</div>` +
      `<p class="disclaimer">${esc(ph.disclaimer_zh || "空 LIVE 交易 · 非買賣建議")}</p>` +
      `<h3 class="subh">${esc(ph.elevated_label_zh || "高機率轉向候選（研究級）")} · n=${cands.length}</h3>`;

    if (!cands.length) {
      html += `<div class="empty">目前沒有與現況明顯重疊的 ACTIVE/PROMISING 基因</div>`;
      el.innerHTML = html;
      return;
    }
    html += `<div class="cand-list">`;
    for (const c of cands) {
      html +=
        `<div class="card cand-hit">` +
        `<div class="id">${esc(c.gene_id)}</div>` +
        tagsHtml([
          c.tag_kind,
          c.evidence_tag,
          c.state,
          "overlap=" + fmt(c.overlap_score, 2),
          c.is_n != null ? "IS n=" + c.is_n : null,
          c.oos_n != null ? "OOS n=" + c.oos_n : null,
        ]) +
        `<div class="meta">fitness=${esc(fmt(c.fitness))} · 重疊：${esc((c.overlap_hits || []).join(", ") || "—")}</div>` +
        (c.hypothesis_one_liner
          ? `<div class="meta hyp-line">${esc(c.hypothesis_one_liner)}</div>`
          : "") +
        `</div>`;
    }
    html += `</div>`;
    el.innerHTML = html;
  }

  function renderEvents(ec) {
    const el = $("event-clock");
    if (!ec) {
      el.innerHTML = `<div class="empty">無事件記憶</div>`;
      return;
    }
    const rows = ec.top_rows || [];
    let html =
      tagsHtml([ec.evidence_tag, "anti-gambler", "缺席≠該買"]) +
      `<div class="stats">` +
      `<div class="stat"><div class="n">${esc(ec.n_events)}</div><div class="l">事件 n</div></div>` +
      `<div class="stat"><div class="n">${esc(ec.asof || "—")}</div><div class="l">asof</div></div>` +
      `</div>` +
      `<p class="muted">${esc(ec.anti_gambler_zh || ec.anti_gambler_rule || "")}</p>`;
    if (!rows.length) {
      html += `<div class="empty">尚無事件列</div>`;
      el.innerHTML = html;
      return;
    }
    html += `<div class="event-rows">`;
    for (const r of rows) {
      const late = r.late_minus_early_hazard;
      const absence = r.absence_not_buy || (late != null && Number(late) <= 0 ? "缺席≠該買" : null);
      const phase = r.countdown_phase || "";
      html +=
        `<div class="event-row">` +
        `<div class="event-head">` +
        `<span class="mono id">${esc(r.event_id)}</span>` +
        tagsHtml([
          absence,
          r.confidence,
          r.countdown_phase === "past_median" ? "已過中位" : r.countdown_phase === "approaching" ? "接近中位" : null,
        ]) +
        `</div>` +
        `<div class="event-def muted">${esc(r.event_definition || "")}</div>` +
        `<div class="event-metrics">` +
        `<span>年齡 <b>${esc(r.days_since_occurrence ?? "—")}</b> 日</span>` +
        `<span>中位 <b>${esc(fmt(r.median_interval_IS, 1))}</b></span>` +
        `<span>P90 <b>${esc(fmt(r.p90_interval_IS, 1))}</b></span>` +
        `<span>age/med <b>${esc(fmt(r.age_over_median_IS, 2))}</b></span>` +
        `<span>n_IS <b>${esc(r.n_occurrences_IS ?? "—")}</b></span>` +
        `<span>late−early <b class="${late != null && late <= 0 ? "err" : ""}">${esc(fmt(late, 4))}</b></span>` +
        `</div>` +
        progressBar(r.progress_pct, phase) +
        (r.progress_vs_p90_pct != null
          ? `<div class="p90-wrap"><span class="muted tiny">vs P90</span>${progressBar(r.progress_vs_p90_pct, phase, "thin")}</div>`
          : "") +
        `<div class="countdown-label">${esc(r.countdown_label_zh || "")}</div>` +
        `<div class="anti-note">${esc(r.anti_gambler_note_zh || "逾期≠買入")}</div>` +
        `</div>`;
    }
    html += `</div>`;
    el.innerHTML = html;
  }

  function renderCombos(ec) {
    const el = $("event-combos");
    if (!ec) {
      el.innerHTML = `<div class="empty">尚無 event_combos.json — 請跑一次 light cycle</div>`;
      return;
    }
    const rows = ec.top || [];
    let html =
      tagsHtml([ec.evidence_tag, "配搭≠訊號"]) +
      `<div class="stats">` +
      `<div class="stat"><div class="n">${esc(ec.n_flagged ?? "—")}</div><div class="l">flagged lift</div></div>` +
      `<div class="stat"><div class="n">${esc(ec.n_pairs ?? "—")}</div><div class="l">pairs</div></div>` +
      `<div class="stat"><div class="n">${esc(ec.k_days ?? "—")}</div><div class="l">k 日窗</div></div>` +
      `<div class="stat"><div class="n">${esc(ec.asof || "—")}</div><div class="l">asof</div></div>` +
      `</div>` +
      `<p class="muted">${esc(ec.honesty_zh || "")}</p>`;
    if (!rows.length) {
      html += `<div class="empty">尚無配搭列</div>`;
      el.innerHTML = html;
      return;
    }
    html +=
      `<div class="scroll"><table><thead><tr>` +
      `<th>配搭</th><th>lift</th><th>n_joint</th><th>tag</th><th>今日 ACTIVE</th><th>legs age</th>` +
      `</tr></thead><tbody>`;
    for (const r of rows) {
      const active = r.active_today ? "是 · 兩腿皆活躍／偏老" : "否";
      const ds = r.days_since || {};
      html +=
        `<tr class="${r.active_today ? "row-active" : ""}">` +
        `<td><div class="mono">${esc(r.combo_id)}</div>` +
        `<div class="tiny muted">${esc((r.definitions || []).join(" × "))}</div></td>` +
        `<td class="mono">${esc(fmt(r.lift, 2))}</td>` +
        `<td>${esc(r.n_joint)}</td>` +
        `<td>${tagsHtml([r.evidence_tag, r.flagged_lift ? "lift>1.3" : null])}</td>` +
        `<td class="${r.active_today ? "ok" : "muted"}">${esc(active)}</td>` +
        `<td class="mono tiny">${esc(ds.a ?? "—")} / ${esc(ds.b ?? "—")} 日</td>` +
        `</tr>`;
    }
    html += `</tbody></table></div>`;
    el.innerHTML = html;
  }

  function renderCandidates(c) {
    const el = $("candidates");
    if (!c) {
      el.innerHTML = `<div class="empty">無候選</div>`;
      return;
    }
    const block = (title, arr, emptyMsg) => {
      let h = `<div class="cand-col"><h3>${esc(title)} · n=${arr.length}</h3>`;
      if (!arr.length) h += `<div class="empty">${esc(emptyMsg)}</div>`;
      else h += arr.map(geneCard).join("");
      h += `</div>`;
      return h;
    };
    el.innerHTML =
      `<div class="stats">` +
      `<div class="stat"><div class="n">${esc(c.n_pop)}</div><div class="l">population</div></div>` +
      `<div class="stat"><div class="n">${esc(c.n_pool)}</div><div class="l">candidate_pool</div></div>` +
      `<div class="stat"><div class="n">${esc((c.live || []).length)}</div><div class="l">LIVE (ACTIVE)</div></div>` +
      `</div>` +
      `<div class="cand-cols">` +
      block("TOP（風險調整 fitness）", c.top || [], "尚無 TOP 候選") +
      block("SHADOW / WATCH（孵化·測試·休眠）", c.shadow || [], "尚無 SHADOW") +
      block("LIVE（ACTIVE — 研究儀表板不代表實盤）", c.live || [], "無 LIVE · 空交易狀態") +
      `</div>`;
  }

  function renderPop(gp) {
    const el = $("gene-pop");
    if (!gp) {
      el.innerHTML = `<div class="empty">gene_population 空白</div>`;
      return;
    }
    const counts = gp.counts_by_state || {};
    const order = [
      "BORN",
      "INCUBATING",
      "TESTING",
      "PROMISING",
      "ACTIVE",
      "WEAKENING",
      "DORMANT",
      "DEAD",
      "ARCHIVED",
    ];
    let stats = `<div class="stats"><div class="stat"><div class="n">${esc(gp.n)}</div><div class="l">總基因 n</div></div>`;
    for (const st of order) {
      const n = counts[st] || 0;
      if (n || ["INCUBATING", "ACTIVE", "DEAD"].includes(st)) {
        stats += `<div class="stat"><div class="n">${n}</div><div class="l">${st}</div></div>`;
      }
    }
    for (const st of Object.keys(counts)) {
      if (!order.includes(st)) {
        stats += `<div class="stat"><div class="n">${counts[st]}</div><div class="l">${esc(st)}</div></div>`;
      }
    }
    stats += `</div>`;
    if (gp.genes_total != null && gp.genes_shown != null && gp.genes_total > gp.genes_shown) {
      stats += `<p class="muted">表內顯示 ${esc(gp.genes_shown)} / ${esc(gp.genes_total)}（按 fitness 截斷）</p>`;
    }
    if (!gp.n) {
      el.innerHTML = stats + `<div class="empty">gene_population 為空 — 仍可渲染空狀態</div>`;
      return;
    }
    let table =
      `<div class="scroll"><table><thead><tr>` +
      `<th>gene_id</th><th>state</th><th>tag</th><th>fitness</th><th>IS n</th><th>OOS n</th>` +
      `</tr></thead><tbody>`;
    for (const g of gp.genes || []) {
      table +=
        `<tr>` +
        `<td class="mono">${esc(g.gene_id)}</td>` +
        `<td><span class="tag state">${esc(g.state)}</span></td>` +
        `<td>${tagsHtml([g.evidence_tag])}</td>` +
        `<td class="mono">${esc(fmt(g.fitness))}</td>` +
        `<td>${esc((g.is || {}).n ?? "—")}</td>` +
        `<td>${esc((g.oos || {}).n ?? "—")}</td>` +
        `</tr>`;
    }
    table += `</tbody></table></div>`;
    el.innerHTML = stats + table;
  }

  function renderEvo(rows) {
    const el = $("evo-log");
    if (!rows || !rows.length) {
      el.innerHTML = `<div class="empty">evolution_log.jsonl 尚無紀錄</div>`;
      return;
    }
    let html =
      `<div class="scroll"><table><thead><tr>` +
      `<th>ts</th><th>event</th><th>gene</th><th>→state</th><th>reason</th>` +
      `</tr></thead><tbody>`;
    const rev = rows.slice().reverse();
    for (const r of rev) {
      html +=
        `<tr>` +
        `<td class="mono">${esc(r.ts)}</td>` +
        `<td>${esc(r.event)}</td>` +
        `<td class="mono">${esc(r.gene_id || r.child || "")}</td>` +
        `<td>${esc(r.to_state || "")}</td>` +
        `<td>${esc(r.reason || "")}</td>` +
        `</tr>`;
    }
    html += `</tbody></table></div>`;
    el.innerHTML = html;
  }

  function renderDead(dead) {
    const el = $("dead-bank");
    if (!dead || !dead.length) {
      el.innerHTML = `<div class="empty">dead_gene_bank 為空 — 尚無可復活樣本</div>`;
      return;
    }
    el.innerHTML =
      `<div class="stats"><div class="stat"><div class="n">${dead.length}</div><div class="l">樣本列</div></div></div>` +
      dead
        .slice(0, 20)
        .map((g) => {
          if (typeof g !== "object") return `<div class="card mono">${esc(JSON.stringify(g))}</div>`;
          return (
            `<div class="card">` +
            `<div class="id">${esc(g.gene_id || g.id || "?")}</div>` +
            tagsHtml([g.state || "DEAD", g.kill_reason || g.reason, g.evidence_tag]) +
            `<div class="meta">${esc((g.hypothesis || {}).statement || g.note || "")}</div>` +
            `</div>`
          );
        })
        .join("");
  }

  function renderReports(list) {
    const el = $("reports");
    if (!list || !list.length) {
      el.innerHTML = `<div class="empty">reports/ 尚無 .md</div>`;
      return;
    }
    el.innerHTML =
      `<ul>` +
      list
        .map(
          (r) =>
            `<li><a href="${esc(r.path)}" target="_blank" rel="noopener">${esc(r.name)}</a>` +
            ` <span class="muted">· ${esc(r.mtime)} · ${esc(r.size)} B</span></li>`
        )
        .join("") +
      `</ul>`;
  }

  function renderCycle(st) {
    const el = $("cycle-status");
    const badge = $("cycle-badge");
    const btn = $("btn-cycle");
    if (!st) {
      el.innerHTML = `<div class="empty">—</div>`;
      return;
    }
    if (st.running) {
      badge.textContent = "運行中";
      badge.className = "badge run";
      btn.disabled = true;
    } else if (st.last_exit_code === 0) {
      badge.textContent = "上次成功";
      badge.className = "badge ok";
      btn.disabled = false;
    } else if (st.last_exit_code != null && st.last_exit_code !== 0) {
      badge.textContent = "上次失敗";
      badge.className = "badge err";
      btn.disabled = false;
    } else {
      badge.textContent = "閒置";
      badge.className = "badge idle";
      btn.disabled = false;
    }
    el.innerHTML =
      `<div class="kv">` +
      `<div class="k">running</div><div class="v">${esc(st.running)}</div>` +
      `<div class="k">cmd</div><div class="v mono">${esc(st.last_cmd || "—")}</div>` +
      `<div class="k">note</div><div class="v">${esc(st.note || "")}</div>` +
      `<div class="k">started</div><div class="v">${esc(st.last_started || "—")}</div>` +
      `<div class="k">finished</div><div class="v">${esc(st.last_finished || "—")}</div>` +
      `<div class="k">exit</div><div class="v">${esc(st.last_exit_code)}</div>` +
      `</div>` +
      (st.last_stdout_tail
        ? `<p class="muted">stdout tail</p><pre class="raw">${esc(st.last_stdout_tail)}</pre>`
        : "") +
      (st.last_stderr_tail
        ? `<p class="muted">stderr tail</p><pre class="raw">${esc(st.last_stderr_tail)}</pre>`
        : "");
  }

  async function loadDashboard() {
    const res = await fetch("/api/dashboard", { cache: "no-store" });
    if (!res.ok) throw new Error("dashboard HTTP " + res.status);
    const data = await res.json();
    renderMarket(data.market_state);
    renderPhenomena(data.phenomena);
    renderEvents(data.event_clock);
    renderCombos(data.event_combos);
    renderCandidates(data.candidates);
    renderPop(data.gene_population);
    renderEvo(data.evolution_log_tail);
    renderDead(data.dead_but_interesting);
    renderReports(data.reports);
    renderCycle((data.meta || {}).cycle || {});
    $("last-refresh").textContent =
      "刷新 " + new Date().toLocaleString("zh-HK", { timeZone: "Asia/Hong_Kong" }) + " HKT";
    return data;
  }

  async function pollCycleWhileRunning() {
    for (let i = 0; i < 120; i++) {
      await new Promise((r) => setTimeout(r, 1500));
      try {
        const res = await fetch("/api/cycle/status", { cache: "no-store" });
        const st = await res.json();
        renderCycle(st);
        if (!st.running) {
          await loadDashboard();
          return;
        }
      } catch (_) {
        /* ignore transient */
      }
    }
  }

  $("btn-refresh").addEventListener("click", () => {
    loadDashboard().catch((e) => alert(String(e)));
  });

  $("btn-cycle").addEventListener("click", async () => {
    $("btn-cycle").disabled = true;
    try {
      const res = await fetch("/api/cycle", { method: "POST" });
      const body = await res.json();
      renderCycle(body.status || body);
      if (res.status === 202 || (body.status && body.status.running)) {
        pollCycleWhileRunning();
      } else if (res.status === 409) {
        pollCycleWhileRunning();
      } else {
        $("btn-cycle").disabled = false;
        await loadDashboard();
      }
    } catch (e) {
      $("btn-cycle").disabled = false;
      alert(String(e));
    }
  });

  loadDashboard().catch((e) => {
    const msg = `<div class="err">載入失敗：${esc(e)}</div>`;
    for (const id of [
      "market-state",
      "phenomena",
      "event-clock",
      "event-combos",
      "candidates",
      "gene-pop",
      "evo-log",
      "dead-bank",
      "reports",
      "cycle-status",
    ]) {
      const el = $(id);
      if (el) el.innerHTML = msg;
    }
  });

  setInterval(() => {
    loadDashboard().catch(() => {});
  }, 60000);
})();
