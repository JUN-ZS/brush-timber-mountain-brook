# EVB Life — Local Web App (Dashboard)

Single-page research dashboard that **auto-reads durable external memory** under `/workspace/evb-life/` and can trigger a **light** research cycle. **Not live trading.** No BUY guarantees.

## Start

```bash
cd /workspace/evb-life
bash app/start.sh
# → http://127.0.0.1:8787/
```

Or:

```bash
EVB_APP_PORT=8787 python3 app/server.py
```

## Panels

1. **MARKET STATE** — `state/market_state.json`
2. **EVENT CLOCK** — `events/event_memory.json` top rows
3. **TOP / SHADOW / LIVE CANDIDATES** — `genes/candidate_pool.json` + `gene_population.json`
4. **GENE POPULATION** — counts by lifecycle state
5. **EVOLUTION LOG** — last 50 lines of `evolution/evolution_log.jsonl`
6. **DEAD BUT INTERESTING** — `genes/dead_gene_bank.json` sample
7. **REPORTS** — links to `reports/*.md`
8. **Honesty banner** — Observed vs Hypothetical · OPRA blocked · no BUY guarantees

## Cycle API

- `POST /api/cycle` — shells `python3 -m src.evb_life.cycle_phase1_2` (or `cycle_full` if that module exists). Async; poll `GET /api/cycle/status`.
- `GET /api/dashboard` — full payload for the UI.
- `GET /api/health` — liveness.

Heavy mass backtests are **not** chained from the UI.

## Optional watchdog

```bash
# default every 30 minutes — light phase1_2 only
python3 app/watchdog.py
EVB_WATCH_MINUTES=60 python3 app/watchdog.py
```

Do **not** set a 1-minute interval for 10k backtests.

## Stack

Python 3 stdlib `http.server` (`ThreadingHTTPServer`) + static HTML/JS/CSS. Zero new heavy deps.
