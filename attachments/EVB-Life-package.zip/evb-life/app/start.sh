#!/usr/bin/env bash
# Launch EVB Life local dashboard on port 8787
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
export EVB_APP_PORT="${EVB_APP_PORT:-8787}"
export EVB_APP_HOST="${EVB_APP_HOST:-0.0.0.0}"
export PYTHONPATH="${ROOT}/src${PYTHONPATH:+:$PYTHONPATH}"
exec python3 "$ROOT/app/server.py"
