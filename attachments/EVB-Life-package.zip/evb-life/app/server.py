#!/usr/bin/env python3
"""EVB Life local dashboard — reads external memory; can trigger light cycles.

No live trading. No fake BUY guarantees. Honesty tags required.
"""
from __future__ import annotations

import json
import os
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

APP_DIR = Path(__file__).resolve().parent
ROOT = APP_DIR.parent
STATIC = APP_DIR / "static"
PORT = int(os.environ.get("EVB_APP_PORT", "8787"))

STATE_PATH = ROOT / "state" / "market_state.json"
EVENTS_PATH = ROOT / "events" / "event_memory.json"
COMBOS_PATH = ROOT / "events" / "event_combos.json"
CANDIDATES_PATH = ROOT / "genes" / "candidate_pool.json"
POP_PATH = ROOT / "genes" / "gene_population.json"
DEAD_PATH = ROOT / "genes" / "dead_gene_bank.json"
EVO_LOG = ROOT / "evolution" / "evolution_log.jsonl"
REPORTS_DIR = ROOT / "reports"

_cycle_lock = threading.Lock()
_cycle_status: dict = {
    "running": False,
    "last_started": None,
    "last_finished": None,
    "last_exit_code": None,
    "last_cmd": None,
    "last_stdout_tail": "",
    "last_stderr_tail": "",
    "note": "",
}


def _json_safe(obj):
    """Make payload browser-JSON.parse safe (no NaN/Infinity)."""
    import math
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
        return obj
    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_json_safe(v) for v in obj]
    if isinstance(obj, tuple):
        return [_json_safe(v) for v in obj]
    return obj


def _gene_row(g: dict) -> dict:
    """Slim gene for dashboard tables (avoid multi-MB payloads)."""
    if not isinstance(g, dict):
        return {"_raw": str(g)[:200]}
    is_ = g.get("is") if isinstance(g.get("is"), dict) else {}
    oos = g.get("oos") if isinstance(g.get("oos"), dict) else {}
    hyp = g.get("hypothesis") if isinstance(g.get("hypothesis"), dict) else {}
    return {
        "gene_id": g.get("gene_id"),
        "state": g.get("state"),
        "evidence_tag": g.get("evidence_tag"),
        "fitness": g.get("fitness"),
        "sample_count": g.get("sample_count"),
        "max_drawdown": g.get("max_drawdown"),
        "es95": g.get("es95"),
        "is": {"n": is_.get("n"), "mean": is_.get("mean"), "wr": is_.get("wr")},
        "oos": {"n": oos.get("n"), "mean": oos.get("mean"), "wr": oos.get("wr")},
        "hypothesis": {"statement": (hyp.get("statement") or "")[:200]},
        "failure_reason": (g.get("failure_reason") or "")[:160],
    }


def _slim_dead(g: dict) -> dict:
    if not isinstance(g, dict):
        return {"_raw": str(g)[:200]}
    hyp = g.get("hypothesis") if isinstance(g.get("hypothesis"), dict) else {}
    return {
        "gene_id": g.get("gene_id") or g.get("id"),
        "state": g.get("state") or "DEAD",
        "evidence_tag": g.get("evidence_tag"),
        "kill_reason": g.get("kill_reason") or g.get("failure_reason") or g.get("reason"),
        "hypothesis": {"statement": (hyp.get("statement") or g.get("note") or "")[:200]},
        "resurrection_condition": (g.get("resurrection_condition") or "")[:160],
    }


def _read_json(path: Path, default):
    try:
        if not path.exists():
            return default
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        return {"_error": str(e), "_path": str(path)}


def _tail_jsonl(path: Path, n: int = 50) -> list:
    if not path.exists():
        return []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
        out = []
        for line in lines[-n:]:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                out.append({"raw": line})
        return out
    except Exception as e:
        return [{"_error": str(e)}]


def _lifecycle_counts(pop: list) -> dict:
    counts: dict[str, int] = {}
    if not isinstance(pop, list):
        return counts
    for g in pop:
        if not isinstance(g, dict):
            continue
        st = g.get("state") or "UNKNOWN"
        counts[st] = counts.get(st, 0) + 1
    return counts


def _filter_candidates(pop: list, pool: list) -> dict:
    """Split genes by lifecycle buckets for TOP / SHADOW / LIVE panels."""
    items = []
    if isinstance(pool, list) and pool:
        items = [g for g in pool if isinstance(g, dict)]
    elif isinstance(pop, list):
        items = [g for g in pop if isinstance(g, dict)]

    def score(g):
        f = g.get("fitness")
        try:
            return float(f) if f is not None else float("-inf")
        except (TypeError, ValueError):
            return float("-inf")

    top = sorted(items, key=score, reverse=True)[:20]
    shadow = [
        g
        for g in items
        if (g.get("state") or "") in ("INCUBATING", "TESTING", "PROMISING", "DORMANT", "BORN")
        or (g.get("hypothesis") or {}).get("not_active")
        or (g.get("evidence_tag") or "").lower() in ("hypothetical",)
    ]
    live = [
        g
        for g in items
        if (g.get("state") or "") in ("ACTIVE", "WEAKENING")
        and not (g.get("hypothesis") or {}).get("not_active")
    ]
    return {
        "top": top,
        "shadow": shadow[:30],
        "live": live[:30],
        "n_pool": len(pool) if isinstance(pool, list) else 0,
        "n_pop": len(pop) if isinstance(pop, list) else 0,
    }


def _safe_float(x):
    try:
        if x is None:
            return None
        v = float(x)
        if v != v:  # NaN
            return None
        return v
    except (TypeError, ValueError):
        return None


def _countdown_fields(ev: dict) -> dict:
    """Progress toward typical occurrence + Traditional Chinese labels."""
    age = _safe_float(ev.get("days_since_occurrence"))
    median = _safe_float(ev.get("median_interval_IS"))
    dist = ev.get("distribution_IS") if isinstance(ev.get("distribution_IS"), dict) else {}
    p90 = _safe_float(dist.get("p90"))
    haz = ev.get("hazard_estimate_unconditional") or {}
    late = _safe_float(haz.get("late_minus_early_hazard"))

    progress_pct = None
    progress_vs_p90_pct = None
    days_to_median = None
    over_median_pct = None
    label_zh = "尚無足夠中位間隔"
    phase = "unknown"

    if age is not None and median is not None and median > 0:
        ratio = age / median
        progress_pct = max(0.0, min(100.0, ratio * 100.0))
        if age < median:
            days_to_median = median - age
            label_zh = f"距離歷史中位還差 {days_to_median:.0f} 日"
            phase = "approaching"
        else:
            over_median_pct = (ratio - 1.0) * 100.0
            label_zh = f"已超過中位 {over_median_pct:.0f}%"
            phase = "past_median"

    if age is not None and p90 is not None and p90 > 0:
        progress_vs_p90_pct = max(0.0, min(100.0, (age / p90) * 100.0))

    anti_note = "逾期≠買入 · 年齡只是時鐘"
    absence_flag = None
    if late is not None and late <= 0:
        absence_flag = "缺席≠該買"
        anti_note = "缺席≠該買 · late−early hazard ≤ 0，年齡無 timing edge"

    return {
        "age_days": age,
        "median_days": median,
        "p90_days": p90,
        "progress_pct": progress_pct,
        "progress_vs_p90_pct": progress_vs_p90_pct,
        "days_to_median": days_to_median,
        "over_median_pct": over_median_pct,
        "countdown_label_zh": label_zh,
        "countdown_phase": phase,
        "late_minus_early_hazard": late,
        "absence_not_buy": absence_flag,
        "anti_gambler_note_zh": anti_note,
    }


def _event_top_rows(mem, limit: int = 25) -> list:
    if not isinstance(mem, dict):
        return []
    events = mem.get("events") or []
    if not isinstance(events, list):
        return []
    rows = []
    for ev in events:
        if not isinstance(ev, dict):
            continue
        haz = ev.get("hazard_estimate_unconditional") or {}
        late = haz.get("late_minus_early_hazard")
        cd = _countdown_fields(ev)
        rows.append(
            {
                "event_id": ev.get("event_id"),
                "event_definition": ev.get("event_definition"),
                "last_occurrence": ev.get("last_occurrence"),
                "days_since_occurrence": ev.get("days_since_occurrence"),
                "median_interval_IS": ev.get("median_interval_IS"),
                "age_over_median_IS": ev.get("age_over_median_IS"),
                "n_occurrences_IS": ev.get("n_occurrences_IS"),
                "n_occurrences_full": ev.get("n_occurrences_full"),
                "late_minus_early_hazard": late,
                "current_regime": ev.get("current_regime") or [],
                "confidence": ev.get("confidence"),
                "p90_interval_IS": cd.get("p90_days"),
                # countdown bar fields
                "progress_pct": cd.get("progress_pct"),
                "progress_vs_p90_pct": cd.get("progress_vs_p90_pct"),
                "days_to_median": cd.get("days_to_median"),
                "over_median_pct": cd.get("over_median_pct"),
                "countdown_label_zh": cd.get("countdown_label_zh"),
                "countdown_phase": cd.get("countdown_phase"),
                "absence_not_buy": cd.get("absence_not_buy"),
                "anti_gambler_note_zh": cd.get("anti_gambler_note_zh"),
            }
        )
    rows.sort(
        key=lambda r: (
            abs(r.get("age_over_median_IS") or 0),
            r.get("days_since_occurrence") or 0,
        ),
        reverse=True,
    )
    return rows[:limit]


def _plain_zh_market(state: dict) -> dict:
    """Plain Traditional Chinese summary of what is happening NOW."""
    if not isinstance(state, dict):
        return {"now_zh": "無市場狀態", "bullets": []}
    trend = state.get("trend") or {}
    vol = state.get("relative_vol") or {}
    pers = state.get("persistence") or {}
    prices = state.get("prices") or {}

    tlabel = trend.get("label") or "未知"
    trend_map = {
        "below_MA20": "QQQ 現價低於 20 日均線（偏弱／回調區）",
        "above_MA20": "QQQ 現價高於 20 日均線（偏強）",
        "below_MA50": "QQQ 低於 50 日均線",
        "above_MA50": "QQQ 高於 50 日均線",
    }
    trend_zh = trend_map.get(tlabel, f"趨勢標籤：{tlabel}")

    vlabel = vol.get("label") or "unknown"
    vol_map = {
        "expansion": "短期波動相對擴張（RV5/RV20 偏高）",
        "compression": "短期波動相對壓縮（RV5/RV20 偏低）",
        "neutral": "相對波動中性",
    }
    vol_zh = vol_map.get(vlabel, f"波動狀態：{vlabel}")

    persist = pers.get("persist_below_MA20")
    mom = pers.get("mom2_improve")
    up1 = pers.get("QQQ_1d_up")
    vpz_fall = pers.get("VolPremium_z_falling")

    bullets = [
        trend_zh,
        vol_zh,
        f"連續低於 MA20：{persist} 日" if persist is not None else "持續性：無資料",
    ]
    if mom is True:
        bullets.append("動能改善中（mom2_improve）— 弱勢中可能出現轉向苗頭")
    elif mom is False:
        bullets.append("動能尚未改善（mom2_improve=false）")
    if up1 is True:
        bullets.append("今日 QQQ 收升（1d up）")
    elif up1 is False:
        bullets.append("今日 QQQ 未收升")
    if vpz_fall is True:
        bullets.append("波動溢價 z 分數回落中")

    over = _safe_float(trend.get("QQQ_over_MA20"))
    dd20 = _safe_float(trend.get("DD20"))
    if over is not None:
        bullets.append(f"QQQ 相對 MA20：{over * 100:.2f}%")
    if dd20 is not None:
        bullets.append(f"近 20 日回撤 DD20：{dd20 * 100:.2f}%")

    vix = prices.get("VIX")
    if vix is not None:
        bullets.append(f"VIX≈{_safe_float(vix):.1f}" if _safe_float(vix) is not None else "VIX：—")

    now_zh = "；".join(bullets[:3])
    return {
        "asof": state.get("asof"),
        "now_zh": now_zh,
        "bullets": bullets,
        "trend_label": tlabel,
        "vol_label": vlabel,
        "persist_below_MA20": persist,
        "mom2_improve": mom,
        "QQQ_1d_up": up1,
    }


def _score_gene_vs_state(g: dict, state: dict) -> tuple[float, list[str]]:
    """Simple overlap score between entry_logic and current market_state."""
    el = g.get("entry_logic")
    if not isinstance(el, dict) or el.get("inherits"):
        return 0.0, []
    trend = state.get("trend") or {}
    vol = state.get("relative_vol") or {}
    pers = state.get("persistence") or {}

    q_over = _safe_float(trend.get("QQQ_over_MA20"))
    dd20 = _safe_float(trend.get("DD20"))
    persist = pers.get("persist_below_MA20")
    try:
        persist = int(persist) if persist is not None else None
    except (TypeError, ValueError):
        persist = None

    hits: list[str] = []
    checks = 0

    ma_below = _safe_float(el.get("ma_below"))
    if ma_below is not None:
        checks += 1
        if q_over is not None and q_over <= -abs(ma_below):
            hits.append(f"below_MA≤-{abs(ma_below)*100:.0f}%")
        elif q_over is not None and q_over < 0 and abs(ma_below) <= 0.01:
            # soft: currently below MA when gene wants mild below
            hits.append("below_MA(soft)")

    dd_th = _safe_float(el.get("dd20"))
    if dd_th is not None:
        checks += 1
        if dd20 is not None and dd20 <= dd_th:
            hits.append(f"DD20≤{dd_th}")

    age_th = el.get("persist_age")
    try:
        age_th = int(age_th) if age_th is not None else None
    except (TypeError, ValueError):
        age_th = None
    if age_th is not None:
        checks += 1
        if persist is not None and persist >= age_th:
            hits.append(f"persist≥{age_th}")
        elif persist is not None and persist >= max(1, age_th - 2):
            hits.append(f"persist≈{persist}(near)")

    def _flag(key, cur, label):
        nonlocal checks
        want = el.get(key)
        if want in (None, 0, False):
            return
        checks += 1
        if cur is True:
            hits.append(label)

    _flag("trans_1d_up", pers.get("QQQ_1d_up") is True, "1d_up")
    _flag("trans_mom_improve", pers.get("mom2_improve") is True, "mom_improve")
    _flag("trans_vpz_fall", pers.get("VolPremium_z_falling") is True, "vpz_fall")
    _flag("trans_vix_down", False, "vix_down")  # no direct flag; skip hit

    if el.get("use_back") in (1, True):
        checks += 1
        if _safe_float(vol.get("backwardation")) and (_safe_float(vol.get("backwardation")) or 0) > 0:
            hits.append("backwardation")

    if el.get("use_term") in (1, True):
        checks += 1
        ts = _safe_float(vol.get("TermSlope"))
        if ts is not None and ts > 1.05:
            hits.append("term_steep")

    if checks == 0:
        return 0.0, []
    # soft near-hits count half
    score = 0.0
    for h in hits:
        score += 0.5 if "(near)" in h or "(soft)" in h else 1.0
    return score / checks, hits


def _build_phenomena(state: dict, pop: list, pool: list) -> dict:
    plain = _plain_zh_market(state if isinstance(state, dict) else {})
    items = []
    for src in (pool, pop):
        if isinstance(src, list):
            items.extend([g for g in src if isinstance(g, dict)])
    # dedupe by gene_id
    seen = set()
    uniq = []
    for g in items:
        gid = g.get("gene_id")
        if not gid or gid in seen:
            continue
        seen.add(gid)
        uniq.append(g)

    candidates = [
        g
        for g in uniq
        if (g.get("state") or "") in ("ACTIVE", "PROMISING", "WEAKENING")
    ]
    scored = []
    for g in candidates:
        sc, hits = _score_gene_vs_state(g, state if isinstance(state, dict) else {})
        if sc <= 0 and not hits:
            continue
        is_ = g.get("is") if isinstance(g.get("is"), dict) else {}
        oos = g.get("oos") if isinstance(g.get("oos"), dict) else {}
        hyp = g.get("hypothesis") if isinstance(g.get("hypothesis"), dict) else {}
        tag = g.get("evidence_tag") or "Hypothetical"
        observed = "observed" in str(tag).lower()
        scored.append(
            {
                "gene_id": g.get("gene_id"),
                "state": g.get("state"),
                "evidence_tag": tag,
                "tag_kind": "Observed" if observed else "Hypothetical",
                "fitness": g.get("fitness"),
                "overlap_score": round(sc, 3),
                "overlap_hits": hits,
                "is_n": is_.get("n"),
                "oos_n": oos.get("n"),
                "hypothesis_one_liner": (hyp.get("statement") or "")[:160],
            }
        )
    scored.sort(
        key=lambda r: (
            -(r.get("overlap_score") or 0),
            -(r.get("fitness") if isinstance(r.get("fitness"), (int, float)) else -1e9),
        )
    )
    top = scored[:15]
    if len(top) < 8:
        # fill with highest-fitness ACTIVE/PROMISING even if weak overlap
        extra = [
            g
            for g in candidates
            if g.get("gene_id") not in {t["gene_id"] for t in top}
        ]
        extra.sort(
            key=lambda g: float(g.get("fitness") or -1e9),
            reverse=True,
        )
        for g in extra:
            if len(top) >= 8:
                break
            sc, hits = _score_gene_vs_state(g, state if isinstance(state, dict) else {})
            is_ = g.get("is") if isinstance(g.get("is"), dict) else {}
            oos = g.get("oos") if isinstance(g.get("oos"), dict) else {}
            hyp = g.get("hypothesis") if isinstance(g.get("hypothesis"), dict) else {}
            tag = g.get("evidence_tag") or "Hypothetical"
            top.append(
                {
                    "gene_id": g.get("gene_id"),
                    "state": g.get("state"),
                    "evidence_tag": tag,
                    "tag_kind": "Observed" if "observed" in str(tag).lower() else "Hypothetical",
                    "fitness": g.get("fitness"),
                    "overlap_score": round(sc, 3),
                    "overlap_hits": hits or ["（弱重疊／僅供參考）"],
                    "is_n": is_.get("n"),
                    "oos_n": oos.get("n"),
                    "hypothesis_one_liner": (hyp.get("statement") or "")[:160],
                }
            )

    return {
        "title_zh": "當前現象 · 現在發生什麼",
        "now": plain,
        "elevated_turn_candidates": top[:15],
        "elevated_label_zh": "高機率轉向候選（研究級）",
        "disclaimer_zh": "空 LIVE 交易 · 本面板僅研究對照，不構成買賣建議 · 無實盤下單",
        "n_scored": len(scored),
        "n_shown": len(top[:15]),
    }


def _event_combos_top(combos: dict, limit: int = 15) -> list:
    if not isinstance(combos, dict):
        return []
    flagged = combos.get("top_flagged") or []
    pairs = combos.get("pairs") or []
    rows = list(flagged) if flagged else []
    seen = {r.get("combo_id") for r in rows}
    for p in pairs:
        if not isinstance(p, dict):
            continue
        if p.get("combo_id") in seen:
            continue
        rows.append(p)
        seen.add(p.get("combo_id"))
        if len(rows) >= limit:
            break
    out = []
    for p in rows[:limit]:
        out.append(
            {
                "combo_id": p.get("combo_id"),
                "legs": p.get("legs"),
                "definitions": p.get("definitions"),
                "lift": p.get("lift"),
                "n_joint": p.get("n_joint"),
                "k_days": p.get("k_days"),
                "p_joint_given_a": p.get("p_joint_given_a"),
                "p_indep_window": p.get("p_indep_window"),
                "evidence_tag": p.get("evidence_tag"),
                "flagged_lift": p.get("flagged_lift"),
                "active_today": p.get("active_today"),
                "legs_active": p.get("legs_active"),
                "days_since": p.get("days_since"),
            }
        )
    return out



def _list_reports() -> list:
    if not REPORTS_DIR.exists():
        return []
    files = sorted(REPORTS_DIR.glob("*.md"), key=lambda p: p.stat().st_mtime, reverse=True)
    return [
        {
            "name": p.name,
            "path": f"/api/report?name={p.name}",
            "mtime": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(p.stat().st_mtime)),
            "size": p.stat().st_size,
        }
        for p in files
    ]


def _resolve_cycle_cmd() -> tuple[list[str], str]:
    """Prefer cycle_full if present; else phase1_2. Never invent heavy backtests."""
    full = ROOT / "src" / "evb_life" / "cycle_full.py"
    phase36 = ROOT / "src" / "evb_life" / "cycle_phase3_6.py"
    phase12 = ROOT / "src" / "evb_life" / "cycle_phase1_2.py"
    if full.exists():
        return (
            ["python3", "-m", "src.evb_life.cycle_full"],
            "cycle_full",
        )
    if phase12.exists():
        note = "phase1_2 (light). Heavy cycle_phase3_6 / full not present — run separately when added."
        if phase36.exists():
            note = "phase1_2 (light). cycle_phase3_6 exists but is heavy — not auto-chained from UI."
        return (["python3", "-m", "src.evb_life.cycle_phase1_2"], note)
    return (["python3", "-m", "src.evb_life.cycle_phase1_2"], "module may be missing")


def _run_cycle_async():
    with _cycle_lock:
        if _cycle_status["running"]:
            return False
        _cycle_status["running"] = True
        _cycle_status["last_started"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        _cycle_status["last_stdout_tail"] = ""
        _cycle_status["last_stderr_tail"] = ""
        _cycle_status["last_exit_code"] = None

    cmd, note = _resolve_cycle_cmd()
    _cycle_status["last_cmd"] = " ".join(cmd)
    _cycle_status["note"] = note

    def worker():
        try:
            env = os.environ.copy()
            env["PYTHONPATH"] = str(ROOT / "src") + os.pathsep + env.get("PYTHONPATH", "")
            # Prefer running as package from ROOT
            proc = subprocess.run(
                cmd,
                cwd=str(ROOT),
                capture_output=True,
                text=True,
                timeout=600,
                env=env,
            )
            out = (proc.stdout or "")[-4000:]
            err = (proc.stderr or "")[-2000:]
            with _cycle_lock:
                _cycle_status["last_exit_code"] = proc.returncode
                _cycle_status["last_stdout_tail"] = out
                _cycle_status["last_stderr_tail"] = err
                _cycle_status["last_finished"] = time.strftime(
                    "%Y-%m-%dT%H:%M:%SZ", time.gmtime()
                )
                _cycle_status["running"] = False
        except Exception as e:
            with _cycle_lock:
                _cycle_status["last_exit_code"] = -1
                _cycle_status["last_stderr_tail"] = str(e)
                _cycle_status["last_finished"] = time.strftime(
                    "%Y-%m-%dT%H:%M:%SZ", time.gmtime()
                )
                _cycle_status["running"] = False

    threading.Thread(target=worker, daemon=True).start()
    return True


def build_dashboard_payload() -> dict:
    state = _read_json(STATE_PATH, {})
    events_mem = _read_json(EVENTS_PATH, {})
    combos_mem = _read_json(COMBOS_PATH, {})
    pool = _read_json(CANDIDATES_PATH, [])
    pop = _read_json(POP_PATH, [])
    dead = _read_json(DEAD_PATH, [])
    if not isinstance(pop, list):
        pop = []
    if not isinstance(pool, list):
        pool = []
    if not isinstance(dead, list):
        dead = []

    cand = _filter_candidates(pop, pool)
    state_obj = state if isinstance(state, dict) else {}
    phenomena = _build_phenomena(state_obj, pop, pool)
    combo_top = _event_combos_top(combos_mem if isinstance(combos_mem, dict) else {}, 15)

    payload = {
        "meta": {
            "root": str(ROOT),
            "generated_local_hint": "Asia/Hong_Kong UTC+8",
            "honesty": {
                "banner": "Observed vs Hypothetical · OPRA blocked · no BUY guarantees",
                "rules": [
                    "Event age ≠ entry signal (overdue ≠ buy)",
                    "缺席≠該買（late−early hazard ≤ 0）",
                    "No BS option P/L as Verified",
                    "No fitness = CAGR",
                    "Never hide n — thin samples = INSUFFICIENT SAMPLE",
                    "No live trading from this dashboard",
                ],
            },
            "cycle": dict(_cycle_status),
        },
        "market_state": state_obj if state_obj else {"_raw": state},
        "phenomena": phenomena,
        "event_clock": {
            "asof": events_mem.get("asof") if isinstance(events_mem, dict) else None,
            "generated_utc": events_mem.get("generated_utc") if isinstance(events_mem, dict) else None,
            "evidence_tag": events_mem.get("evidence_tag") if isinstance(events_mem, dict) else None,
            "anti_gambler_rule": events_mem.get("anti_gambler_rule") if isinstance(events_mem, dict) else None,
            "anti_gambler_zh": "逾期≠買入 · 缺席≠該買 · 進度條只顯示距離歷史中位，不是下單訊號",
            "n_events": len(events_mem.get("events") or []) if isinstance(events_mem, dict) else 0,
            "top_rows": _event_top_rows(events_mem, 25),
        },
        "event_combos": {
            "asof": combos_mem.get("asof") if isinstance(combos_mem, dict) else None,
            "generated_utc": combos_mem.get("generated_utc") if isinstance(combos_mem, dict) else None,
            "evidence_tag": combos_mem.get("evidence_tag") if isinstance(combos_mem, dict) else None,
            "honesty_zh": (combos_mem.get("honesty_zh") if isinstance(combos_mem, dict) else None)
            or "配搭提升≠交易訊號",
            "k_days": combos_mem.get("k_days") if isinstance(combos_mem, dict) else None,
            "n_pairs": len(combos_mem.get("pairs") or []) if isinstance(combos_mem, dict) else 0,
            "n_flagged": len(combos_mem.get("top_flagged") or []) if isinstance(combos_mem, dict) else 0,
            "top": combo_top,
        },
        "candidates": cand,
        "gene_population": {
            "n": len(pop),
            "counts_by_state": _lifecycle_counts(pop),
            # Slim + cap rows so browser JSON.parse / DOM stay responsive
            "genes": sorted(
                [_gene_row(g) for g in pop if isinstance(g, dict)],
                key=lambda x: (x.get("fitness") is None, -(x.get("fitness") or 0)),
            )[:250],
            "genes_shown": min(250, len(pop)),
            "genes_total": len(pop),
        },
        "evolution_log_tail": _json_safe(_tail_jsonl(EVO_LOG, 50)),
        "dead_but_interesting": [_slim_dead(g) for g in dead[:20] if isinstance(g, dict)],
        "reports": _list_reports(),
    }
    return _json_safe(payload)


MIME = {
    ".html": "text/html; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".md": "text/markdown; charset=utf-8",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
}


class Handler(BaseHTTPRequestHandler):
    server_version = "EVBLifeApp/1.0"

    def log_message(self, fmt, *args):
        # quieter default
        sys_stderr = __import__("sys").stderr
        sys_stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def _json(self, code: int, obj):
        body = json.dumps(_json_safe(obj), ensure_ascii=False, default=str, allow_nan=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self._cors()
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _file(self, path: Path, code: int = 200):
        if not path.exists() or not path.is_file():
            self.send_error(404, "Not Found")
            return
        data = path.read_bytes()
        ctype = MIME.get(path.suffix.lower(), "application/octet-stream")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self._cors()
        if path.suffix.lower() in (".html", ".js", ".css"):
            self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path in ("/", "/index.html"):
            self._file(STATIC / "index.html")
            return
        if path.startswith("/static/"):
            rel = path[len("/static/") :]
            # prevent path escape
            target = (STATIC / rel).resolve()
            if not str(target).startswith(str(STATIC.resolve())):
                self.send_error(403)
                return
            self._file(target)
            return
        if path == "/api/health":
            self._json(200, {"ok": True, "service": "evb-life-app", "port": PORT})
            return
        if path == "/api/dashboard":
            self._json(200, build_dashboard_payload())
            return
        if path == "/api/cycle/status":
            self._json(200, dict(_cycle_status))
            return
        if path == "/api/report":
            qs = parse_qs(parsed.query)
            name = (qs.get("name") or [""])[0]
            if not name or "/" in name or "\\" in name or ".." in name:
                self._json(400, {"error": "bad name"})
                return
            fp = (REPORTS_DIR / name).resolve()
            if not str(fp).startswith(str(REPORTS_DIR.resolve())) or not fp.exists():
                self._json(404, {"error": "not found"})
                return
            self._file(fp)
            return
        if path == "/api/reports":
            self._json(200, {"reports": _list_reports()})
            return

        self.send_error(404, "Not Found")

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        length = int(self.headers.get("Content-Length") or 0)
        if length > 1_000_000:
            self._json(413, {"error": "body too large"})
            return
        _ = self.rfile.read(length) if length else b""

        if path == "/api/cycle":
            started = _run_cycle_async()
            if not started:
                self._json(
                    409,
                    {
                        "ok": False,
                        "error": "cycle already running",
                        "status": dict(_cycle_status),
                    },
                )
                return
            self._json(
                202,
                {
                    "ok": True,
                    "accepted": True,
                    "message": "Cycle started (async). Poll /api/cycle/status or refresh dashboard.",
                    "status": dict(_cycle_status),
                },
            )
            return

        self._json(404, {"error": "not found"})


def main():
    STATIC.mkdir(parents=True, exist_ok=True)
    host = os.environ.get("EVB_APP_HOST", "0.0.0.0")
    httpd = ThreadingHTTPServer((host, PORT), Handler)
    print(f"EVB Life dashboard http://127.0.0.1:{PORT}/  (root={ROOT})", flush=True)
    print("Honesty: Observed vs Hypothetical · OPRA blocked · no BUY guarantees", flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nshutting down", flush=True)
        httpd.shutdown()


if __name__ == "__main__":
    main()
