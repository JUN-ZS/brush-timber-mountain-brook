# EVB Life Package

Research evolutionary trading lifeform (NOT live trading).

## Run App
```bash
cd evb-life
python3 app/server.py
# open http://127.0.0.1:8787/
```

## Light cycle
```bash
cd evb-life
python3 -m src.evb_life.cycle_phase1_2
```

## Full evolution (heavy)
```bash
python3 -m src.evb_life.cycle_full
```

Honesty: Observed vs Hypothetical · OPRA blocked · no BUY guarantees · overdue ≠ buy.

Large dead_gene_bank.json may be omitted from this zip if oversized — see PACKAGE_NOTES.txt.
