import pandas as pd,numpy as np, math
from scipy.stats import norm
D=pd.read_csv('/mnt/data/evb/ex/artifacts/data/spots_qqq_vxx_vix.csv',parse_dates=['Date']).sort_values('Date').reset_index(drop=True)
q=D.QQQ.astype(float).values; v=D.VIX.astype(float).ffill().values; n=len(D)
r=pd.Series(q).pct_change(fill_method=None); rv20=r.rolling(20).std().values*np.sqrt(252); ma20=pd.Series(q).rolling(20).mean().values
md=q/ma20-1; below=q<ma20; age=np.zeros(n,int); a=0
for i,x in enumerate(below): a=a+1 if x else 0; age[i]=a
q5=pd.Series(q).pct_change(5,fill_method=None).values; v5=pd.Series(v).pct_change(5,fill_method=None).values
rvz=(r/(r.rolling(20).std()+1e-9)).values

def past_pct(x,w=252):
 out=np.full(n,np.nan)
 for i in range(w,n): out[i]=np.mean(x[i-w:i]<x[i])
 return out
# BS vector helpers
def N(x): return norm.cdf(x)
def bs(S,K,T,sig,call=True,r=.04):
 S=np.asarray(S,float); K=np.asarray(K,float); sig=np.maximum(np.asarray(sig,float),1e-6); T=np.asarray(T,float)
 vs=sig*np.sqrt(np.maximum(T,1e-8)); d1=(np.log(S/K)+(r+.5*sig**2)*T)/vs; d2=d1-vs
 return S*N(d1)-K*np.exp(-r*T)*N(d2) if call else K*np.exp(-r*T)*N(-d2)-S*N(-d1)
def Kdelta(S,T,sig,delta,call=True,r=.04):
 d1=norm.ppf(delta if call else 1-delta); return S*np.exp(-(d1*sig*np.sqrt(T)-(r+.5*sig**2)*T))
sig=np.clip(1.08*v/100,.10,.90); T0=30/365; T10=20/365
# Precompute 10-day trade returns for structures, with 0/5/10% friction
structures={}
def add(name, legs, den):
 # legs tuples qty,type,K array,price array
 p0=sum(qty*pr for qty,typ,K,pr in legs)
 S2=np.roll(q,-10); V2=np.roll(v,-10)
 valid=np.arange(n)+10<n
 p1=np.zeros(n); abs0=np.zeros(n); abs1=np.zeros(n)
 for qty,typ,K,pr in legs:
  p1 += qty*bs(S2,K,T10,sig*np.roll(v,-10)/np.maximum(v,1e-9),typ=='C')
  abs0 += abs(qty)*pr
  abs1 += abs(qty)*bs(S2,K,T10,sig*np.roll(v,-10)/np.maximum(v,1e-9),typ=='C')
 out={}
 for f in [0,.05,.10]:
  pnl=p1-p0-f*(abs0+abs1)
  out[f]=np.where(valid,pnl/(np.abs(den)+1e-9),np.nan)
 structures[name]=out
# Recompute future IV directly: above sig2 formula equals 1.08*v2/100; simplify by using v2
sig2=np.clip(1.08*np.roll(v,-10)/100,.10,.90)
def make(name,kind,a=None,b=None,w=None):
 S=q; s=sig; T=T0
 if kind=='call':
  K=Kdelta(S,T,s,.5,True); p=bs(S,K,T,s,True); den=p
  legs=[(1,'C',K,p)]
 elif kind=='vert':
  K1=Kdelta(S,T,s,a,True); K2=Kdelta(S,T,s,b,True); p1=bs(S,K1,T,s,True); p2=bs(S,K2,T,s,True); den=np.maximum(K2-K1-(p1-p2),1e-8); legs=[(1,'C',K1,p1),(-1,'C',K2,p2)]
 elif kind=='cal':
  K=S; p2=bs(S,K,60/365,s,True); p1=bs(S,K,T,s,True); den=np.maximum(p2-p1,1e-8); legs=[(1,'C',K,p2),(-1,'C',K,p1)]
 elif kind=='putcred':
  Ks=Kdelta(S,T,s,a,False); Kl=Kdelta(S,T,s,b,False); ps=bs(S,Ks,T,s,False); pl=bs(S,Kl,T,s,False)
  # a>b => Ks higher strike generally
  den=np.maximum(Ks-Kl-(ps-pl),1e-8); legs=[(-1,'P',Ks,ps),(1,'P',Kl,pl)]
 elif kind=='hedge':
  K1=Kdelta(S,T,s,a,True); K2=Kdelta(S,T,s,b,True); p1=bs(S,K1,T,s,True); p2=bs(S,K2,T,s,True); Kp=Kdelta(S,T,s,.10,False); pp=bs(S,Kp,T,s,False)
  den=np.maximum(K2-K1-(p1-p2),1e-8)+w*pp; legs=[(1,'C',K1,p1),(-1,'C',K2,p2),(w,'P',Kp,pp)]
 p0=sum(qty*pr for qty,typ,K,pr in legs); S2=np.roll(S,-10); p1f=np.zeros(n); abs0=np.zeros(n); abs1=np.zeros(n)
 for qty,typ,K,pr in legs:
  p1f += qty*bs(S2,K,T10,sig2,typ=='C'); abs0 += abs(qty)*pr; abs1 += abs(qty)*bs(S2,K,T10,sig2,typ=='C')
 valid=np.arange(n)+10<n
 for f in [0,.05,.10]: structures[name][f]=np.where(valid,(p1f-p0-f*(abs0+abs1))/(np.abs(den)+1e-9),np.nan)
for name,kind,args in [('C_ATM','call',()),('CV_35_15','vert',(.35,.15)),('CV_50_10','vert',(.50,.10)),('CV_25_10','vert',(.25,.10)),('CAL_ATM','cal',()),('PC_25_10','putcred',(.25,.10)),('H_35_15_15','hedge',(.35,.15,.15)),('H_50_10_10','hedge',(.50,.10,.10)),('H_50_15_20','hedge',(.50,.15,.20))]:
 structures[name]={}; make(name,kind,*args)
# 12k genomes, signals one per episode
rng=np.random.default_rng(11); genomes=[]
for dist in np.linspace(.01,.06,10):
 for amin in range(2,13):
  for ret in [.001,.002,.003,.004,.006,.008]:
   for vd in [.01,.02,.03,.04,.05,.07]:
    for rel in [0,.1,.2,.3,.5]:
     for logic in range(5): genomes.append((dist,amin,ret,vd,rel,logic))
rng.shuffle(genomes); genomes=genomes[:12000]
# fast signal + evaluate structures
records=[]
for g in genomes:
 dist,amin,ret,vd,rel,logic=g
 stress=(md<=-dist)&(age>=amin)
 t1=r.values>=ret; t2=v5<=-vd; relok=rvz>=rel; cool=v5<=-vd
 turn=[t1&t2,t1&relok&t2,t1&cool,(q5>=ret*2)&(v5<=-vd),t1&(v5<=-vd)&(v<=pd.Series(v).rolling(20).mean().values)][logic]
 sigmask=stress&turn
 inds=[]; last=-99
 for i in np.where(sigmask)[0]:
  if i-last>10: inds.append(i); last=i
 isidx=[i for i in inds if D.Date.iloc[i].year<=2022 and i+10<n]; oidx=[i for i in inds if D.Date.iloc[i].year>=2023 and i+10<n]
 if len(isidx)<12 or len(oidx)<4: continue
 for st,arrs in structures.items():
  arr5=arrs[.05][isidx]; o5=arrs[.05][oidx]; arr10=arrs[.10][isidx]
  if np.isfinite(arr5).sum()<12: continue
  ev=np.nanmean(arr5); win=np.nanmean(arr5>0); q05=np.nanquantile(arr5,.05); es=np.nanmean(arr5[arr5<=q05]) if np.any(arr5<=q05) else q05
  oe=np.nanmean(o5); ow=np.nanmean(o5>0); oq=np.nanquantile(o5,.05)
  score=min(ev,oe)/(abs(es)+.01)*math.log1p(min(len(arr5),len(o5)))
  records.append((score,st,g,len(arr5),ev,win,q05,es,oe,ow,oq,len(o5),np.nanmean(arr10)))
res=pd.DataFrame(records,columns=['score','structure','genome','is_n','is_ev','is_win','is_q05','is_es','oos_ev','oos_win','oos_q05','oos_n','is_ev10'])
print('rows',n,'genomes',len(genomes),'records',len(res))
res['is_score']=res.is_ev/(abs(res.is_es)+.01)*np.log1p(res.is_n)
print('\nIS top:')
for _,x in res.sort_values('is_score',ascending=False).head(20).iterrows(): print(x.structure,x.genome,'IS',round(x.is_ev,4),round(x.is_win,3),round(x.is_q05,4),x.is_n,'OOS',round(x.oos_ev,4),round(x.oos_win,3),round(x.oos_q05,4),x.oos_n,'fr10',round(x.is_ev10,4))
print('\nSTABLE top:')
for _,x in res.sort_values('score',ascending=False).head(30).iterrows(): print(x.structure,x.genome,'IS',round(x.is_ev,4),round(x.is_win,3),round(x.is_q05,4),x.is_n,'OOS',round(x.oos_ev,4),round(x.oos_win,3),round(x.oos_q05,4),x.oos_n,'score',round(x.score,4))
res.to_csv('/mnt/data/evb/evolutionary_candidate_pool.csv',index=False)
